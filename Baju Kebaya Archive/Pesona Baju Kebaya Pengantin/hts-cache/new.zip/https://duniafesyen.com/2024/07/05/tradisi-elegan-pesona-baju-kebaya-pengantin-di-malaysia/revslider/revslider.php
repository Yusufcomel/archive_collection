<!DOCTYPE html>
<html lang="en-US" prefix="og: https://ogp.me/ns#">
<head>
<meta charset="UTF-8" />
<meta http-equiv="X-UA-Compatible" content="IE=Edge" />
<meta name="viewport" content="width=device-width, initial-scale=1.0, maximum-scale=1.0, user-scalable=0" />
<link rel="profile" href="http://gmpg.org/xfn/11" />
<link rel="pingback" href="https://duniafesyen.com/xmlrpc.php" />
<link rel="shortcut icon" href="https://duniafesyen-media.s3.ap-southeast-1.amazonaws.com/wp-content/uploads/2025/03/03181828/DF-Favicon-32x32-1.png" />
	<style>img:is([sizes="auto" i], [sizes^="auto," i]) { contain-intrinsic-size: 3000px 1500px }</style>
	
<!-- Search Engine Optimization by Rank Math PRO - https://rankmath.com/ -->
<title>Page Not Found - Dunia Fesyen</title>
<meta name="robots" content="follow, noindex"/>
<meta property="og:locale" content="en_US" />
<meta property="og:type" content="article" />
<meta property="og:title" content="Page Not Found - Dunia Fesyen" />
<meta property="og:site_name" content="Dunia Fesyen" />
<meta name="twitter:card" content="summary_large_image" />
<meta name="twitter:title" content="Page Not Found - Dunia Fesyen" />
<script type="application/ld+json" class="rank-math-schema-pro">{"@context":"https://schema.org","@graph":[{"@type":"Person","@id":"https://duniafesyen.com/#person","name":"Dunia Fesyen","url":"https://duniafesyen.com","email":"hello@duniafesyen.com"},{"@type":"WebSite","@id":"https://duniafesyen.com/#website","url":"https://duniafesyen.com","name":"Dunia Fesyen","publisher":{"@id":"https://duniafesyen.com/#person"},"inLanguage":"en-US"},{"@type":"WebPage","@id":"#webpage","url":"","name":"Page Not Found - Dunia Fesyen","isPartOf":{"@id":"https://duniafesyen.com/#website"},"inLanguage":"en-US"}]}</script>
<!-- /Rank Math WordPress SEO plugin -->

<link rel='dns-prefetch' href='//fonts.googleapis.com' />
<link rel="alternate" type="application/rss+xml" title="Dunia Fesyen &raquo; Feed" href="https://duniafesyen.com/feed/" />
<link rel="alternate" type="application/rss+xml" title="Dunia Fesyen &raquo; Comments Feed" href="https://duniafesyen.com/comments/feed/" />
<link rel="preload" href="//duniafesyen.com/wp-content/themes/elessi-theme/assets/minify-font-icons/font-nasa-icons/nasa-font.woff" as="font" type="font/woff" crossorigin /><link rel="preload" href="//duniafesyen.com/wp-content/themes/elessi-theme/assets/minify-font-icons/font-pe-icon-7-stroke/Pe-icon-7-stroke.woff" as="font" type="font/woff" crossorigin /><link rel="preload" href="//duniafesyen.com/wp-content/themes/elessi-theme/assets/minify-font-icons/font-awesome-4.7.0/fontawesome-webfont.woff2" as="font" type="font/woff2" crossorigin /><link rel="preload" href="//duniafesyen.com/wp-content/themes/elessi-theme/assets/minify-font-icons/font-awesome-4.7.0/fontawesome-webfont.woff" as="font" type="font/woff" crossorigin /><script type="text/javascript">
/* <![CDATA[ */
window._wpemojiSettings = {"baseUrl":"https:\/\/s.w.org\/images\/core\/emoji\/15.1.0\/72x72\/","ext":".png","svgUrl":"https:\/\/s.w.org\/images\/core\/emoji\/15.1.0\/svg\/","svgExt":".svg","source":{"concatemoji":"https:\/\/duniafesyen.com\/wp-includes\/js\/wp-emoji-release.min.js?ver=6.8.1"}};
/*! This file is auto-generated */
!function(i,n){var o,s,e;function c(e){try{var t={supportTests:e,timestamp:(new Date).valueOf()};sessionStorage.setItem(o,JSON.stringify(t))}catch(e){}}function p(e,t,n){e.clearRect(0,0,e.canvas.width,e.canvas.height),e.fillText(t,0,0);var t=new Uint32Array(e.getImageData(0,0,e.canvas.width,e.canvas.height).data),r=(e.clearRect(0,0,e.canvas.width,e.canvas.height),e.fillText(n,0,0),new Uint32Array(e.getImageData(0,0,e.canvas.width,e.canvas.height).data));return t.every(function(e,t){return e===r[t]})}function u(e,t,n){switch(t){case"flag":return n(e,"\ud83c\udff3\ufe0f\u200d\u26a7\ufe0f","\ud83c\udff3\ufe0f\u200b\u26a7\ufe0f")?!1:!n(e,"\ud83c\uddfa\ud83c\uddf3","\ud83c\uddfa\u200b\ud83c\uddf3")&&!n(e,"\ud83c\udff4\udb40\udc67\udb40\udc62\udb40\udc65\udb40\udc6e\udb40\udc67\udb40\udc7f","\ud83c\udff4\u200b\udb40\udc67\u200b\udb40\udc62\u200b\udb40\udc65\u200b\udb40\udc6e\u200b\udb40\udc67\u200b\udb40\udc7f");case"emoji":return!n(e,"\ud83d\udc26\u200d\ud83d\udd25","\ud83d\udc26\u200b\ud83d\udd25")}return!1}function f(e,t,n){var r="undefined"!=typeof WorkerGlobalScope&&self instanceof WorkerGlobalScope?new OffscreenCanvas(300,150):i.createElement("canvas"),a=r.getContext("2d",{willReadFrequently:!0}),o=(a.textBaseline="top",a.font="600 32px Arial",{});return e.forEach(function(e){o[e]=t(a,e,n)}),o}function t(e){var t=i.createElement("script");t.src=e,t.defer=!0,i.head.appendChild(t)}"undefined"!=typeof Promise&&(o="wpEmojiSettingsSupports",s=["flag","emoji"],n.supports={everything:!0,everythingExceptFlag:!0},e=new Promise(function(e){i.addEventListener("DOMContentLoaded",e,{once:!0})}),new Promise(function(t){var n=function(){try{var e=JSON.parse(sessionStorage.getItem(o));if("object"==typeof e&&"number"==typeof e.timestamp&&(new Date).valueOf()<e.timestamp+604800&&"object"==typeof e.supportTests)return e.supportTests}catch(e){}return null}();if(!n){if("undefined"!=typeof Worker&&"undefined"!=typeof OffscreenCanvas&&"undefined"!=typeof URL&&URL.createObjectURL&&"undefined"!=typeof Blob)try{var e="postMessage("+f.toString()+"("+[JSON.stringify(s),u.toString(),p.toString()].join(",")+"));",r=new Blob([e],{type:"text/javascript"}),a=new Worker(URL.createObjectURL(r),{name:"wpTestEmojiSupports"});return void(a.onmessage=function(e){c(n=e.data),a.terminate(),t(n)})}catch(e){}c(n=f(s,u,p))}t(n)}).then(function(e){for(var t in e)n.supports[t]=e[t],n.supports.everything=n.supports.everything&&n.supports[t],"flag"!==t&&(n.supports.everythingExceptFlag=n.supports.everythingExceptFlag&&n.supports[t]);n.supports.everythingExceptFlag=n.supports.everythingExceptFlag&&!n.supports.flag,n.DOMReady=!1,n.readyCallback=function(){n.DOMReady=!0}}).then(function(){return e}).then(function(){var e;n.supports.everything||(n.readyCallback(),(e=n.source||{}).concatemoji?t(e.concatemoji):e.wpemoji&&e.twemoji&&(t(e.twemoji),t(e.wpemoji)))}))}((window,document),window._wpemojiSettings);
/* ]]> */
</script>
<link rel='stylesheet' id='elementor-frontend-css' href='https://duniafesyen.com/wp-content/plugins/elementor/assets/css/frontend.min.css?ver=3.28.4' type='text/css' media='all' />
<link rel='stylesheet' id='elementor-post-3702-css' href='https://duniafesyen.com/wp-content/uploads/elementor/css/post-3702.css?ver=1745378997' type='text/css' media='all' />
<link rel='stylesheet' id='swiper-css' href='https://duniafesyen.com/wp-content/plugins/elementor/assets/lib/swiper/v8/css/swiper.min.css?ver=8.4.5' type='text/css' media='all' />
<link rel='stylesheet' id='e-swiper-css' href='https://duniafesyen.com/wp-content/plugins/elementor/assets/css/conditionals/e-swiper.min.css?ver=3.28.4' type='text/css' media='all' />
<link rel='stylesheet' id='sbi_styles-css' href='https://duniafesyen.com/wp-content/plugins/instagram-feed/css/sbi-styles.min.css?ver=6.9.0' type='text/css' media='all' />
<link rel='stylesheet' id='hfe-widgets-style-css' href='https://duniafesyen.com/wp-content/plugins/header-footer-elementor/inc/widgets-css/frontend.css?ver=2.3.1' type='text/css' media='all' />
<style id='wp-emoji-styles-inline-css' type='text/css'>

	img.wp-smiley, img.emoji {
		display: inline !important;
		border: none !important;
		box-shadow: none !important;
		height: 1em !important;
		width: 1em !important;
		margin: 0 0.07em !important;
		vertical-align: -0.1em !important;
		background: none !important;
		padding: 0 !important;
	}
</style>
<link rel='stylesheet' id='wp-block-library-css' href='https://duniafesyen.com/wp-includes/css/dist/block-library/style.min.css?ver=6.8.1' type='text/css' media='all' />
<style id='classic-theme-styles-inline-css' type='text/css'>
/*! This file is auto-generated */
.wp-block-button__link{color:#fff;background-color:#32373c;border-radius:9999px;box-shadow:none;text-decoration:none;padding:calc(.667em + 2px) calc(1.333em + 2px);font-size:1.125em}.wp-block-file__button{background:#32373c;color:#fff;text-decoration:none}
</style>
<style id='global-styles-inline-css' type='text/css'>
:root{--wp--preset--aspect-ratio--square: 1;--wp--preset--aspect-ratio--4-3: 4/3;--wp--preset--aspect-ratio--3-4: 3/4;--wp--preset--aspect-ratio--3-2: 3/2;--wp--preset--aspect-ratio--2-3: 2/3;--wp--preset--aspect-ratio--16-9: 16/9;--wp--preset--aspect-ratio--9-16: 9/16;--wp--preset--color--black: #000000;--wp--preset--color--cyan-bluish-gray: #abb8c3;--wp--preset--color--white: #ffffff;--wp--preset--color--pale-pink: #f78da7;--wp--preset--color--vivid-red: #cf2e2e;--wp--preset--color--luminous-vivid-orange: #ff6900;--wp--preset--color--luminous-vivid-amber: #fcb900;--wp--preset--color--light-green-cyan: #7bdcb5;--wp--preset--color--vivid-green-cyan: #00d084;--wp--preset--color--pale-cyan-blue: #8ed1fc;--wp--preset--color--vivid-cyan-blue: #0693e3;--wp--preset--color--vivid-purple: #9b51e0;--wp--preset--gradient--vivid-cyan-blue-to-vivid-purple: linear-gradient(135deg,rgba(6,147,227,1) 0%,rgb(155,81,224) 100%);--wp--preset--gradient--light-green-cyan-to-vivid-green-cyan: linear-gradient(135deg,rgb(122,220,180) 0%,rgb(0,208,130) 100%);--wp--preset--gradient--luminous-vivid-amber-to-luminous-vivid-orange: linear-gradient(135deg,rgba(252,185,0,1) 0%,rgba(255,105,0,1) 100%);--wp--preset--gradient--luminous-vivid-orange-to-vivid-red: linear-gradient(135deg,rgba(255,105,0,1) 0%,rgb(207,46,46) 100%);--wp--preset--gradient--very-light-gray-to-cyan-bluish-gray: linear-gradient(135deg,rgb(238,238,238) 0%,rgb(169,184,195) 100%);--wp--preset--gradient--cool-to-warm-spectrum: linear-gradient(135deg,rgb(74,234,220) 0%,rgb(151,120,209) 20%,rgb(207,42,186) 40%,rgb(238,44,130) 60%,rgb(251,105,98) 80%,rgb(254,248,76) 100%);--wp--preset--gradient--blush-light-purple: linear-gradient(135deg,rgb(255,206,236) 0%,rgb(152,150,240) 100%);--wp--preset--gradient--blush-bordeaux: linear-gradient(135deg,rgb(254,205,165) 0%,rgb(254,45,45) 50%,rgb(107,0,62) 100%);--wp--preset--gradient--luminous-dusk: linear-gradient(135deg,rgb(255,203,112) 0%,rgb(199,81,192) 50%,rgb(65,88,208) 100%);--wp--preset--gradient--pale-ocean: linear-gradient(135deg,rgb(255,245,203) 0%,rgb(182,227,212) 50%,rgb(51,167,181) 100%);--wp--preset--gradient--electric-grass: linear-gradient(135deg,rgb(202,248,128) 0%,rgb(113,206,126) 100%);--wp--preset--gradient--midnight: linear-gradient(135deg,rgb(2,3,129) 0%,rgb(40,116,252) 100%);--wp--preset--font-size--small: 13px;--wp--preset--font-size--medium: 20px;--wp--preset--font-size--large: 36px;--wp--preset--font-size--x-large: 42px;--wp--preset--spacing--20: 0.44rem;--wp--preset--spacing--30: 0.67rem;--wp--preset--spacing--40: 1rem;--wp--preset--spacing--50: 1.5rem;--wp--preset--spacing--60: 2.25rem;--wp--preset--spacing--70: 3.38rem;--wp--preset--spacing--80: 5.06rem;--wp--preset--shadow--natural: 6px 6px 9px rgba(0, 0, 0, 0.2);--wp--preset--shadow--deep: 12px 12px 50px rgba(0, 0, 0, 0.4);--wp--preset--shadow--sharp: 6px 6px 0px rgba(0, 0, 0, 0.2);--wp--preset--shadow--outlined: 6px 6px 0px -3px rgba(255, 255, 255, 1), 6px 6px rgba(0, 0, 0, 1);--wp--preset--shadow--crisp: 6px 6px 0px rgba(0, 0, 0, 1);}:where(.is-layout-flex){gap: 0.5em;}:where(.is-layout-grid){gap: 0.5em;}body .is-layout-flex{display: flex;}.is-layout-flex{flex-wrap: wrap;align-items: center;}.is-layout-flex > :is(*, div){margin: 0;}body .is-layout-grid{display: grid;}.is-layout-grid > :is(*, div){margin: 0;}:where(.wp-block-columns.is-layout-flex){gap: 2em;}:where(.wp-block-columns.is-layout-grid){gap: 2em;}:where(.wp-block-post-template.is-layout-flex){gap: 1.25em;}:where(.wp-block-post-template.is-layout-grid){gap: 1.25em;}.has-black-color{color: var(--wp--preset--color--black) !important;}.has-cyan-bluish-gray-color{color: var(--wp--preset--color--cyan-bluish-gray) !important;}.has-white-color{color: var(--wp--preset--color--white) !important;}.has-pale-pink-color{color: var(--wp--preset--color--pale-pink) !important;}.has-vivid-red-color{color: var(--wp--preset--color--vivid-red) !important;}.has-luminous-vivid-orange-color{color: var(--wp--preset--color--luminous-vivid-orange) !important;}.has-luminous-vivid-amber-color{color: var(--wp--preset--color--luminous-vivid-amber) !important;}.has-light-green-cyan-color{color: var(--wp--preset--color--light-green-cyan) !important;}.has-vivid-green-cyan-color{color: var(--wp--preset--color--vivid-green-cyan) !important;}.has-pale-cyan-blue-color{color: var(--wp--preset--color--pale-cyan-blue) !important;}.has-vivid-cyan-blue-color{color: var(--wp--preset--color--vivid-cyan-blue) !important;}.has-vivid-purple-color{color: var(--wp--preset--color--vivid-purple) !important;}.has-black-background-color{background-color: var(--wp--preset--color--black) !important;}.has-cyan-bluish-gray-background-color{background-color: var(--wp--preset--color--cyan-bluish-gray) !important;}.has-white-background-color{background-color: var(--wp--preset--color--white) !important;}.has-pale-pink-background-color{background-color: var(--wp--preset--color--pale-pink) !important;}.has-vivid-red-background-color{background-color: var(--wp--preset--color--vivid-red) !important;}.has-luminous-vivid-orange-background-color{background-color: var(--wp--preset--color--luminous-vivid-orange) !important;}.has-luminous-vivid-amber-background-color{background-color: var(--wp--preset--color--luminous-vivid-amber) !important;}.has-light-green-cyan-background-color{background-color: var(--wp--preset--color--light-green-cyan) !important;}.has-vivid-green-cyan-background-color{background-color: var(--wp--preset--color--vivid-green-cyan) !important;}.has-pale-cyan-blue-background-color{background-color: var(--wp--preset--color--pale-cyan-blue) !important;}.has-vivid-cyan-blue-background-color{background-color: var(--wp--preset--color--vivid-cyan-blue) !important;}.has-vivid-purple-background-color{background-color: var(--wp--preset--color--vivid-purple) !important;}.has-black-border-color{border-color: var(--wp--preset--color--black) !important;}.has-cyan-bluish-gray-border-color{border-color: var(--wp--preset--color--cyan-bluish-gray) !important;}.has-white-border-color{border-color: var(--wp--preset--color--white) !important;}.has-pale-pink-border-color{border-color: var(--wp--preset--color--pale-pink) !important;}.has-vivid-red-border-color{border-color: var(--wp--preset--color--vivid-red) !important;}.has-luminous-vivid-orange-border-color{border-color: var(--wp--preset--color--luminous-vivid-orange) !important;}.has-luminous-vivid-amber-border-color{border-color: var(--wp--preset--color--luminous-vivid-amber) !important;}.has-light-green-cyan-border-color{border-color: var(--wp--preset--color--light-green-cyan) !important;}.has-vivid-green-cyan-border-color{border-color: var(--wp--preset--color--vivid-green-cyan) !important;}.has-pale-cyan-blue-border-color{border-color: var(--wp--preset--color--pale-cyan-blue) !important;}.has-vivid-cyan-blue-border-color{border-color: var(--wp--preset--color--vivid-cyan-blue) !important;}.has-vivid-purple-border-color{border-color: var(--wp--preset--color--vivid-purple) !important;}.has-vivid-cyan-blue-to-vivid-purple-gradient-background{background: var(--wp--preset--gradient--vivid-cyan-blue-to-vivid-purple) !important;}.has-light-green-cyan-to-vivid-green-cyan-gradient-background{background: var(--wp--preset--gradient--light-green-cyan-to-vivid-green-cyan) !important;}.has-luminous-vivid-amber-to-luminous-vivid-orange-gradient-background{background: var(--wp--preset--gradient--luminous-vivid-amber-to-luminous-vivid-orange) !important;}.has-luminous-vivid-orange-to-vivid-red-gradient-background{background: var(--wp--preset--gradient--luminous-vivid-orange-to-vivid-red) !important;}.has-very-light-gray-to-cyan-bluish-gray-gradient-background{background: var(--wp--preset--gradient--very-light-gray-to-cyan-bluish-gray) !important;}.has-cool-to-warm-spectrum-gradient-background{background: var(--wp--preset--gradient--cool-to-warm-spectrum) !important;}.has-blush-light-purple-gradient-background{background: var(--wp--preset--gradient--blush-light-purple) !important;}.has-blush-bordeaux-gradient-background{background: var(--wp--preset--gradient--blush-bordeaux) !important;}.has-luminous-dusk-gradient-background{background: var(--wp--preset--gradient--luminous-dusk) !important;}.has-pale-ocean-gradient-background{background: var(--wp--preset--gradient--pale-ocean) !important;}.has-electric-grass-gradient-background{background: var(--wp--preset--gradient--electric-grass) !important;}.has-midnight-gradient-background{background: var(--wp--preset--gradient--midnight) !important;}.has-small-font-size{font-size: var(--wp--preset--font-size--small) !important;}.has-medium-font-size{font-size: var(--wp--preset--font-size--medium) !important;}.has-large-font-size{font-size: var(--wp--preset--font-size--large) !important;}.has-x-large-font-size{font-size: var(--wp--preset--font-size--x-large) !important;}
:where(.wp-block-post-template.is-layout-flex){gap: 1.25em;}:where(.wp-block-post-template.is-layout-grid){gap: 1.25em;}
:where(.wp-block-columns.is-layout-flex){gap: 2em;}:where(.wp-block-columns.is-layout-grid){gap: 2em;}
:root :where(.wp-block-pullquote){font-size: 1.5em;line-height: 1.6;}
</style>
<link rel='stylesheet' id='sr7css-css' href='//duniafesyen.com/wp-content/plugins/revslider/public/css/sr7.css?ver=6.7.30' type='text/css' media='all' />
<style id='woocommerce-inline-inline-css' type='text/css'>
.woocommerce form .form-row .required { visibility: visible; }
</style>
<link rel='stylesheet' id='hfe-style-css' href='https://duniafesyen.com/wp-content/plugins/header-footer-elementor/assets/css/header-footer-elementor.css?ver=2.3.1' type='text/css' media='all' />
<link rel='stylesheet' id='elementor-icons-css' href='https://duniafesyen.com/wp-content/plugins/elementor/assets/lib/eicons/css/elementor-icons.min.css?ver=5.36.0' type='text/css' media='all' />
<link rel='stylesheet' id='elementor-post-7-css' href='https://duniafesyen.com/wp-content/uploads/elementor/css/post-7.css?ver=1745378998' type='text/css' media='all' />
<link rel='stylesheet' id='sbistyles-css' href='https://duniafesyen.com/wp-content/plugins/instagram-feed/css/sbi-styles.min.css?ver=6.9.0' type='text/css' media='all' />
<link rel='stylesheet' id='brands-styles-css' href='https://duniafesyen.com/wp-content/plugins/woocommerce/assets/css/brands.css?ver=9.8.5' type='text/css' media='all' />
<link rel='stylesheet' id='elessi-fonts-icons-css' href='https://duniafesyen.com/wp-content/themes/elessi-theme/assets/minify-font-icons/fonts.min.css?ver=6.8.1' type='text/css' media='all' />
<link rel='stylesheet' id='photoswipe-css' href='https://duniafesyen.com/wp-content/plugins/woocommerce/assets/css/photoswipe/photoswipe.min.css?ver=9.8.5' type='text/css' media='all' />
<link rel='stylesheet' id='photoswipe-default-skin-css' href='https://duniafesyen.com/wp-content/plugins/woocommerce/assets/css/photoswipe/default-skin/default-skin.min.css?ver=9.8.5' type='text/css' media='all' />
<link rel='stylesheet' id='nasa-fonts-css' href='https://fonts.googleapis.com/css?family=Jost%3A300%2C300italic%2C400%2C400italic%2C500%2C500italic%2C600%2C600italic%2C700%2C700italic%2C800%2C800italic%2C900%2C900italic&#038;subset=latin&#038;display=swap&#038;ver=6.8.1' type='text/css' media='all' />
<link rel='stylesheet' id='jquery-fixedheadertable-style-css' href='https://duniafesyen.com/wp-content/plugins/yith-woocommerce-compare/assets/css/jquery.dataTables.css?ver=1.10.18' type='text/css' media='all' />
<link rel='stylesheet' id='yith_woocompare_page-css' href='https://duniafesyen.com/wp-content/plugins/yith-woocommerce-compare/assets/css/compare.css?ver=3.0.1' type='text/css' media='all' />
<link rel='stylesheet' id='yith-woocompare-widget-css' href='https://duniafesyen.com/wp-content/plugins/yith-woocommerce-compare/assets/css/widget.css?ver=3.0.1' type='text/css' media='all' />
<style id='akismet-widget-style-inline-css' type='text/css'>

			.a-stats {
				--akismet-color-mid-green: #357b49;
				--akismet-color-white: #fff;
				--akismet-color-light-grey: #f6f7f7;

				max-width: 350px;
				width: auto;
			}

			.a-stats * {
				all: unset;
				box-sizing: border-box;
			}

			.a-stats strong {
				font-weight: 600;
			}

			.a-stats a.a-stats__link,
			.a-stats a.a-stats__link:visited,
			.a-stats a.a-stats__link:active {
				background: var(--akismet-color-mid-green);
				border: none;
				box-shadow: none;
				border-radius: 8px;
				color: var(--akismet-color-white);
				cursor: pointer;
				display: block;
				font-family: -apple-system, BlinkMacSystemFont, 'Segoe UI', 'Roboto', 'Oxygen-Sans', 'Ubuntu', 'Cantarell', 'Helvetica Neue', sans-serif;
				font-weight: 500;
				padding: 12px;
				text-align: center;
				text-decoration: none;
				transition: all 0.2s ease;
			}

			/* Extra specificity to deal with TwentyTwentyOne focus style */
			.widget .a-stats a.a-stats__link:focus {
				background: var(--akismet-color-mid-green);
				color: var(--akismet-color-white);
				text-decoration: none;
			}

			.a-stats a.a-stats__link:hover {
				filter: brightness(110%);
				box-shadow: 0 4px 12px rgba(0, 0, 0, 0.06), 0 0 2px rgba(0, 0, 0, 0.16);
			}

			.a-stats .count {
				color: var(--akismet-color-white);
				display: block;
				font-size: 1.5em;
				line-height: 1.4;
				padding: 0 13px;
				white-space: nowrap;
			}
		
</style>
<link rel='stylesheet' id='hfe-elementor-icons-css' href='https://duniafesyen.com/wp-content/plugins/elementor/assets/lib/eicons/css/elementor-icons.min.css?ver=5.34.0' type='text/css' media='all' />
<link rel='stylesheet' id='hfe-icons-list-css' href='https://duniafesyen.com/wp-content/plugins/elementor/assets/css/widget-icon-list.min.css?ver=3.24.3' type='text/css' media='all' />
<link rel='stylesheet' id='hfe-social-icons-css' href='https://duniafesyen.com/wp-content/plugins/elementor/assets/css/widget-social-icons.min.css?ver=3.24.0' type='text/css' media='all' />
<link rel='stylesheet' id='hfe-social-share-icons-brands-css' href='https://duniafesyen.com/wp-content/plugins/elementor/assets/lib/font-awesome/css/brands.css?ver=5.15.3' type='text/css' media='all' />
<link rel='stylesheet' id='hfe-social-share-icons-fontawesome-css' href='https://duniafesyen.com/wp-content/plugins/elementor/assets/lib/font-awesome/css/fontawesome.css?ver=5.15.3' type='text/css' media='all' />
<link rel='stylesheet' id='hfe-nav-menu-icons-css' href='https://duniafesyen.com/wp-content/plugins/elementor/assets/lib/font-awesome/css/solid.css?ver=5.15.3' type='text/css' media='all' />
<link rel='stylesheet' id='elessi-style-css' href='https://duniafesyen.com/wp-content/themes/elessi-theme/style.css?ver=6.8.1' type='text/css' media='all' />
<link rel='stylesheet' id='elessi-child-style-css' href='https://duniafesyen.com/wp-content/themes/elessi-theme-child/style.css?ver=6.8.1' type='text/css' media='all' />
<link rel='stylesheet' id='elessi-style-elementor-css' href='https://duniafesyen.com/wp-content/themes/elessi-theme/style-elementor.css' type='text/css' media='all' />
<link rel='stylesheet' id='elessi-style-crazy-css' href='https://duniafesyen.com/wp-content/themes/elessi-theme/assets/css/style-crazy-load.css' type='text/css' media='all' />
<link rel='stylesheet' id='elessi-style-large-css' href='https://duniafesyen.com/wp-content/themes/elessi-theme/assets/css/style-large.css' type='text/css' media='all' />
<link rel='stylesheet' id='elessi-style-font-weight-css' href='https://duniafesyen.com/wp-content/themes/elessi-theme/assets/css/style-font-weight-500.css' type='text/css' media='all' />
<link rel='stylesheet' id='nasa-sc-woo-css' href='https://duniafesyen.com/wp-content/plugins/nasa-core/assets/css/nasa-sc-woo.css' type='text/css' media='all' />
<link rel='stylesheet' id='nasa-sc-css' href='https://duniafesyen.com/wp-content/plugins/nasa-core/assets/css/nasa-sc.css' type='text/css' media='all' />
<link rel='stylesheet' id='elessi-style-dynamic-css' href='//duniafesyen.com/wp-content/uploads/nasa-dynamic/dynamic.css?ver=1742477331' type='text/css' media='all' />
<link rel='stylesheet' id='elementor-gf-local-jost-css' href='https://duniafesyen.com/wp-content/uploads/elementor/google-fonts/css/jost.css?ver=1742363450' type='text/css' media='all' />
<script type="text/template" id="tmpl-variation-template">
	<div class="woocommerce-variation-description">{{{ data.variation.variation_description }}}</div>
	<div class="woocommerce-variation-price">{{{ data.variation.price_html }}}</div>
	<div class="woocommerce-variation-availability">{{{ data.variation.availability_html }}}</div>
</script>
<script type="text/template" id="tmpl-unavailable-variation-template">
	<p role="alert">Sorry, this product is unavailable. Please choose a different combination.</p>
</script>
<script type="text/javascript" src="https://duniafesyen.com/wp-includes/js/jquery/jquery.min.js?ver=3.7.1" id="jquery-core-js"></script>
<script type="text/javascript" src="https://duniafesyen.com/wp-includes/js/jquery/jquery-migrate.min.js?ver=3.4.1" id="jquery-migrate-js"></script>
<script type="text/javascript" id="jquery-js-after">
/* <![CDATA[ */
!function($){"use strict";$(document).ready(function(){$(this).scrollTop()>100&&$(".hfe-scroll-to-top-wrap").removeClass("hfe-scroll-to-top-hide"),$(window).scroll(function(){$(this).scrollTop()<100?$(".hfe-scroll-to-top-wrap").fadeOut(300):$(".hfe-scroll-to-top-wrap").fadeIn(300)}),$(".hfe-scroll-to-top-wrap").on("click",function(){$("html, body").animate({scrollTop:0},300);return!1})})}(jQuery);
/* ]]> */
</script>
<script type="text/javascript" id="rac_guest_handle-js-extra">
/* <![CDATA[ */
var rac_guest_params = {"console_error":"Not a valid e-mail address","current_lang_code":"en","ajax_url":"https:\/\/duniafesyen.com\/wp-admin\/admin-ajax.php","guest_entry":"167bed13d7","is_checkout":"","is_shop":"","ajax_add_to_cart":"yes","enable_popup":"no","form_label":"Please enter your Details","first_name":"","email_address_not_valid":"Please Enter your Valid Email Address","popup_sub_header":"","enter_email_address":"Please Enter your Email Address","enter_first_name":"Please Enter your First Name","enter_phone_no":"Please Enter your Contact Number","enter_valid_phone_no":"Please Enter valid Contact Number","enter_last_name":"Please Enter your Last Name","cancel_label":"Cancel","add_to_cart_label":"Add to cart","force_guest":"no","show_guest_name":"","show_guest_contactno":"","force_guest_name":"","force_guest_contactno":"","popup_already_displayed":"no","is_cookie_already_set":"","fp_rac_popup_email":"","fp_rac_first_name":"","fp_rac_last_name":"","fp_rac_phone_no":"","fp_rac_disp_notice_check":"","fp_rac_disp_notice":"Your email will be used for sending Abandoned Cart emails","popup_disp_method":"1","popup_cookie_delay_time":"no","rac_popup_delay_nonce":"f70b54920e","show_gdpr":"","gdpr_description":"I agree that my submitted data is being collected for future follow-ups","gdpr_error":"Please Confirm the GDPR","checkout_gdpr_field":"","show_checkout_gdpr":"","gdpr_nonce":"7e9bb5d29f"};
var custom_css_btn_color = {"popupcolor":"ffffff","confirmbtncolor":"008000","cancelbtncolor":"cc2900","email_placeholder":"Enter your Email Address","fname_placeholder":"Enter your First Name","lname_placeholder":"Enter your Last Name","phone_placeholder":"Enter Your Contact Number"};
/* ]]> */
</script>
<script type="text/javascript" src="https://duniafesyen.com/wp-content/plugins/rac/assets/js/fp-rac-guest-checkout.js?ver=24.2.0" id="rac_guest_handle-js"></script>
<script type="text/javascript" src="//duniafesyen.com/wp-content/plugins/revslider/public/js/libs/tptools.js?ver=6.7.30" id="tp-tools-js" async="async" data-wp-strategy="async"></script>
<script type="text/javascript" src="//duniafesyen.com/wp-content/plugins/revslider/public/js/sr7.js?ver=6.7.30" id="sr7-js" async="async" data-wp-strategy="async"></script>
<script type="text/javascript" src="https://duniafesyen.com/wp-content/plugins/woocommerce/assets/js/jquery-blockui/jquery.blockUI.min.js?ver=2.7.0-wc.9.8.5" id="jquery-blockui-js" defer="defer" data-wp-strategy="defer"></script>
<script type="text/javascript" id="wc-add-to-cart-js-extra">
/* <![CDATA[ */
var wc_add_to_cart_params = {"ajax_url":"\/wp-admin\/admin-ajax.php","wc_ajax_url":"\/?wc-ajax=%%endpoint%%","i18n_view_cart":"View cart","cart_url":"https:\/\/duniafesyen.com\/shopping-cart\/","is_cart":"","cart_redirect_after_add":"no"};
/* ]]> */
</script>
<script type="text/javascript" src="https://duniafesyen.com/wp-content/plugins/woocommerce/assets/js/frontend/add-to-cart.min.js?ver=9.8.5" id="wc-add-to-cart-js" defer="defer" data-wp-strategy="defer"></script>
<script type="text/javascript" src="https://duniafesyen.com/wp-content/plugins/woocommerce/assets/js/js-cookie/js.cookie.min.js?ver=2.1.4-wc.9.8.5" id="js-cookie-js" defer="defer" data-wp-strategy="defer"></script>
<script type="text/javascript" id="woocommerce-js-extra">
/* <![CDATA[ */
var woocommerce_params = {"ajax_url":"\/wp-admin\/admin-ajax.php","wc_ajax_url":"\/?wc-ajax=%%endpoint%%","i18n_password_show":"Show password","i18n_password_hide":"Hide password"};
/* ]]> */
</script>
<script type="text/javascript" src="https://duniafesyen.com/wp-content/plugins/woocommerce/assets/js/frontend/woocommerce.min.js?ver=9.8.5" id="woocommerce-js" defer="defer" data-wp-strategy="defer"></script>
<script type="text/javascript" src="https://duniafesyen.com/wp-content/plugins/woocommerce/assets/js/photoswipe/photoswipe.min.js?ver=4.1.1-wc.9.8.5" id="photoswipe-js" defer="defer" data-wp-strategy="defer"></script>
<script type="text/javascript" src="https://duniafesyen.com/wp-content/plugins/woocommerce/assets/js/photoswipe/photoswipe-ui-default.min.js?ver=4.1.1-wc.9.8.5" id="photoswipe-ui-default-js" defer="defer" data-wp-strategy="defer"></script>
<script type="text/javascript" id="wc-cart-fragments-js-extra">
/* <![CDATA[ */
var wc_cart_fragments_params = {"ajax_url":"\/wp-admin\/admin-ajax.php","wc_ajax_url":"\/?wc-ajax=%%endpoint%%","cart_hash_key":"wc_cart_hash_740c2a6a2a9d6fc6e1bb60c99770b297","fragment_name":"wc_fragments_740c2a6a2a9d6fc6e1bb60c99770b297","request_timeout":"5000"};
/* ]]> */
</script>
<script type="text/javascript" src="https://duniafesyen.com/wp-content/plugins/woocommerce/assets/js/frontend/cart-fragments.min.js?ver=9.8.5" id="wc-cart-fragments-js" defer="defer" data-wp-strategy="defer"></script>
<script type="text/javascript" src="https://duniafesyen.com/wp-includes/js/underscore.min.js?ver=1.13.7" id="underscore-js"></script>
<script type="text/javascript" id="wp-util-js-extra">
/* <![CDATA[ */
var _wpUtilSettings = {"ajax":{"url":"\/wp-admin\/admin-ajax.php"}};
/* ]]> */
</script>
<script type="text/javascript" src="https://duniafesyen.com/wp-includes/js/wp-util.min.js?ver=6.8.1" id="wp-util-js"></script>
<script type="text/javascript" id="wc-add-to-cart-variation-js-extra">
/* <![CDATA[ */
var wc_add_to_cart_variation_params = {"wc_ajax_url":"\/?wc-ajax=%%endpoint%%","i18n_no_matching_variations_text":"Sorry, no products matched your selection. Please choose a different combination.","i18n_make_a_selection_text":"Please select some product options before adding this product to your cart.","i18n_unavailable_text":"Sorry, this product is unavailable. Please choose a different combination.","i18n_reset_alert_text":"Your selection has been reset. Please select some product options before adding this product to your cart."};
/* ]]> */
</script>
<script type="text/javascript" src="https://duniafesyen.com/wp-content/plugins/woocommerce/assets/js/frontend/add-to-cart-variation.min.js?ver=9.8.5" id="wc-add-to-cart-variation-js" defer="defer" data-wp-strategy="defer"></script>
<link rel="https://api.w.org/" href="https://duniafesyen.com/wp-json/" /><link rel="EditURI" type="application/rsd+xml" title="RSD" href="https://duniafesyen.com/xmlrpc.php?rsd" />
<meta name="generator" content="WordPress 6.8.1" />
	<noscript><style>.woocommerce-product-gallery{ opacity: 1 !important; }</style></noscript>
	<meta name="generator" content="Elementor 3.28.4; features: additional_custom_breakpoints, e_local_google_fonts; settings: css_print_method-external, google_font-enabled, font_display-swap">
			<style>
				.e-con.e-parent:nth-of-type(n+4):not(.e-lazyloaded):not(.e-no-lazyload),
				.e-con.e-parent:nth-of-type(n+4):not(.e-lazyloaded):not(.e-no-lazyload) * {
					background-image: none !important;
				}
				@media screen and (max-height: 1024px) {
					.e-con.e-parent:nth-of-type(n+3):not(.e-lazyloaded):not(.e-no-lazyload),
					.e-con.e-parent:nth-of-type(n+3):not(.e-lazyloaded):not(.e-no-lazyload) * {
						background-image: none !important;
					}
				}
				@media screen and (max-height: 640px) {
					.e-con.e-parent:nth-of-type(n+2):not(.e-lazyloaded):not(.e-no-lazyload),
					.e-con.e-parent:nth-of-type(n+2):not(.e-lazyloaded):not(.e-no-lazyload) * {
						background-image: none !important;
					}
				}
			</style>
			<link rel="preconnect" href="https://fonts.googleapis.com">
<link rel="preconnect" href="https://fonts.gstatic.com/" crossorigin>
<meta name="generator" content="Powered by Slider Revolution 6.7.30 - responsive, Mobile-Friendly Slider Plugin for WordPress with comfortable drag and drop interface." />
<script>
	window._tpt			??= {};
	window.SR7			??= {};
	_tpt.R				??= {};
	_tpt.R.fonts		??= {};
	_tpt.R.fonts.customFonts??= {};
	SR7.devMode			=  false;
	SR7.F 				??= {};
	SR7.G				??= {};
	SR7.LIB				??= {};
	SR7.E				??= {};
	SR7.E.gAddons		??= {};
	SR7.E.php 			??= {};
	SR7.E.nonce			= 'd386761fdc';
	SR7.E.ajaxurl		= 'https://duniafesyen.com/wp-admin/admin-ajax.php';
	SR7.E.resturl		= 'https://duniafesyen.com/wp-json/';
	SR7.E.slug_path		= 'revslider/revslider.php';
	SR7.E.slug			= 'revslider';
	SR7.E.plugin_url	= 'https://duniafesyen.com/wp-content/plugins/revslider/';
	SR7.E.wp_plugin_url = 'https://duniafesyen.com/wp-content/plugins/';
	SR7.E.revision		= '6.7.30';
	SR7.E.fontBaseUrl	= '';
	SR7.G.breakPoints 	= [1240,1024,778,480];
	SR7.E.modules 		= ['module','page','slide','layer','draw','animate','srtools','canvas','defaults','carousel','navigation','media','modifiers','migration'];
	SR7.E.libs 			= ['WEBGL'];
	SR7.E.css 			= ['csslp','cssbtns','cssfilters','cssnav','cssmedia'];
	SR7.E.resources		= {};
	SR7.JSON			??= {};
/*! Slider Revolution 7.0 - Page Processor */
!function(){"use strict";window.SR7??={},window._tpt??={},SR7.version="Slider Revolution 6.7.16",_tpt.getMobileZoom=()=>document.documentElement.clientWidth/window.innerWidth,_tpt.getWinDim=function(t){_tpt.screenHeightWithUrlBar??=window.innerHeight;let e=SR7.F?.modal?.visible&&SR7.M[SR7.F.module.getIdByAlias(SR7.F.modal.requested)];_tpt.scrollBar=window.innerWidth!==document.documentElement.clientWidth||e&&window.innerWidth!==e.c.module.clientWidth,_tpt.winW=_tpt.getMobileZoom()*window.innerWidth-(_tpt.scrollBar||"prepare"==t?_tpt.scrollBarW??_tpt.mesureScrollBar():0),_tpt.winH=_tpt.getMobileZoom()*window.innerHeight,_tpt.winWAll=document.documentElement.clientWidth},_tpt.getResponsiveLevel=function(t,e){SR7.M[e];return _tpt.closestGE(t,_tpt.winWAll)},_tpt.mesureScrollBar=function(){let t=document.createElement("div");return t.className="RSscrollbar-measure",t.style.width="100px",t.style.height="100px",t.style.overflow="scroll",t.style.position="absolute",t.style.top="-9999px",document.body.appendChild(t),_tpt.scrollBarW=t.offsetWidth-t.clientWidth,document.body.removeChild(t),_tpt.scrollBarW},_tpt.loadCSS=async function(t,e,s){return s?_tpt.R.fonts.required[e].status=1:(_tpt.R[e]??={},_tpt.R[e].status=1),new Promise(((i,n)=>{if(_tpt.isStylesheetLoaded(t))s?_tpt.R.fonts.required[e].status=2:_tpt.R[e].status=2,i();else{const o=document.createElement("link");o.rel="stylesheet";let l="text",r="css";o["type"]=l+"/"+r,o.href=t,o.onload=()=>{s?_tpt.R.fonts.required[e].status=2:_tpt.R[e].status=2,i()},o.onerror=()=>{s?_tpt.R.fonts.required[e].status=3:_tpt.R[e].status=3,n(new Error(`Failed to load CSS: ${t}`))},document.head.appendChild(o)}}))},_tpt.addContainer=function(t){const{tag:e="div",id:s,class:i,datas:n,textContent:o,iHTML:l}=t,r=document.createElement(e);if(s&&""!==s&&(r.id=s),i&&""!==i&&(r.className=i),n)for(const[t,e]of Object.entries(n))"style"==t?r.style.cssText=e:r.setAttribute(`data-${t}`,e);return o&&(r.textContent=o),l&&(r.innerHTML=l),r},_tpt.collector=function(){return{fragment:new DocumentFragment,add(t){var e=_tpt.addContainer(t);return this.fragment.appendChild(e),e},append(t){t.appendChild(this.fragment)}}},_tpt.isStylesheetLoaded=function(t){let e=t.split("?")[0];return Array.from(document.querySelectorAll('link[rel="stylesheet"], link[rel="preload"]')).some((t=>t.href.split("?")[0]===e))},_tpt.preloader={requests:new Map,preloaderTemplates:new Map,show:function(t,e){if(!e||!t)return;const{type:s,color:i}=e;if(s<0||"off"==s)return;const n=`preloader_${s}`;let o=this.preloaderTemplates.get(n);o||(o=this.build(s,i),this.preloaderTemplates.set(n,o)),this.requests.has(t)||this.requests.set(t,{count:0});const l=this.requests.get(t);clearTimeout(l.timer),l.count++,1===l.count&&(l.timer=setTimeout((()=>{l.preloaderClone=o.cloneNode(!0),l.anim&&l.anim.kill(),void 0!==_tpt.gsap?l.anim=_tpt.gsap.fromTo(l.preloaderClone,1,{opacity:0},{opacity:1}):l.preloaderClone.classList.add("sr7-fade-in"),t.appendChild(l.preloaderClone)}),150))},hide:function(t){if(!this.requests.has(t))return;const e=this.requests.get(t);e.count--,e.count<0&&(e.count=0),e.anim&&e.anim.kill(),0===e.count&&(clearTimeout(e.timer),e.preloaderClone&&(e.preloaderClone.classList.remove("sr7-fade-in"),e.anim=_tpt.gsap.to(e.preloaderClone,.3,{opacity:0,onComplete:function(){e.preloaderClone.remove()}})))},state:function(t){if(!this.requests.has(t))return!1;return this.requests.get(t).count>0},build:(t,e="#ffffff",s="")=>{if(t<0||"off"===t)return null;const i=parseInt(t);if(t="prlt"+i,isNaN(i))return null;if(_tpt.loadCSS(SR7.E.plugin_url+"public/css/preloaders/t"+i+".css","preloader_"+t),isNaN(i)||i<6){const n=`background-color:${e}`,o=1===i||2==i?n:"",l=3===i||4==i?n:"",r=_tpt.collector();["dot1","dot2","bounce1","bounce2","bounce3"].forEach((t=>r.add({tag:"div",class:t,datas:{style:l}})));const d=_tpt.addContainer({tag:"sr7-prl",class:`${t} ${s}`,datas:{style:o}});return r.append(d),d}{let n={};if(7===i){let t;e.startsWith("#")?(t=e.replace("#",""),t=`rgba(${parseInt(t.substring(0,2),16)}, ${parseInt(t.substring(2,4),16)}, ${parseInt(t.substring(4,6),16)}, `):e.startsWith("rgb")&&(t=e.slice(e.indexOf("(")+1,e.lastIndexOf(")")).split(",").map((t=>t.trim())),t=`rgba(${t[0]}, ${t[1]}, ${t[2]}, `),t&&(n.style=`border-top-color: ${t}0.65); border-bottom-color: ${t}0.15); border-left-color: ${t}0.65); border-right-color: ${t}0.15)`)}else 12===i&&(n.style=`background:${e}`);const o=[10,0,4,2,5,9,0,4,4,2][i-6],l=_tpt.collector(),r=l.add({tag:"div",class:"sr7-prl-inner",datas:n});Array.from({length:o}).forEach((()=>r.appendChild(l.add({tag:"span",datas:{style:`background:${e}`}}))));const d=_tpt.addContainer({tag:"sr7-prl",class:`${t} ${s}`});return l.append(d),d}}},SR7.preLoader={show:(t,e)=>{"off"!==(SR7.M[t]?.settings?.pLoader?.type??"off")&&_tpt.preloader.show(e||SR7.M[t].c.module,SR7.M[t]?.settings?.pLoader??{color:"#fff",type:10})},hide:(t,e)=>{"off"!==(SR7.M[t]?.settings?.pLoader?.type??"off")&&_tpt.preloader.hide(e||SR7.M[t].c.module)},state:(t,e)=>_tpt.preloader.state(e||SR7.M[t].c.module)},_tpt.prepareModuleHeight=function(t){window.SR7.M??={},window.SR7.M[t.id]??={},"ignore"==t.googleFont&&(SR7.E.ignoreGoogleFont=!0);let e=window.SR7.M[t.id];if(null==_tpt.scrollBarW&&_tpt.mesureScrollBar(),e.c??={},e.states??={},e.settings??={},e.settings.size??={},t.fixed&&(e.settings.fixed=!0),e.c.module=document.querySelector("sr7-module#"+t.id),e.c.adjuster=e.c.module.getElementsByTagName("sr7-adjuster")[0],e.c.content=e.c.module.getElementsByTagName("sr7-content")[0],"carousel"==t.type&&(e.c.carousel=e.c.content.getElementsByTagName("sr7-carousel")[0]),null==e.c.module||null==e.c.module)return;t.plType&&t.plColor&&(e.settings.pLoader={type:t.plType,color:t.plColor}),void 0===t.plType||"off"===t.plType||SR7.preLoader.state(t.id)&&SR7.preLoader.state(t.id,e.c.module)||SR7.preLoader.show(t.id,e.c.module),_tpt.winW||_tpt.getWinDim("prepare"),_tpt.getWinDim();let s=""+e.c.module.dataset?.modal;"modal"==s||"true"==s||"undefined"!==s&&"false"!==s||(e.settings.size.fullWidth=t.size.fullWidth,e.LEV??=_tpt.getResponsiveLevel(window.SR7.G.breakPoints,t.id),t.vpt=_tpt.fillArray(t.vpt,5),e.settings.vPort=t.vpt[e.LEV],void 0!==t.el&&"720"==t.el[4]&&t.gh[4]!==t.el[4]&&"960"==t.el[3]&&t.gh[3]!==t.el[3]&&"768"==t.el[2]&&t.gh[2]!==t.el[2]&&delete t.el,e.settings.size.height=null==t.el||null==t.el[e.LEV]||0==t.el[e.LEV]||"auto"==t.el[e.LEV]?_tpt.fillArray(t.gh,5,-1):_tpt.fillArray(t.el,5,-1),e.settings.size.width=_tpt.fillArray(t.gw,5,-1),e.settings.size.minHeight=_tpt.fillArray(t.mh??[0],5,-1),e.cacheSize={fullWidth:e.settings.size?.fullWidth,fullHeight:e.settings.size?.fullHeight},void 0!==t.off&&(t.off?.t&&(e.settings.size.m??={})&&(e.settings.size.m.t=t.off.t),t.off?.b&&(e.settings.size.m??={})&&(e.settings.size.m.b=t.off.b),t.off?.l&&(e.settings.size.p??={})&&(e.settings.size.p.l=t.off.l),t.off?.r&&(e.settings.size.p??={})&&(e.settings.size.p.r=t.off.r),e.offsetPrepared=!0),_tpt.updatePMHeight(t.id,t,!0))},_tpt.updatePMHeight=(t,e,s)=>{let i=SR7.M[t];var n=i.settings.size.fullWidth?_tpt.winW:i.c.module.parentNode.offsetWidth;n=0===n||isNaN(n)?_tpt.winW:n;let o=i.settings.size.width[i.LEV]||i.settings.size.width[i.LEV++]||i.settings.size.width[i.LEV--]||n,l=i.settings.size.height[i.LEV]||i.settings.size.height[i.LEV++]||i.settings.size.height[i.LEV--]||0,r=i.settings.size.minHeight[i.LEV]||i.settings.size.minHeight[i.LEV++]||i.settings.size.minHeight[i.LEV--]||0;if(l="auto"==l?0:l,l=parseInt(l),"carousel"!==e.type&&(n-=parseInt(e.onw??0)||0),i.MP=!i.settings.size.fullWidth&&n<o||_tpt.winW<o?Math.min(1,n/o):1,e.size.fullScreen||e.size.fullHeight){let t=parseInt(e.fho)||0,s=(""+e.fho).indexOf("%")>-1;e.newh=_tpt.winH-(s?_tpt.winH*t/100:t)}else e.newh=i.MP*Math.max(l,r);if(e.newh+=(parseInt(e.onh??0)||0)+(parseInt(e.carousel?.pt)||0)+(parseInt(e.carousel?.pb)||0),void 0!==e.slideduration&&(e.newh=Math.max(e.newh,parseInt(e.slideduration)/3)),e.shdw&&_tpt.buildShadow(e.id,e),i.c.adjuster.style.height=e.newh+"px",i.c.module.style.height=e.newh+"px",i.c.content.style.height=e.newh+"px",i.states.heightPrepared=!0,i.dims??={},i.dims.moduleRect=i.c.module.getBoundingClientRect(),i.c.content.style.left="-"+i.dims.moduleRect.left+"px",!i.settings.size.fullWidth)return s&&requestAnimationFrame((()=>{n!==i.c.module.parentNode.offsetWidth&&_tpt.updatePMHeight(e.id,e)})),void _tpt.bgStyle(e.id,e,window.innerWidth==_tpt.winW,!0);_tpt.bgStyle(e.id,e,window.innerWidth==_tpt.winW,!0),requestAnimationFrame((function(){s&&requestAnimationFrame((()=>{n!==i.c.module.parentNode.offsetWidth&&_tpt.updatePMHeight(e.id,e)}))})),i.earlyResizerFunction||(i.earlyResizerFunction=function(){requestAnimationFrame((function(){_tpt.getWinDim(),_tpt.moduleDefaults(e.id,e),_tpt.updateSlideBg(t,!0)}))},window.addEventListener("resize",i.earlyResizerFunction))},_tpt.buildShadow=function(t,e){let s=SR7.M[t];null==s.c.shadow&&(s.c.shadow=document.createElement("sr7-module-shadow"),s.c.shadow.classList.add("sr7-shdw-"+e.shdw),s.c.content.appendChild(s.c.shadow))},_tpt.bgStyle=async(t,e,s,i,n)=>{const o=SR7.M[t];if((e=e??o.settings).fixed&&!o.c.module.classList.contains("sr7-top-fixed")&&(o.c.module.classList.add("sr7-top-fixed"),o.c.module.style.position="fixed",o.c.module.style.width="100%",o.c.module.style.top="0px",o.c.module.style.left="0px",o.c.module.style.pointerEvents="none",o.c.module.style.zIndex=5e3,o.c.content.style.pointerEvents="none"),null==o.c.bgcanvas){let t=document.createElement("sr7-module-bg"),l=!1;if("string"==typeof e?.bg?.color&&e?.bg?.color.includes("{"))if(_tpt.gradient&&_tpt.gsap)e.bg.color=_tpt.gradient.convert(e.bg.color);else try{let t=JSON.parse(e.bg.color);(t?.orig||t?.string)&&(e.bg.color=JSON.parse(e.bg.color))}catch(t){return}let r="string"==typeof e?.bg?.color?e?.bg?.color||"transparent":e?.bg?.color?.string??e?.bg?.color?.orig??e?.bg?.color?.color??"transparent";if(t.style["background"+(String(r).includes("grad")?"":"Color")]=r,("transparent"!==r||n)&&(l=!0),o.offsetPrepared&&(t.style.visibility="hidden"),e?.bg?.image?.src&&(t.style.backgroundImage=`url(${e?.bg?.image.src})`,t.style.backgroundSize=""==(e.bg.image?.size??"")?"cover":e.bg.image.size,t.style.backgroundPosition=e.bg.image.position,t.style.backgroundRepeat=""==e.bg.image.repeat||null==e.bg.image.repeat?"no-repeat":e.bg.image.repeat,l=!0),!l)return;o.c.bgcanvas=t,e.size.fullWidth?t.style.width=_tpt.winW-(s&&_tpt.winH<document.body.offsetHeight?_tpt.scrollBarW:0)+"px":i&&(t.style.width=o.c.module.offsetWidth+"px"),e.sbt?.use?o.c.content.appendChild(o.c.bgcanvas):o.c.module.appendChild(o.c.bgcanvas)}o.c.bgcanvas.style.height=void 0!==e.newh?e.newh+"px":("carousel"==e.type?o.dims.module.h:o.dims.content.h)+"px",o.c.bgcanvas.style.left=!s&&e.sbt?.use||o.c.bgcanvas.closest("SR7-CONTENT")?"0px":"-"+(o?.dims?.moduleRect?.left??0)+"px"},_tpt.updateSlideBg=function(t,e){const s=SR7.M[t];let i=s.settings;s?.c?.bgcanvas&&(i.size.fullWidth?s.c.bgcanvas.style.width=_tpt.winW-(e&&_tpt.winH<document.body.offsetHeight?_tpt.scrollBarW:0)+"px":preparing&&(s.c.bgcanvas.style.width=s.c.module.offsetWidth+"px"))},_tpt.moduleDefaults=(t,e)=>{let s=SR7.M[t];null!=s&&null!=s.c&&null!=s.c.module&&(s.dims??={},s.dims.moduleRect=s.c.module.getBoundingClientRect(),s.c.content.style.left="-"+s.dims.moduleRect.left+"px",s.c.content.style.width=_tpt.winW-_tpt.scrollBarW+"px","carousel"==e.type&&(s.c.module.style.overflow="visible"),_tpt.bgStyle(t,e,window.innerWidth==_tpt.winW))},_tpt.getOffset=t=>{var e=t.getBoundingClientRect(),s=window.pageXOffset||document.documentElement.scrollLeft,i=window.pageYOffset||document.documentElement.scrollTop;return{top:e.top+i,left:e.left+s}},_tpt.fillArray=function(t,e){let s,i;t=Array.isArray(t)?t:[t];let n=Array(e),o=t.length;for(i=0;i<t.length;i++)n[i+(e-o)]=t[i],null==s&&"#"!==t[i]&&(s=t[i]);for(let t=0;t<e;t++)void 0!==n[t]&&"#"!=n[t]||(n[t]=s),s=n[t];return n},_tpt.closestGE=function(t,e){let s=Number.MAX_VALUE,i=-1;for(let n=0;n<t.length;n++)t[n]-1>=e&&t[n]-1-e<s&&(s=t[n]-1-e,i=n);return++i}}();</script>
</head>
<body class="error404 wp-theme-elessi-theme wp-child-theme-elessi-theme-child theme-elessi-theme nasa-core-actived nasa-woo-actived woocommerce-demo-store woocommerce-no-js ehf-template-elessi-theme ehf-stylesheet-elessi-theme-child antialiased group-blog nasa-quickview-on nasa-crazy-load crazy-loading nasa-label-attr-single nasa-image-round elementor-default elementor-kit-7">

<!-- Start Wrapper Site -->
<div id="wrapper">

<!-- Start Header Site -->
<header id="header-content" class=" site-header nasa-header-sticky-wrap ns-has-topbar">

<div class="header-wrapper header-type-1 nasa-header-sticky">
    <div class="nasa-topbar-wrap">
    <div id="top-bar" class="top-bar">
                    <!-- Desktop | Responsive Top-bar -->
            <div class="row">
                <div class="large-12 columns">
                    <div class="left-text left rtl-right">
                        <span class="nasa-flex jc"><i class="pe7-icon pe-7s-news-paper"></i>&nbsp;Dashboard &nbsp;<i class="fa fa-angle-right"></i>&nbsp; Static Blocks &nbsp;<i class="fa fa-angle-right"></i>&nbsp; Topbar</span>                    </div>
                    <div class="right-text nasa-hide-for-mobile right rtl-left">
                        <div class="topbar-menu-container">
                            <ul class="nasa-menus-account"><li class="menu-item"><a class="nasa-login-register-ajax inline-block" data-enable="1" href="https://duniafesyen.com/my-account/" title="Login / Register"><svg width="24" height="24" viewBox="0 0 32 32" fill="currentColor"><path d="M16 3.205c-7.067 0-12.795 5.728-12.795 12.795s5.728 12.795 12.795 12.795 12.795-5.728 12.795-12.795c0-7.067-5.728-12.795-12.795-12.795zM16 4.271c6.467 0 11.729 5.261 11.729 11.729 0 2.845-1.019 5.457-2.711 7.49-1.169-0.488-3.93-1.446-5.638-1.951-0.146-0.046-0.169-0.053-0.169-0.66 0-0.501 0.206-1.005 0.407-1.432 0.218-0.464 0.476-1.244 0.569-1.944 0.259-0.301 0.612-0.895 0.839-2.026 0.199-0.997 0.106-1.36-0.026-1.7-0.014-0.036-0.028-0.071-0.039-0.107-0.050-0.234 0.019-1.448 0.189-2.391 0.118-0.647-0.030-2.022-0.921-3.159-0.562-0.719-1.638-1.601-3.603-1.724l-1.078 0.001c-1.932 0.122-3.008 1.004-3.57 1.723-0.89 1.137-1.038 2.513-0.92 3.159 0.172 0.943 0.239 2.157 0.191 2.387-0.010 0.040-0.025 0.075-0.040 0.111-0.131 0.341-0.225 0.703-0.025 1.7 0.226 1.131 0.579 1.725 0.839 2.026 0.092 0.7 0.35 1.48 0.569 1.944 0.159 0.339 0.234 0.801 0.234 1.454 0 0.607-0.023 0.614-0.159 0.657-1.767 0.522-4.579 1.538-5.628 1.997-1.725-2.042-2.768-4.679-2.768-7.555 0-6.467 5.261-11.729 11.729-11.729zM7.811 24.386c1.201-0.49 3.594-1.344 5.167-1.808 0.914-0.288 0.914-1.058 0.914-1.677 0-0.513-0.035-1.269-0.335-1.908-0.206-0.438-0.442-1.189-0.494-1.776-0.011-0.137-0.076-0.265-0.18-0.355-0.151-0.132-0.458-0.616-0.654-1.593-0.155-0.773-0.089-0.942-0.026-1.106 0.027-0.070 0.053-0.139 0.074-0.216 0.128-0.468-0.015-2.005-0.17-2.858-0.068-0.371 0.018-1.424 0.711-2.311 0.622-0.795 1.563-1.238 2.764-1.315l1.011-0.001c1.233 0.078 2.174 0.521 2.797 1.316 0.694 0.887 0.778 1.94 0.71 2.312-0.154 0.852-0.298 2.39-0.17 2.857 0.022 0.078 0.047 0.147 0.074 0.217 0.064 0.163 0.129 0.333-0.025 1.106-0.196 0.977-0.504 1.461-0.655 1.593-0.103 0.091-0.168 0.218-0.18 0.355-0.051 0.588-0.286 1.338-0.492 1.776-0.236 0.502-0.508 1.171-0.508 1.886 0 0.619 0 1.389 0.924 1.68 1.505 0.445 3.91 1.271 5.18 1.77-2.121 2.1-5.035 3.4-8.248 3.4-3.183 0-6.073-1.277-8.188-3.342z"/></svg>&nbsp;<span class="nasa-login-title">Login / Register</span></a></li></ul>                        </div>
                    </div>
                </div>
            </div>
            </div>
    
            <div class="nasa-hide-for-mobile">
            <a class="nasa-icon-toggle" href="javascript:void(0);" rel="nofollow">
                <svg class="nasa-topbar-up" width="26" height="26" viewBox="0 0 32 32">
                    <path d="M16.767 12.809l-0.754-0.754-6.035 6.035 0.754 0.754 5.281-5.281 5.256 5.256 0.754-0.754-3.013-3.013z" fill="currentColor" />
                </svg>

                <svg class="nasa-topbar-down" width="26" height="26" viewBox="0 0 32 32">
                    <path d="M15.233 19.175l0.754 0.754 6.035-6.035-0.754-0.754-5.281 5.281-5.256-5.256-0.754 0.754 3.013 3.013z" fill="currentColor" />
                </svg>
            </a>
        </div>
    </div>
    
    <div class="sticky-wrapper">
        <div id="masthead" class="site-header">
                        
            <div class="row">
                <div class="large-12 columns header-container">
                    <div class="nasa-hide-for-mobile nasa-wrap-event-search">
                        <div class="nasa-relative nasa-header-flex nasa-elements-wrap nasa-wrap-width-main-menu jbw">
                            <!-- Logo -->
                            <div class="order-1 logo-wrapper">
                                <a class="logo nasa-logo-retina nasa-has-sticky-logo nasa-has-mobile-logo" href="https://duniafesyen.com/" title="Dunia Fesyen - Info Terkini Fesyen" rel="Home"><img src="//duniafesyen-media.s3.ap-southeast-1.amazonaws.com/wp-content/uploads/2025/03/03181633/Dunia-Fesyen-Logo.png" alt="Dunia Fesyen" class="header_logo" srcset="//duniafesyen-media.s3.ap-southeast-1.amazonaws.com/wp-content/uploads/2025/03/03181633/Dunia-Fesyen-Logo.png 1x, //duniafesyen-media.s3.ap-southeast-1.amazonaws.com/wp-content/uploads/2025/03/03181554/DF-Logo-Retina.png 2x" /><img src="//duniafesyen-media.s3.ap-southeast-1.amazonaws.com/wp-content/uploads/2025/03/03181633/Dunia-Fesyen-Logo.png" alt="Dunia Fesyen" class="header_logo logo_sticky" /><img src="//duniafesyen-media.s3.ap-southeast-1.amazonaws.com/wp-content/uploads/2025/03/03181633/Dunia-Fesyen-Logo.png" alt="Dunia Fesyen" class="header_logo logo_mobile" /></a>                            </div>
                            
                            <!-- Group icon header -->
                            <div class="order-3 icons-wrapper">
                                <div class="nasa-header-icons-wrap"><ul class="header-icons"><li class="first nasa-icon-mini-cart"><a href="https://duniafesyen.com/shopping-cart/" class="cart-link mini-cart cart-inner nasa-flex jc" title="Cart" rel="nofollow"><span class="icon-wrap"><svg class="nasa-icon cart-icon nasa-icon-1" width="28" height="28" viewBox="0 0 32 32" fill="currentColor"><path d="M3.205 3.205v25.59h25.59v-25.59h-25.59zM27.729 27.729h-23.457v-23.457h23.457v23.457z" /><path d="M9.068 13.334c0 3.828 3.104 6.931 6.931 6.931s6.93-3.102 6.93-6.931v-3.732h1.067v-1.066h-3.199v1.066h1.065v3.732c0 3.234-2.631 5.864-5.864 5.864-3.234 0-5.865-2.631-5.865-5.864v-3.732h1.067v-1.066h-3.199v1.066h1.065v3.732z"/></svg><span class="nasa-cart-count nasa-mini-number cart-number hidden-tag nasa-product-empty">0</span></span><span class="icon-text hidden-tag">Cart</span></a></li><li class="nasa-icon-wishlist"><a class="wishlist-link nasa-wishlist-link nasa-flex" href="javascript:void(0);" title="Wishlist" rel="nofollow"><span class="icon-wrap"><svg class="nasa-icon wishlist-icon" width="28" height="28" viewBox="0 0 32 32"><path d="M21.886 5.115c3.521 0 6.376 2.855 6.376 6.376 0 1.809-0.754 3.439-1.964 4.6l-10.297 10.349-10.484-10.536c-1.1-1.146-1.778-2.699-1.778-4.413 0-3.522 2.855-6.376 6.376-6.376 2.652 0 4.925 1.62 5.886 3.924 0.961-2.304 3.234-3.924 5.886-3.924zM21.886 4.049c-2.345 0-4.499 1.089-5.886 2.884-1.386-1.795-3.54-2.884-5.886-2.884-4.104 0-7.442 3.339-7.442 7.442 0 1.928 0.737 3.758 2.075 5.152l11.253 11.309 11.053-11.108c1.46-1.402 2.275-3.308 2.275-5.352 0-4.104-3.339-7.442-7.442-7.442v0z" fill="currentColor" /></svg><span class="nasa-wishlist-count nasa-mini-number wishlist-number nasa-product-empty">0</span></span><span class="icon-text hidden-tag">Wishlist</span></a></li><li class="nasa-icon-compare"><a href="https://duniafesyen.com/" title="Compare" class="nasa-show-compare nasa-flex"><span class="icon-wrap"><svg class="nasa-flip-vertical nasa-icon compare-icon" viewBox="0 30 512 512" width="28" height="28" fill="currentColor"><path d="M276 467c0 8 6 21-2 23l-26 0c-128-7-230-143-174-284 5-13 13-23 16-36-18 0-41 23-54 5 5-15 25-18 41-23 15-5 36-7 48-15-2 10 23 95 6 100-21 5-13-39-18-57-8-5-8 8-11 13-71 126 29 297 174 274z m44 13c-8 0-10 5-20 3 0-6-3-13-3-18 5-3 13-3 18-5 2 7 5 15 5 20z m38-18c-5 3-10 8-18 10-2-7-5-12-7-18 5-2 10-7 18-7 2 5 7 7 7 15z m34-31c0-33-18-71-5-99 23 2 12 38 17 58 90-117-7-314-163-289 0-8-3-10-3-20 131-5 233 84 220 225-2 36-20 66-30 92 12 0 51-26 53-2 3 17-82 28-89 35z m-233-325c5-2 13-5 18-10 0 8 5 10 7 18-5 2-10 8-18 8 0-8-7-8-7-16z m38-18c8 0 10-5 21-5 0 5 2 13 2 18-5 3-13 3-18 5 0-5-5-10-5-18z"/></svg><span class="nasa-compare-count nasa-mini-number compare-number nasa-product-empty">0</span></span><span class="icon-text hidden-tag">Compare</span></a></li><li class="nasa-icon-search nasa-hide-for-mobile"><a class="search-icon desk-search nasa-flex" href="javascript:void(0);" data-open="0" title="Search" rel="nofollow"><svg class="nasa-icon nasa-search" fill="currentColor" viewBox="0 0 80 80" width="22" height="22"><path d="M74.3,72.2L58.7,56.5C69.9,44,69,24.8,56.5,13.5s-31.7-10.3-43,2.2s-10.3,31.7,2.2,43c11.6,10.5,29.3,10.5,40.9,0 l15.7,15.7L74.3,72.2z M36.1,63.5c-15.1,0-27.4-12.3-27.4-27.4C8.7,20.9,21,8.7,36.1,8.7c15.1,0,27.4,12.3,27.4,27.4 C63.5,51.2,51.2,63.5,36.1,63.5z"/><path d="M36.1,12.8v3c11.2,0,20.3,9.1,20.3,20.3h3C59.4,23.2,49,12.8,36.1,12.8z"/></svg></a></li></ul></div>                            </div>
                            
                            <!-- Main menu -->
                            <div class="wide-nav fgr-2 order-2 fjct nasa-bg-wrap nasa-nav-style-1">
                                <div class="nasa-menus-wrapper nasa-menus-wrapper-reponsive nasa-loading" data-padding_x="35">
                                    <div class="nav-wrapper main-menu-warpper"><ul id="site-navigation" class="header-nav nasa-to-menu-mobile nasa-main-menu"><li class="menu-item menu-item-type-custom menu-item-object-custom default-menu root-item nasa_even"><a title="HOME" href="#" class="nasa-title-menu"><svg class="nasa-open-child" width="20" height="20" viewBox="0 0 32 32" fill="currentColor"><path d="M15.233 19.175l0.754 0.754 6.035-6.035-0.754-0.754-5.281 5.281-5.256-5.256-0.754 0.754 3.013 3.013z" /></svg>HOME</a></li>
<li class="menu-item menu-item-type-custom menu-item-object-custom default-menu root-item nasa_odd"><a title="SHOP" href="#" class="nasa-title-menu"><svg class="nasa-open-child" width="20" height="20" viewBox="0 0 32 32" fill="currentColor"><path d="M15.233 19.175l0.754 0.754 6.035-6.035-0.754-0.754-5.281 5.281-5.256-5.256-0.754 0.754 3.013 3.013z" /></svg>SHOP</a></li>
<li class="menu-item menu-item-type-custom menu-item-object-custom default-menu root-item nasa_even"><a title="ELEMENTS" href="#" class="nasa-title-menu"><svg class="nasa-open-child" width="20" height="20" viewBox="0 0 32 32" fill="currentColor"><path d="M15.233 19.175l0.754 0.754 6.035-6.035-0.754-0.754-5.281 5.281-5.256-5.256-0.754 0.754 3.013 3.013z" /></svg>ELEMENTS</a></li>
<li class="menu-item menu-item-type-custom menu-item-object-custom default-menu root-item nasa_odd"><a title="BLOGS" href="#" class="nasa-title-menu"><svg class="nasa-open-child" width="20" height="20" viewBox="0 0 32 32" fill="currentColor"><path d="M15.233 19.175l0.754 0.754 6.035-6.035-0.754-0.754-5.281 5.281-5.256-5.256-0.754 0.754 3.013 3.013z" /></svg>BLOGS</a></li>
<li class="menu-item menu-item-type-custom menu-item-object-custom default-menu root-item nasa_even"><a title="CONTACT US" href="#" class="nasa-title-menu"><svg class="nasa-open-child" width="20" height="20" viewBox="0 0 32 32" fill="currentColor"><path d="M15.233 19.175l0.754 0.754 6.035-6.035-0.754-0.754-5.281 5.281-5.256-5.256-0.754 0.754 3.013 3.013z" /></svg>CONTACT US</a></li>
</ul></div><!-- nav-wrapper -->                                </div>
                            </div>
                        </div>

                        <!-- Search form in header -->
                        <div class="nasa-header-search-wrap nasa-hide-for-mobile">
                            <div class="nasa-search-space nasa-search-icon"><div class="nasa-show-search-form nasa-over-hide nasa-rightToLeft nasa-modern-layout">
    <div class="search-wrapper nasa-ajax-search-form-container modern">
                    <form role="search" method="get" class="nasa-search nasa-ajax-search-form" action="https://duniafesyen.com/">
                <label for="nasa-input-1" class="hidden-tag">
                    Search here                </label>

                <input type="text" name="s" id="nasa-input-1" class="search-field search-input live-search-input" value="" placeholder="I&#039;m shopping for ..." data-suggestions="Sweater, Jacket, Shirt ..." />
                
                                    <div class="ns-popular-keys-wrap hidden-tag">
                        <span class="ns-popular-keys">
                            <span class="ns-label">
                                Popular Searches:                            </span>

                                                            <a class="nasa-bold ns-popular-keyword" href="javascript:void(0);" rel="nofollow" data-word="Sweater">
                                    Sweater                                </a>
                                                            <a class="nasa-bold ns-popular-keyword" href="javascript:void(0);" rel="nofollow" data-word="Jacket">
                                    Jacket                                </a>
                                                            <a class="nasa-bold ns-popular-keyword" href="javascript:void(0);" rel="nofollow" data-word="Shirt">
                                    Shirt                                </a>
                                                    </span>
                    </div>
                
                <span class="nasa-icon-submit-page">
                    <svg viewBox="0 0 80 80" width="26" height="26" fill="currentColor"><path d="M74.3,72.2L58.7,56.5C69.9,44,69,24.8,56.5,13.5s-31.7-10.3-43,2.2s-10.3,31.7,2.2,43c11.6,10.5,29.3,10.5,40.9,0 l15.7,15.7L74.3,72.2z M36.1,63.5c-15.1,0-27.4-12.3-27.4-27.4C8.7,20.9,21,8.7,36.1,8.7c15.1,0,27.4,12.3,27.4,27.4 C63.5,51.2,51.2,63.5,36.1,63.5z" /><path d="M36.1,12.8v3c11.2,0,20.3,9.1,20.3,20.3h3C59.4,23.2,49,12.8,36.1,12.8z" /></svg>
                    
                    <button class="nasa-submit-search hidden-tag">
                        Search                        <svg viewBox="0 0 80 80" width="25" height="25" fill="currentColor"><path d="M74.3,72.2L58.7,56.5C69.9,44,69,24.8,56.5,13.5s-31.7-10.3-43,2.2s-10.3,31.7,2.2,43c11.6,10.5,29.3,10.5,40.9,0 l15.7,15.7L74.3,72.2z M36.1,63.5c-15.1,0-27.4-12.3-27.4-27.4C8.7,20.9,21,8.7,36.1,8.7c15.1,0,27.4,12.3,27.4,27.4 C63.5,51.2,51.2,63.5,36.1,63.5z" /><path d="M36.1,12.8v3c11.2,0,20.3,9.1,20.3,20.3h3C59.4,23.2,49,12.8,36.1,12.8z" /></svg>
                    </button>
                </span>

                                    <input type="hidden" name="post_type" value="product" />
                            </form>
                
        <a href="javascript:void(0);" title="Close search" class="nasa-close-search nasa-stclose" rel="nofollow"></a>
    </div>

</div></div>                        </div>
                    </div>
                </div>
            </div>
            
                    </div>
    </div>
</div>
</header>
<!-- End Header Site -->

<!-- Start Main Content Site -->
<main id="main-content" class="site-main light nasa-after-clear">

<div class="container-wrap">
    <div class="row">
        <div class="large-12 left columns">
            <article id="post-0" class="post error404 not-found text-center">
                <header class="entry-header">
                    <img src="https://duniafesyen.com/wp-content/themes/elessi-theme/assets/images/404.png" alt="404" />
                    <h1 class="entry-title">Oops! That page can&rsquo;t be found.</h1>
                </header><!-- .entry-header -->
                
                <div class="entry-content">
                    <p>Sorry, but the page you are looking for is not found. Please, make sure you have typed the current URL.</p>
                    
                    
    <div class="search-wrapper nasa-search-form-container">
                    <form role="search" method="get" class="nasa-search nasa-search-form" action="https://duniafesyen.com/">
                <label for="nasa-input-2" class="hidden-tag">
                    Search here                </label>

                <input type="text" name="s" id="nasa-input-2" class="search-field search-input" value="" placeholder="Start typing ..." />
                
                
                <span class="nasa-icon-submit-page">
                    <svg viewBox="0 0 80 80" width="26" height="26" fill="currentColor"><path d="M74.3,72.2L58.7,56.5C69.9,44,69,24.8,56.5,13.5s-31.7-10.3-43,2.2s-10.3,31.7,2.2,43c11.6,10.5,29.3,10.5,40.9,0 l15.7,15.7L74.3,72.2z M36.1,63.5c-15.1,0-27.4-12.3-27.4-27.4C8.7,20.9,21,8.7,36.1,8.7c15.1,0,27.4,12.3,27.4,27.4 C63.5,51.2,51.2,63.5,36.1,63.5z" /><path d="M36.1,12.8v3c11.2,0,20.3,9.1,20.3,20.3h3C59.4,23.2,49,12.8,36.1,12.8z" /></svg>
                    
                    <button class="nasa-submit-search hidden-tag">
                        Search                        <svg viewBox="0 0 80 80" width="25" height="25" fill="currentColor"><path d="M74.3,72.2L58.7,56.5C69.9,44,69,24.8,56.5,13.5s-31.7-10.3-43,2.2s-10.3,31.7,2.2,43c11.6,10.5,29.3,10.5,40.9,0 l15.7,15.7L74.3,72.2z M36.1,63.5c-15.1,0-27.4-12.3-27.4-27.4C8.7,20.9,21,8.7,36.1,8.7c15.1,0,27.4,12.3,27.4,27.4 C63.5,51.2,51.2,63.5,36.1,63.5z" /><path d="M36.1,12.8v3c11.2,0,20.3,9.1,20.3,20.3h3C59.4,23.2,49,12.8,36.1,12.8z" /></svg>
                    </button>
                </span>

                                    <input type="hidden" name="post_type" value="post" />
                            </form>
                
        <a href="javascript:void(0);" title="Close search" class="nasa-close-search nasa-stclose" rel="nofollow"></a>
    </div>

                    
                    <a class="button medium" href="https://duniafesyen.com/">
                        GO TO HOME                    </a>
                </div>
            </article>
        </div>
    </div>
</div>

</main>
<!-- End Main Content Site -->

<!-- MAIN FOOTER --><footer id="nasa-footer" class="footer-wrapper nasa-clear-both">		<div data-elementor-type="wp-post" data-elementor-id="3702" class="elementor elementor-3702">
						<section class="elementor-section elementor-top-section elementor-element elementor-element-6a1329c6 footer-light-2 elementor-section-boxed elementor-section-height-default elementor-section-height-default" data-id="6a1329c6" data-element_type="section" data-settings="{&quot;background_background&quot;:&quot;classic&quot;}">
						<div class="elementor-container elementor-column-gap-default">
					<div class="elementor-column elementor-col-50 elementor-top-column elementor-element elementor-element-fb4661b" data-id="fb4661b" data-element_type="column">
			<div class="elementor-widget-wrap elementor-element-populated">
						<section class="elementor-section elementor-inner-section elementor-element elementor-element-5751f2cf elementor-section-full_width elementor-section-height-default elementor-section-height-default" data-id="5751f2cf" data-element_type="section">
						<div class="elementor-container elementor-column-gap-default">
					<div class="elementor-column elementor-col-50 elementor-inner-column elementor-element elementor-element-3848a02d" data-id="3848a02d" data-element_type="column">
			<div class="elementor-widget-wrap elementor-element-populated">
						<div class="elementor-element elementor-element-270a1cd9 margin-bottom-0 elementor-widget__width-initial elementor-widget elementor-widget-wp-widget-nasa_image" data-id="270a1cd9" data-element_type="widget" data-widget_type="wp-widget-nasa_image.default">
				<div class="elementor-widget-container">
					<a class="nasa-link-image" href="#"><img class="nasa-image skip-lazy" src="https://duniafesyen-media.s3.ap-southeast-1.amazonaws.com/wp-content/uploads/2025/03/03182040/Dunia-Fesyen-Logo-1.png" alt="" width="300" height="63" /></a>				</div>
				</div>
				<div class="elementor-element elementor-element-50f710e5 elementor-widget elementor-widget-html" data-id="50f710e5" data-element_type="widget" data-widget_type="html.default">
				<div class="elementor-widget-container">
					<ul class="contact-information">
    <li class="media">
        <div class="contact-text">iNiaga Global Sdn Bhd. (1495204-W)</div>
    </li>
    <li class="media">
        <div class="contact-text">No 46, Jalan Semilang 1, Taman Seri Putera, 42700, Banting, Selangor.</div>
    </li>
    <li class="media">
        <div class="contact-text">(+60)-03-3187-8882</div>
    </li>
    <li class="media">
        <div class="contact-text">
            <a href="mailto:hello@duniafesyen.com" title="Email">hello@duniafesyen.com</a>
        </div>
    </li>
    <li class="media">
        <div class="contact-text">
            <a href="https://duniafesyen.com" title="DuniaFesyen.com">DuniaFesyen.com</a>
        </div>
    </li>
</ul>
				</div>
				</div>
					</div>
		</div>
				<div class="elementor-column elementor-col-50 elementor-inner-column elementor-element elementor-element-1f95b9" data-id="1f95b9" data-element_type="column">
			<div class="elementor-widget-wrap elementor-element-populated">
						<div class="elementor-element elementor-element-1a5ae830 margin-bottom-0 elementor-widget elementor-widget-wp-widget-nasa_follow" data-id="1a5ae830" data-element_type="widget" data-widget_type="wp-widget-nasa_follow.default">
				<div class="elementor-widget-container">
					<div class="ns-social social-icons nasa-follow"><div class="follow-icon nasa-iflex flex-wrap"><a href="#" target="_blank" class="icon icon_twitter nasa-tip" title="Follow us on X" rel="nofollow"><svg viewBox="0 0 24 24" with="14" height="14" aria-hidden="true" fill="currentColor"><path d="M18.244 2.25h3.308l-7.227 8.26 8.502 11.24H16.17l-5.214-6.817L4.99 21.75H1.68l7.73-8.835L1.254 2.25H8.08l4.713 6.231zm-1.161 17.52h1.833L7.084 4.126H5.117z"/></svg></a><a href="#" target="_blank" class="icon icon_facebook nasa-tip" title="Follow us on Facebook" rel="nofollow"><svg viewBox="0 0 32 32" with="16" height="16" fill="currentColor"><path d="M 19.253906 2 C 15.311906 2 13 4.0821719 13 8.8261719 L 13 13 L 8 13 L 8 18 L 13 18 L 13 30 L 18 30 L 18 18 L 22 18 L 23 13 L 18 13 L 18 9.671875 C 18 7.884875 18.582766 7 20.259766 7 L 23 7 L 23 2.2050781 C 22.526 2.1410781 21.144906 2 19.253906 2 z"/></svg></a><a href="#" target="_blank" class="icon icon_pintrest nasa-tip" title="Follow us on Pinterest" rel="nofollow"><svg viewBox="0 0 16 16" width="16" height="16" fill="currentColor"><path d="M 7.5 1 C 3.910156 1 1 3.910156 1 7.5 C 1 10.253906 2.714844 12.605469 5.132813 13.554688 C 5.074219 13.039063 5.023438 12.25 5.152344 11.6875 C 5.273438 11.183594 5.914063 8.457031 5.914063 8.457031 C 5.914063 8.457031 5.722656 8.066406 5.722656 7.492188 C 5.722656 6.589844 6.246094 5.914063 6.898438 5.914063 C 7.453125 5.914063 7.71875 6.332031 7.71875 6.828125 C 7.71875 7.386719 7.363281 8.222656 7.183594 8.992188 C 7.027344 9.640625 7.507813 10.167969 8.144531 10.167969 C 9.300781 10.167969 10.1875 8.949219 10.1875 7.191406 C 10.1875 5.636719 9.070313 4.546875 7.472656 4.546875 C 5.625 4.546875 4.539063 5.933594 4.539063 7.367188 C 4.539063 7.925781 4.753906 8.527344 5.023438 8.851563 C 5.074219 8.917969 5.082031 8.972656 5.066406 9.039063 C 5.019531 9.242188 4.90625 9.6875 4.886719 9.777344 C 4.859375 9.894531 4.792969 9.921875 4.667969 9.863281 C 3.855469 9.484375 3.347656 8.296875 3.347656 7.34375 C 3.347656 5.292969 4.839844 3.410156 7.644531 3.410156 C 9.898438 3.410156 11.652344 5.015625 11.652344 7.164063 C 11.652344 9.402344 10.238281 11.207031 8.277344 11.207031 C 7.617188 11.207031 7 10.863281 6.789063 10.460938 C 6.789063 10.460938 6.460938 11.703125 6.382813 12.007813 C 6.234375 12.570313 5.839844 13.277344 5.574219 13.710938 C 6.183594 13.898438 6.828125 14 7.5 14 C 11.089844 14 14 11.089844 14 7.5 C 14 3.910156 11.089844 1 7.5 1 Z"/></svg></a><a href="#" target="_blank" class="icon icon_instagram nasa-tip" title="Follow us on Instagram" rel="nofollow"><svg viewBox="0 0 48 48" width="18" height="18" fill="currentColor"><path d="M 16.5 5 C 10.16639 5 5 10.16639 5 16.5 L 5 31.5 C 5 37.832757 10.166209 43 16.5 43 L 31.5 43 C 37.832938 43 43 37.832938 43 31.5 L 43 16.5 C 43 10.166209 37.832757 5 31.5 5 L 16.5 5 z M 16.5 8 L 31.5 8 C 36.211243 8 40 11.787791 40 16.5 L 40 31.5 C 40 36.211062 36.211062 40 31.5 40 L 16.5 40 C 11.787791 40 8 36.211243 8 31.5 L 8 16.5 C 8 11.78761 11.78761 8 16.5 8 z M 34 12 C 32.895 12 32 12.895 32 14 C 32 15.105 32.895 16 34 16 C 35.105 16 36 15.105 36 14 C 36 12.895 35.105 12 34 12 z M 24 14 C 18.495178 14 14 18.495178 14 24 C 14 29.504822 18.495178 34 24 34 C 29.504822 34 34 29.504822 34 24 C 34 18.495178 29.504822 14 24 14 z M 24 17 C 27.883178 17 31 20.116822 31 24 C 31 27.883178 27.883178 31 24 31 C 20.116822 31 17 27.883178 17 24 C 17 20.116822 20.116822 17 24 17 z"/></svg></a></div></div>				</div>
				</div>
				<div class="elementor-element elementor-element-4666f890 elementor-widget elementor-widget-wp-widget-nasa_menu_sc" data-id="4666f890" data-element_type="widget" data-widget_type="wp-widget-nasa_menu_sc.default">
				<div class="elementor-widget-container">
					        <div class="nasa-nav-sc-menu">
                        <ul class="nasa-menu-wrapper">
                <li class="menu-item menu-item-type-custom menu-item-object-custom default-menu root-item nasa_even"><a title="Delivery Information" href="#" class="nasa-title-menu"><svg class="nasa-open-child" width="20" height="20" viewBox="0 0 32 32" fill="currentColor"><path d="M15.233 19.175l0.754 0.754 6.035-6.035-0.754-0.754-5.281 5.281-5.256-5.256-0.754 0.754 3.013 3.013z" /></svg>Delivery Information</a></li>
<li class="menu-item menu-item-type-custom menu-item-object-custom default-menu root-item nasa_odd"><a title="Privacy Policy" href="#" class="nasa-title-menu"><svg class="nasa-open-child" width="20" height="20" viewBox="0 0 32 32" fill="currentColor"><path d="M15.233 19.175l0.754 0.754 6.035-6.035-0.754-0.754-5.281 5.281-5.256-5.256-0.754 0.754 3.013 3.013z" /></svg>Privacy Policy</a></li>
<li class="menu-item menu-item-type-custom menu-item-object-custom default-menu root-item nasa_even"><a title="Terms &#038; Condition" href="#" class="nasa-title-menu"><svg class="nasa-open-child" width="20" height="20" viewBox="0 0 32 32" fill="currentColor"><path d="M15.233 19.175l0.754 0.754 6.035-6.035-0.754-0.754-5.281 5.281-5.256-5.256-0.754 0.754 3.013 3.013z" /></svg>Terms &#038; Condition</a></li>
<li class="menu-item menu-item-type-custom menu-item-object-custom default-menu root-item nasa_odd"><a title="Search Terms" href="#" class="nasa-title-menu"><svg class="nasa-open-child" width="20" height="20" viewBox="0 0 32 32" fill="currentColor"><path d="M15.233 19.175l0.754 0.754 6.035-6.035-0.754-0.754-5.281 5.281-5.256-5.256-0.754 0.754 3.013 3.013z" /></svg>Search Terms</a></li>
<li class="menu-item menu-item-type-custom menu-item-object-custom default-menu root-item nasa_even"><a title="Order &#038; Return" href="#" class="nasa-title-menu"><svg class="nasa-open-child" width="20" height="20" viewBox="0 0 32 32" fill="currentColor"><path d="M15.233 19.175l0.754 0.754 6.035-6.035-0.754-0.754-5.281 5.281-5.256-5.256-0.754 0.754 3.013 3.013z" /></svg>Order &#038; Return</a></li>
            </ul>
        </div>
        				</div>
				</div>
					</div>
		</div>
					</div>
		</section>
					</div>
		</div>
				<div class="elementor-column elementor-col-50 elementor-top-column elementor-element elementor-element-4267d4ad" data-id="4267d4ad" data-element_type="column">
			<div class="elementor-widget-wrap elementor-element-populated">
						<section class="elementor-section elementor-inner-section elementor-element elementor-element-16aeec83 elementor-section-full_width elementor-section-height-default elementor-section-height-default" data-id="16aeec83" data-element_type="section">
						<div class="elementor-container elementor-column-gap-default">
					<div class="elementor-column elementor-col-100 elementor-inner-column elementor-element elementor-element-436ac45f footer-contact" data-id="436ac45f" data-element_type="column">
			<div class="elementor-widget-wrap elementor-element-populated">
						<div class="elementor-element elementor-element-6b098993 elementor-widget elementor-widget-shortcode" data-id="6b098993" data-element_type="widget" data-widget_type="shortcode.default">
				<div class="elementor-widget-container">
							<div class="elementor-shortcode"><div role="form" class="wpcf7" id="wpcf7-f210-o1" lang="en-US" dir="ltr">
<div class="screen-reader-response"><p role="status" aria-live="polite" aria-atomic="true"></p> <ul></ul></div>
<form action="/2024/07/05/tradisi-elegan-pesona-baju-kebaya-pengantin-di-malaysia/revslider/revslider.php#wpcf7-f210-o1" method="post" class="wpcf7-form init" novalidate="novalidate" data-status="init">
<div style="display: none;">
<input type="hidden" name="_wpcf7" value="210" />
<input type="hidden" name="_wpcf7_version" value="6.6.4" />
<input type="hidden" name="_wpcf7_locale" value="en_US" />
<input type="hidden" name="_wpcf7_unit_tag" value="wpcf7-f210-o1" />
<input type="hidden" name="_wpcf7_container_post" value="0" />
<input type="hidden" name="_wpcf7_posted_data_hash" value="" />
</div>
<p><span class="wpcf7-form-control-wrap" data-name="your-email"><input type="email" name="your-email" value="" size="40" class="wpcf7-form-control wpcf7-text wpcf7-email wpcf7-validates-as-required wpcf7-validates-as-email nasa-footer-contact-mail" aria-required="true" aria-invalid="false" placeholder="Enter your email here" /></span><input type="submit" value="SUBSCRIBE" class="wpcf7-form-control has-spinner wpcf7-submit btn-submit-newsletters button" /></p>
<p style="display: none !important;" class="akismet-fields-container" data-prefix="_wpcf7_ak_"><label>&#916;<textarea name="_wpcf7_ak_hp_textarea" cols="45" rows="8" maxlength="100"></textarea></label><input type="hidden" id="ak_js_1" name="_wpcf7_ak_js" value="35"/><script>document.getElementById( "ak_js_1" ).setAttribute( "value", ( new Date() ).getTime() );</script></p><div class="wpcf7-response-output" aria-hidden="true"></div></form></div></div>
						</div>
				</div>
					</div>
		</div>
					</div>
		</section>
				<section class="elementor-section elementor-inner-section elementor-element elementor-element-5a4a8c9b elementor-section-full_width elementor-section-height-default elementor-section-height-default" data-id="5a4a8c9b" data-element_type="section">
						<div class="elementor-container elementor-column-gap-default">
					<div class="elementor-column elementor-col-50 elementor-inner-column elementor-element elementor-element-3f2d2e92" data-id="3f2d2e92" data-element_type="column">
			<div class="elementor-widget-wrap elementor-element-populated">
						<div class="elementor-element elementor-element-37126907 elementor-widget elementor-widget-wp-widget-nasa_menu_sc" data-id="37126907" data-element_type="widget" data-widget_type="wp-widget-nasa_menu_sc.default">
				<div class="elementor-widget-container">
					        <div class="nasa-nav-sc-menu">
                        <ul class="nasa-menu-wrapper">
                <li class="menu-item menu-item-type-custom menu-item-object-custom default-menu root-item nasa_even"><a title="Customer Service" href="#" class="nasa-title-menu"><svg class="nasa-open-child" width="20" height="20" viewBox="0 0 32 32" fill="currentColor"><path d="M15.233 19.175l0.754 0.754 6.035-6.035-0.754-0.754-5.281 5.281-5.256-5.256-0.754 0.754 3.013 3.013z" /></svg>Customer Service</a></li>
<li class="menu-item menu-item-type-custom menu-item-object-custom default-menu root-item nasa_odd"><a title="Privacy Policy" href="#" class="nasa-title-menu"><svg class="nasa-open-child" width="20" height="20" viewBox="0 0 32 32" fill="currentColor"><path d="M15.233 19.175l0.754 0.754 6.035-6.035-0.754-0.754-5.281 5.281-5.256-5.256-0.754 0.754 3.013 3.013z" /></svg>Privacy Policy</a></li>
<li class="menu-item menu-item-type-custom menu-item-object-custom default-menu root-item nasa_even"><a title="Terms &#038; Condition" href="#" class="nasa-title-menu"><svg class="nasa-open-child" width="20" height="20" viewBox="0 0 32 32" fill="currentColor"><path d="M15.233 19.175l0.754 0.754 6.035-6.035-0.754-0.754-5.281 5.281-5.256-5.256-0.754 0.754 3.013 3.013z" /></svg>Terms &#038; Condition</a></li>
<li class="menu-item menu-item-type-custom menu-item-object-custom default-menu root-item nasa_odd"><a title="Best Seller" href="#" class="nasa-title-menu"><svg class="nasa-open-child" width="20" height="20" viewBox="0 0 32 32" fill="currentColor"><path d="M15.233 19.175l0.754 0.754 6.035-6.035-0.754-0.754-5.281 5.281-5.256-5.256-0.754 0.754 3.013 3.013z" /></svg>Best Seller</a></li>
<li class="menu-item menu-item-type-custom menu-item-object-custom default-menu root-item nasa_even"><a title="Manufactures" href="#" class="nasa-title-menu"><svg class="nasa-open-child" width="20" height="20" viewBox="0 0 32 32" fill="currentColor"><path d="M15.233 19.175l0.754 0.754 6.035-6.035-0.754-0.754-5.281 5.281-5.256-5.256-0.754 0.754 3.013 3.013z" /></svg>Manufactures</a></li>
            </ul>
        </div>
        				</div>
				</div>
					</div>
		</div>
				<div class="elementor-column elementor-col-50 elementor-inner-column elementor-element elementor-element-4e9010e8" data-id="4e9010e8" data-element_type="column">
			<div class="elementor-widget-wrap elementor-element-populated">
						<div class="elementor-element elementor-element-53a401be elementor-widget elementor-widget-html" data-id="53a401be" data-element_type="widget" data-widget_type="html.default">
				<div class="elementor-widget-container">
					<ul class="nasa-opening-time margin-bottom-0"><li><span class="nasa-day-open">Monday - Friday</span><span class="nasa-time-open">08:00 - 20:00</span></li><li><span class="nasa-day-open">Saturday</span><span class="nasa-time-open">09:00 - 21:00</span></li><li><span class="nasa-day-open">Sunday</span><span class="nasa-time-open">13:00 - 22:00</span></li></ul>				</div>
				</div>
				<div class="elementor-element elementor-element-24b83918 elementor-widget elementor-widget-wp-widget-nasa_image" data-id="24b83918" data-element_type="widget" data-widget_type="wp-widget-nasa_image.default">
				<div class="elementor-widget-container">
					<div class="nasa-image-wrap text-right"><img class="nasa-image" src="https://duniafesyen-media.s3.ap-southeast-1.amazonaws.com/wp-content/uploads/2017/11/03173831/payment-icons.png" alt="" width="191" height="35" /></div>				</div>
				</div>
					</div>
		</div>
					</div>
		</section>
					</div>
		</div>
					</div>
		</section>
				<section class="elementor-section elementor-top-section elementor-element elementor-element-5b6ee18e nasa-footer-bottom elementor-section-boxed elementor-section-height-default elementor-section-height-default" data-id="5b6ee18e" data-element_type="section">
						<div class="elementor-container elementor-column-gap-default">
					<div class="elementor-column elementor-col-50 elementor-top-column elementor-element elementor-element-f58fa8c nasa-footer-bottom-left" data-id="f58fa8c" data-element_type="column" data-settings="{&quot;background_background&quot;:&quot;classic&quot;}">
			<div class="elementor-widget-wrap elementor-element-populated">
						<div class="elementor-element elementor-element-698f7c9e elementor-widget elementor-widget-text-editor" data-id="698f7c9e" data-element_type="widget" data-widget_type="text-editor.default">
				<div class="elementor-widget-container">
									<p style="padding-bottom: 0;">© 2025 &#8211; All Right reserved!</p>								</div>
				</div>
					</div>
		</div>
				<div class="elementor-column elementor-col-50 elementor-top-column elementor-element elementor-element-65e3cbeb nasa-footer-bottom-right" data-id="65e3cbeb" data-element_type="column">
			<div class="elementor-widget-wrap elementor-element-populated">
						<div class="elementor-element elementor-element-670c7840 elementor-widget elementor-widget-wp-widget-nasa_menu_sc" data-id="670c7840" data-element_type="widget" data-widget_type="wp-widget-nasa_menu_sc.default">
				<div class="elementor-widget-container">
					        <div class="nasa-nav-sc-menu nasa-menu-inline">
                        <ul class="nasa-menu-wrapper">
                <li class="menu-item menu-item-type-custom menu-item-object-custom default-menu root-item nasa_even"><a title="Privacy &#038; Cookies" href="#" class="nasa-title-menu"><svg class="nasa-open-child" width="20" height="20" viewBox="0 0 32 32" fill="currentColor"><path d="M15.233 19.175l0.754 0.754 6.035-6.035-0.754-0.754-5.281 5.281-5.256-5.256-0.754 0.754 3.013 3.013z" /></svg>Privacy &#038; Cookies</a></li>
<li class="menu-item menu-item-type-custom menu-item-object-custom default-menu root-item nasa_odd"><a title="Terms &#038; Conditions" href="#" class="nasa-title-menu"><svg class="nasa-open-child" width="20" height="20" viewBox="0 0 32 32" fill="currentColor"><path d="M15.233 19.175l0.754 0.754 6.035-6.035-0.754-0.754-5.281 5.281-5.256-5.256-0.754 0.754 3.013 3.013z" /></svg>Terms &#038; Conditions</a></li>
<li class="menu-item menu-item-type-custom menu-item-object-custom default-menu root-item nasa_even"><a title="Accessibility" href="#" class="nasa-title-menu"><svg class="nasa-open-child" width="20" height="20" viewBox="0 0 32 32" fill="currentColor"><path d="M15.233 19.175l0.754 0.754 6.035-6.035-0.754-0.754-5.281 5.281-5.256-5.256-0.754 0.754 3.013 3.013z" /></svg>Accessibility</a></li>
<li class="menu-item menu-item-type-custom menu-item-object-custom default-menu root-item nasa_odd"><a title="Store Directory" href="#" class="nasa-title-menu"><svg class="nasa-open-child" width="20" height="20" viewBox="0 0 32 32" fill="currentColor"><path d="M15.233 19.175l0.754 0.754 6.035-6.035-0.754-0.754-5.281 5.281-5.256-5.256-0.754 0.754 3.013 3.013z" /></svg>Store Directory</a></li>
<li class="menu-item menu-item-type-custom menu-item-object-custom default-menu root-item nasa_even"><a title="About Us" href="#" class="nasa-title-menu"><svg class="nasa-open-child" width="20" height="20" viewBox="0 0 32 32" fill="currentColor"><path d="M15.233 19.175l0.754 0.754 6.035-6.035-0.754-0.754-5.281 5.281-5.256-5.256-0.754 0.754 3.013 3.013z" /></svg>About Us</a></li>
            </ul>
        </div>
        				</div>
				</div>
					</div>
		</div>
					</div>
		</section>
				</div>
		</footer><!-- END MAIN FOOTER -->
</div>
<!-- End Wrapper Site -->

<!-- Start static group buttons --><div class="nasa-static-group-btn"><a href="javascript:void(0);" id="nasa-back-to-top" class="nasa-tip nasa-tip-left" data-tip="Back to Top" rel="nofollow"><svg width="38" height="45" viewBox="0 0 32 32" fill="currentColor"><path d="M16.767 12.809l-0.754-0.754-6.035 6.035 0.754 0.754 5.281-5.281 5.256 5.256 0.754-0.754-3.013-3.013z" /></svg></a>    
        <a id="nasa-init-viewed" class="nasa-tip nasa-tip-left style-1" href="javascript:void(0);" data-tip="Recently Viewed" title="Recently Viewed" rel="nofollow">
        <svg width="26" height="26" viewBox="0 0 32 32" fill="currentColor">
            <path d="M16 3.205c-7.066 0-12.795 5.729-12.795 12.795s5.729 12.795 12.795 12.795 12.795-5.729 12.795-12.795c0-7.066-5.729-12.795-12.795-12.795zM16 27.729c-6.467 0-11.729-5.261-11.729-11.729s5.261-11.729 11.729-11.729 11.729 5.261 11.729 11.729c0 6.467-5.261 11.729-11.729 11.729z"/>
            <path d="M16 17.066h-6.398v1.066h7.464v-10.619h-1.066z"/>
        </svg>
    </a>
    </div><!-- End static group buttons --><!-- Start static tags --><div class="nasa-check-reponsive nasa-desktop-check"></div><div class="nasa-check-reponsive nasa-tablet-check"></div><div class="nasa-check-reponsive nasa-mobile-check"></div><div class="nasa-check-reponsive nasa-switch-check"></div><div class="black-window hidden-tag"></div><div class="white-window hidden-tag"></div><div class="transparent-window hidden-tag"></div><div class="transparent-mobile hidden-tag"></div><div class="black-window-mobile"></div><div class="warpper-mobile-search hidden-tag">    
    <div class="search-wrapper nasa-search nasa-ajax-search-form-container nasa-flex">
                    <form method="get" class="nasa-search nasa-ajax-search-form nasa-transition" action="https://duniafesyen.com/">
                <label for="nasa-input-mobile-search" class="label-search hidden-tag text-left fs-17">
                    Search                </label>

                <input id="nasa-input-mobile-search" type="text" class="search-field search-input force-radius-5 live-search-input" value="" name="s" placeholder="I&#039;m shopping for ..." />
                
                                    <span class="ns-popular-keys nasa-flex">
                        <span class="ns-label">
                            Popular Searches:                        </span>
                        
                                                    <a class="ns-popular-keyword" href="javascript:void(0);" rel="nofollow" data-word="Sweater">
                                Sweater                            </a>
                                                    <a class="ns-popular-keyword" href="javascript:void(0);" rel="nofollow" data-word="Jacket">
                                Jacket                            </a>
                                                    <a class="ns-popular-keyword" href="javascript:void(0);" rel="nofollow" data-word="Shirt">
                                Shirt                            </a>
                                            </span>
                
                <div class="nasa-vitual-hidden">
                                            <input type="submit" name="post_type" value="product" />
                                    </div>
            </form>
                <a href="javascript:void(0);" title="Close search" class="nasa-close-search-mobile margin-left-10 rtl-margin-left-0 rtl-margin-right-10 nasa-stclose" rel="nofollow"><svg width="36" height="36" viewBox="0 0 32 32"><path d="M16.767 12.809l-0.754-0.754-6.035 6.035 0.754 0.754 5.281-5.281 5.256 5.256 0.754-0.754-3.013-3.013z" fill="currentColor" /></svg></a>
    </div>
</div><script type="text/template" id="tmpl-nasa-mobile-account">
    <div class="content-account">
        <ul class="nasa-menus-account"><li class="menu-item"><a class="nasa-login-register-ajax inline-block" data-enable="1" href="https://duniafesyen.com/my-account/" title="Login / Register"><svg width="24" height="24" viewBox="0 0 32 32" fill="currentColor"><path d="M16 3.205c-7.067 0-12.795 5.728-12.795 12.795s5.728 12.795 12.795 12.795 12.795-5.728 12.795-12.795c0-7.067-5.728-12.795-12.795-12.795zM16 4.271c6.467 0 11.729 5.261 11.729 11.729 0 2.845-1.019 5.457-2.711 7.49-1.169-0.488-3.93-1.446-5.638-1.951-0.146-0.046-0.169-0.053-0.169-0.66 0-0.501 0.206-1.005 0.407-1.432 0.218-0.464 0.476-1.244 0.569-1.944 0.259-0.301 0.612-0.895 0.839-2.026 0.199-0.997 0.106-1.36-0.026-1.7-0.014-0.036-0.028-0.071-0.039-0.107-0.050-0.234 0.019-1.448 0.189-2.391 0.118-0.647-0.030-2.022-0.921-3.159-0.562-0.719-1.638-1.601-3.603-1.724l-1.078 0.001c-1.932 0.122-3.008 1.004-3.57 1.723-0.89 1.137-1.038 2.513-0.92 3.159 0.172 0.943 0.239 2.157 0.191 2.387-0.010 0.040-0.025 0.075-0.040 0.111-0.131 0.341-0.225 0.703-0.025 1.7 0.226 1.131 0.579 1.725 0.839 2.026 0.092 0.7 0.35 1.48 0.569 1.944 0.159 0.339 0.234 0.801 0.234 1.454 0 0.607-0.023 0.614-0.159 0.657-1.767 0.522-4.579 1.538-5.628 1.997-1.725-2.042-2.768-4.679-2.768-7.555 0-6.467 5.261-11.729 11.729-11.729zM7.811 24.386c1.201-0.49 3.594-1.344 5.167-1.808 0.914-0.288 0.914-1.058 0.914-1.677 0-0.513-0.035-1.269-0.335-1.908-0.206-0.438-0.442-1.189-0.494-1.776-0.011-0.137-0.076-0.265-0.18-0.355-0.151-0.132-0.458-0.616-0.654-1.593-0.155-0.773-0.089-0.942-0.026-1.106 0.027-0.070 0.053-0.139 0.074-0.216 0.128-0.468-0.015-2.005-0.17-2.858-0.068-0.371 0.018-1.424 0.711-2.311 0.622-0.795 1.563-1.238 2.764-1.315l1.011-0.001c1.233 0.078 2.174 0.521 2.797 1.316 0.694 0.887 0.778 1.94 0.71 2.312-0.154 0.852-0.298 2.39-0.17 2.857 0.022 0.078 0.047 0.147 0.074 0.217 0.064 0.163 0.129 0.333-0.025 1.106-0.196 0.977-0.504 1.461-0.655 1.593-0.103 0.091-0.168 0.218-0.18 0.355-0.051 0.588-0.286 1.338-0.492 1.776-0.236 0.502-0.508 1.171-0.508 1.886 0 0.619 0 1.389 0.924 1.68 1.505 0.445 3.91 1.271 5.18 1.77-2.121 2.1-5.035 3.4-8.248 3.4-3.183 0-6.073-1.277-8.188-3.342z"/></svg>&nbsp;<span class="nasa-login-title">Login / Register</span></a></li></ul>    </div>
</script>

        <script type="text/template" id="ns-cart-sidebar-loading-item">
            <div class="nasa-minicart-items-empty">
                <div class="sidebar-minicart-items-mask nasa-flex align-start">
                    <div class="nasa-mask-lv1 ns-mask-load"></div>
                    <div class="nasa-mask-lv1">
                        <div class="nasa-mask-lv2 ns-mask-load"></div>
                        <div class="nasa-mask-lv2 ns-mask-load"></div>
                        <div class="nasa-mask-lv2 ns-mask-load"></div>
                        <div class="nasa-mask-lv2 ns-mask-load"></div>
                    </div>
                </div>
            </div>
        </script>

        <script type="text/template" id="ns-cart-sidebar-loading-footer">
            <div class="nasa-mask-lv1">
                <div class="nasa-flex ext-mini-cart-wrap-empty jsa">
                    <span class="nasa-mask-lv2 ns-mask-load"></span>
                    <span class="ns-line-ver"></span>
                    <span class="nasa-mask-lv2 ns-mask-load"></span>
                    <span class="ns-line-ver"></span>
                    <span class="nasa-mask-lv2 ns-mask-load"></span>
                </div>
                <span class="ns-line"></span>
                <div class="nasa-mask-lv2 ns-mask-load nasa-float-left nasa-block ns-width-40"></div>
                <div class="nasa-mask-lv2 ns-mask-load nasa-float-right nasa-block ns-width-30"></div>
                <span class="ns-line"></span>
                <div class="nasa-mask-lv2 ns-mask-load nasa-float-left nasa-block ns-width-35"></div>
                <div class="nasa-mask-lv2 ns-mask-load nasa-float-right nasa-block ns-width-20"></div>
            </div>
            <div class="nasa-mask-lv1 btn-mini-cart">
                <div class="nasa-mask-lv2 ns-mask-load"></div>
                <div class="nasa-mask-lv2 ns-mask-load"></div>
            </div>
        </script>


        <div id="cart-sidebar" data-variation-product-adding="" class="nasa-static-sidebar style-1">
            <!-- canvas id="nasa-confetti" style="position:absolute; top:0; left:0; display:none; z-index:99;"></canvas -->

            <div class="cart-close nasa-sidebar-close">
                <a href="javascript:void(0);" title="Close" rel="nofollow">
                    <svg width="15" height="15" viewBox="0 0 512 512" fill="currentColor">
                        <path d="M135 512c3 0 4 0 6 0 15-4 26-21 40-33 62-61 122-122 187-183 9-9 27-24 29-33 3-14-8-23-17-32-67-66-135-131-202-198-11-9-24-27-33-29-18-4-28 8-31 21 0 0 0 2 0 2 1 1 1 6 3 10 3 8 18 20 27 28 47 47 95 93 141 139 19 18 39 36 55 55-62 64-134 129-199 193-8 9-24 21-26 32-3 18 8 24 20 28z" />
                    </svg>
                </a>

                <span class="nasa-tit-mycart nasa-sidebar-tit text-center" data_text_adding="Adding">
                    My Cart                </span>
            </div>

            <div class="widget_shopping_cart_content">
                <input type="hidden" name="nasa-mini-cart-empty-content" />
            </div>

                    </div>

    <input type="hidden" name="nasa_wishlist_cookie_name" value="nasa_wishlist_774b9914d2cd9931f51d220a376a1595_default" />
        <div id="nasa-wishlist-sidebar" class="nasa-static-sidebar style-1">
            <div class="wishlist-close nasa-sidebar-close">
                <a href="javascript:void(0);" title="Close" rel="nofollow">
                    <svg width="15" height="15" viewBox="0 0 512 512" fill="currentColor">
                        <path d="M135 512c3 0 4 0 6 0 15-4 26-21 40-33 62-61 122-122 187-183 9-9 27-24 29-33 3-14-8-23-17-32-67-66-135-131-202-198-11-9-24-27-33-29-18-4-28 8-31 21 0 0 0 2 0 2 1 1 1 6 3 10 3 8 18 20 27 28 47 47 95 93 141 139 19 18 39 36 55 55-62 64-134 129-199 193-8 9-24 21-26 32-3 18 8 24 20 28z" />
                    </svg>
                </a>

                <span class="nasa-tit-wishlist nasa-sidebar-tit text-center">
                    Wishlist                </span>
            </div>

            <div id="nasa-wishlist-sidebar-content" class="nasa-relative nasa-fullsize"><div class="nasa-loader"></div></div>        </div>
            
    <!-- viewed product -->
    <div id="nasa-viewed-sidebar" class="nasa-static-sidebar style-1">
        <div class="viewed-close nasa-sidebar-close">
            <a href="javascript:void(0);" title="Close" rel="nofollow">
                <svg width="15" height="15" viewBox="0 0 512 512" fill="currentColor"><path d="M135 512c3 0 4 0 6 0 15-4 26-21 40-33 62-61 122-122 187-183 9-9 27-24 29-33 3-14-8-23-17-32-67-66-135-131-202-198-11-9-24-27-33-29-18-4-28 8-31 21 0 0 0 2 0 2 1 1 1 6 3 10 3 8 18 20 27 28 47 47 95 93 141 139 19 18 39 36 55 55-62 64-134 129-199 193-8 9-24 21-26 32-3 18 8 24 20 28z"/></svg>
            </a>
            
            <span class="nasa-tit-viewed nasa-sidebar-tit text-center">
                Recently Viewed            </span>
        </div>
        
        <div id="nasa-viewed-sidebar-content" class="nasa-absolute">
            <div class="nasa-loader"></div>
        </div>
    </div>
    
                            <div class="nasa-login-register-warper" style="display: none;">
                <div id="nasa-login-register-form" class="">
                    <div class="nasa-form-logo-log nasa-no-fix-size-retina margin-bottom-20">
                        <a class="logo nasa-logo-retina nasa-has-sticky-logo nasa-has-mobile-logo" href="https://duniafesyen.com/" title="Dunia Fesyen - Info Terkini Fesyen" rel="Home"><img src="//duniafesyen-media.s3.ap-southeast-1.amazonaws.com/wp-content/uploads/2025/03/03181633/Dunia-Fesyen-Logo.png" alt="Dunia Fesyen" class="header_logo" srcset="//duniafesyen-media.s3.ap-southeast-1.amazonaws.com/wp-content/uploads/2025/03/03181633/Dunia-Fesyen-Logo.png 1x, //duniafesyen-media.s3.ap-southeast-1.amazonaws.com/wp-content/uploads/2025/03/03181554/DF-Logo-Retina.png 2x" /><img src="//duniafesyen-media.s3.ap-southeast-1.amazonaws.com/wp-content/uploads/2025/03/03181633/Dunia-Fesyen-Logo.png" alt="Dunia Fesyen" class="header_logo logo_sticky" /><img src="//duniafesyen-media.s3.ap-southeast-1.amazonaws.com/wp-content/uploads/2025/03/03181633/Dunia-Fesyen-Logo.png" alt="Dunia Fesyen" class="header_logo logo_mobile" /></a>
                        <a class="login-register-close nasa-stclose" href="javascript:void(0);" title="Close" rel="nofollow"></a>
                    </div>

                    <div class="nasa-message"></div>
                    <div class="nasa-form-content">
                        

<div class="row" id="nasa_customer_login">
    <div class="large-12 columns nasa_login-form">
        
        <span class="nasa-form-title">
            Great to have you back!        </span>

        <form method="post" class="woocommerce-form woocommerce-form-login login">
            
            
            <p class="form-row form-row-wide">
                <span>
                    <label for="nasa_username" class="inline-block left rtl-right">
                        Username or email <span class="required" aria-hidden="true">*</span>
                    </label>

                    <!-- Remember -->
                    <label for="nasa_rememberme" class="woocommerce-form__label woocommerce-form__label-for-checkbox woocommerce-form-login__rememberme inline-block right rtl-left none-weight">
                        <input class="woocommerce-form__input woocommerce-form__input-checkbox margin-right-5 rtl-margin-right-0 rtl-margin-left-5" name="nasa_rememberme" type="checkbox" id="nasa_rememberme" value="forever" /> Remember                    </label>
                </span>

                <!-- Username -->
                <input type="text" class="woocommerce-Input woocommerce-Input--text input-text" name="nasa_username" id="nasa_username" autocomplete="username" value="" required aria-required="true" />
            </p>

            <p class="form-row form-row-wide">
                <span>
                    <label for="nasa_password" class="inline-block left rtl-right">
                        Password <span class="required" aria-hidden="true">*</span>
                    </label>
                    
                    <a class="lost_password inline-block right rtl-left none-weight" href="https://duniafesyen.com/my-account/lost-password/">Lost?</a>
                </span>
                
                <a href="javascript:void(0);" class="ns-show-password"><svg width="20px" height="20px" viewBox="0 0 24 24" fill="currentColor" class="ns-svg-eye-op">
    <path d="M12 5C5.63636 5 2 12 2 12C2 12 5.63636 19 12 19C18.3636 19 22 12 22 12C22 12 18.3636 5 12 5Z" stroke="currentColor" stroke-width="1.5" stroke-linecap="round" stroke-linejoin="round" />
    <path d="M12 15C13.6569 15 15 13.6569 15 12C15 10.3431 13.6569 9 12 9C10.3431 9 9 10.3431 9 12C9 13.6569 10.3431 15 12 15Z" stroke="currentColor" stroke-width="1.5" stroke-linecap="round" stroke-linejoin="round" />
</svg><svg width="20px" height="20px" viewBox="0 0 24 24" fill="currentColor" class="ns-svg-eye-cl">
    <path d="M20 14.8335C21.3082 13.3317 22 12 22 12C22 12 18.3636 5 12 5C11.6588 5 11.3254 5.02013 11 5.05822C10.6578 5.09828 10.3244 5.15822 10 5.23552M12 9C12.3506 9 12.6872 9.06015 13 9.17071C13.8524 9.47199 14.528 10.1476 14.8293 11C14.9398 11.3128 15 11.6494 15 12M3 3L21 21M12 15C11.6494 15 11.3128 14.9398 11 14.8293C10.1476 14.528 9.47198 13.8524 9.1707 13C9.11386 12.8392 9.07034 12.6721 9.04147 12.5M4.14701 9C3.83877 9.34451 3.56234 9.68241 3.31864 10C2.45286 11.1282 2 12 2 12C2 12 5.63636 19 12 19C12.3412 19 12.6746 18.9799 13 18.9418" stroke="currentColor" stroke-width="1.5" stroke-linecap="round" stroke-linejoin="round" />
</svg></a>
                
                <input class="woocommerce-Input woocommerce-Input--text input-text" type="password" name="nasa_password" id="nasa_password" autocomplete="current-password" required aria-required="true" />
            </p>

            
            <p class="form-row row-submit">
                <input type="hidden" id="woocommerce-login-nonce" name="woocommerce-login-nonce" value="6e89b455b3" /><input type="hidden" name="_wp_http_referer" value="/2024/07/05/tradisi-elegan-pesona-baju-kebaya-pengantin-di-malaysia/revslider/revslider.php" />                <button type="submit" class="woocommerce-button button woocommerce-form-login__submit nasa-fullwidth margin-top-10" name="nasa_login" value="SIGN IN TO YOUR ACCOUNT">SIGN IN TO YOUR ACCOUNT</button>
            </p>

                    </form>

                    <p class="nasa-switch-form">
                Not a member?                 
                <a class="nasa-switch-register" href="javascript:void(0);" rel="nofollow">
                    Create an account                </a>
            </p>
            </div>

            <div class="large-12 columns nasa_register-form">

            <span class="nasa-form-title">
                Great to see you here!            </span>

            <form method="post" class="woocommerce-form woocommerce-form-register register" >

                
                
                <p class="form-row form-row-wide">
                    <label for="nasa_reg_email" class="left rtl-right">
                        Email address <span class="required" aria-hidden="true">*</span>
                    </label>

                    <!-- Email -->
                    <input type="email" class="woocommerce-Input woocommerce-Input--text input-text" name="nasa_email" id="nasa_reg_email" autocomplete="email" value="" required aria-required="true" />
                </p>

                
                    <p class="form-row form-row-wide">
                        A link to set a new password will be sent to your email address.                    </p>

                
                <wc-order-attribution-inputs></wc-order-attribution-inputs><div class="woocommerce-privacy-policy-text"></div>
                <p class="form-row">
                    <input type="hidden" id="woocommerce-register-nonce" name="woocommerce-register-nonce" value="b68baf444e" /><input type="hidden" name="_wp_http_referer" value="/2024/07/05/tradisi-elegan-pesona-baju-kebaya-pengantin-di-malaysia/revslider/revslider.php" />
                    <!-- Submit button -->
                    <button type="submit" class="woocommerce-Button woocommerce-button button woocommerce-form-register__submit nasa-fullwidth" name="nasa_register" value="SETUP YOUR ACCOUNT">SETUP YOUR ACCOUNT</button>
                </p>

                
            </form>

            <p class="nasa-switch-form">
                Already got an account?                 
                <a class="nasa-switch-login" href="javascript:void(0);" rel="nofollow">
                    Sign in here                </a>
            </p>

        </div>
    </div>

                    </div>
                </div>
            </div>
                                <div id="nasa-quickview-sidebar" class="nasa-static-sidebar nasa-crazy-load qv-loading style-1">
                                    <div class="nasa-quickview-fog hidden-tag">
                        <div class="qv-crazy-imgs"></div>
                        <div class="qv-crazy-info">
                            <!-- Loading Name -->
                            <span class="info-1"></span>

                            <!-- Loading Price -->
                            <span class="info-2 margin-top-20"></span>

                            <!-- Loading Other Ex Stars -->
                            <span class="info-3 margin-top-20"></span>

                            <!-- Loading Desc -->
                            <span class="info-4 margin-top-40"></span>
                            <span class="info-5 margin-top-10"></span>

                            <!-- Loading Variation -->
                            <span class="info-6 margin-top-40"></span>
                            <span class="info-6-2 margin-top-20"></span>

                            <!-- Loading Buttons -->
                            <span class="info-7 nasa-flex margin-top-40">
                                <span class="info-7-1"></span>
                                <span class="info-7-2"></span>
                                <span class="info-7-3"></span>
                            </span>

                            <span class="info-8 margin-top-40"></span>
                        </div>
                    </div>
                
                <div class="quickview-close nasa-sidebar-close">
                    <a href="javascript:void(0);" title="Close" rel="nofollow">
                        <svg width="15" height="15" viewBox="0 0 512 512" fill="currentColor">
                            <path d="M135 512c3 0 4 0 6 0 15-4 26-21 40-33 62-61 122-122 187-183 9-9 27-24 29-33 3-14-8-23-17-32-67-66-135-131-202-198-11-9-24-27-33-29-18-4-28 8-31 21 0 0 0 2 0 2 1 1 1 6 3 10 3 8 18 20 27 28 47 47 95 93 141 139 19 18 39 36 55 55-62 64-134 129-199 193-8 9-24 21-26 32-3 18 8 24 20 28z" />
                        </svg>
                    </a>
                </div>

                <div id="nasa-quickview-sidebar-content"><div class="nasa-loader"></div></div>            </div>
                <div class="nasa-compare-list-bottom">
                    </div>
    
        <div id="nasa-menu-sidebar-content" class="nasa-standard">
            <a class="nasa-close-menu-mobile ns-touch-close" href="javascript:void(0);" rel="nofollow">
                <svg class="nasa-rotate-180" width="15" height="15" viewBox="0 0 512 512" fill="currentColor">
                    <path d="M135 512c3 0 4 0 6 0 15-4 26-21 40-33 62-61 122-122 187-183 9-9 27-24 29-33 3-14-8-23-17-32-67-66-135-131-202-198-11-9-24-27-33-29-18-4-28 8-31 21 0 0 0 2 0 2 1 1 1 6 3 10 3 8 18 20 27 28 47 47 95 93 141 139 19 18 39 36 55 55-62 64-134 129-199 193-8 9-24 21-26 32-3 18 8 24 20 28z" />
                </svg>
            </a>
            <div class="nasa-mobile-nav-wrap">
                <div id="mobile-navigation"></div>
            </div>
        </div>

    <div id="heading-menu-mobile" class="hidden-tag"><a class="logo nasa-logo-retina nasa-has-sticky-logo nasa-has-mobile-logo" href="https://duniafesyen.com/" title="Dunia Fesyen - Info Terkini Fesyen" rel="Home"><img src="//duniafesyen-media.s3.ap-southeast-1.amazonaws.com/wp-content/uploads/2025/03/03181633/Dunia-Fesyen-Logo.png" alt="Dunia Fesyen" class="header_logo" srcset="//duniafesyen-media.s3.ap-southeast-1.amazonaws.com/wp-content/uploads/2025/03/03181633/Dunia-Fesyen-Logo.png 1x, //duniafesyen-media.s3.ap-southeast-1.amazonaws.com/wp-content/uploads/2025/03/03181554/DF-Logo-Retina.png 2x" /><img src="//duniafesyen-media.s3.ap-southeast-1.amazonaws.com/wp-content/uploads/2025/03/03181633/Dunia-Fesyen-Logo.png" alt="Dunia Fesyen" class="header_logo logo_sticky" /><img src="//duniafesyen-media.s3.ap-southeast-1.amazonaws.com/wp-content/uploads/2025/03/03181633/Dunia-Fesyen-Logo.png" alt="Dunia Fesyen" class="header_logo logo_mobile" /></a></div>        <div class="nasa-top-cat-filter-wrap-mobile">
            <span class="nasa-tit-filter-cat">
                Categories            </span>

            <div id="nasa-mobile-cat-filter"><ul class="nasa-top-cat-filter product-categories nasa-accordion"><li class="nasa-tax-item cat-item cat-item-1108 cat-item-jewelry root-item cat-parent nasa-tax-parent li_accordion"><a href="javascript:void(0);" class="accordion" rel="nofollow"></a><a href="https://duniafesyen.com/product-category/jewelry/" title="Jewelry" class="nasa-filter-item nasa-filter-by-tax nasa-filter-by-cat">Jewelry</a><ul class='children'>
<li class="nasa-tax-item cat-item cat-item-1162 cat-item-bracelets"><a href="https://duniafesyen.com/product-category/jewelry/bracelets/" title="Bracelets" class="nasa-filter-item nasa-filter-by-tax nasa-filter-by-cat">Bracelets</a></li>
<li class="nasa-tax-item cat-item cat-item-1117 cat-item-necklaces-pendants"><a href="https://duniafesyen.com/product-category/jewelry/necklaces-pendants/" title="Necklaces &amp; Pendants" class="nasa-filter-item nasa-filter-by-tax nasa-filter-by-cat">Necklaces &amp; Pendants</a></li>
<li class="nasa-tax-item cat-item cat-item-1123 cat-item-rings"><a href="https://duniafesyen.com/product-category/jewelry/rings/" title="Rings" class="nasa-filter-item nasa-filter-by-tax nasa-filter-by-cat">Rings</a></li>
</ul>
</li>
<li class="nasa-tax-item cat-item cat-item-902 cat-item-jewelry-watches root-item cat-parent nasa-tax-parent li_accordion"><a href="javascript:void(0);" class="accordion" rel="nofollow"></a><a href="https://duniafesyen.com/product-category/jewelry-watches/" title="Jewelry &amp; Watches" class="nasa-filter-item nasa-filter-by-tax nasa-filter-by-cat">Jewelry &amp; Watches</a><ul class='children'>
<li class="nasa-tax-item cat-item cat-item-947 cat-item-body-jewelry cat-parent nasa-tax-parent li_accordion"><a href="javascript:void(0);" class="accordion" rel="nofollow"></a><a href="https://duniafesyen.com/product-category/jewelry-watches/body-jewelry/" title="Body Jewelry" class="nasa-filter-item nasa-filter-by-tax nasa-filter-by-cat">Body Jewelry</a>	<ul class='children'>
<li class="nasa-tax-item cat-item cat-item-950 cat-item-belly-button-ring"><a href="https://duniafesyen.com/product-category/jewelry-watches/body-jewelry/belly-button-ring/" title="Belly Button Ring" class="nasa-filter-item nasa-filter-by-tax nasa-filter-by-cat">Belly Button Ring</a></li>
<li class="nasa-tax-item cat-item cat-item-951 cat-item-bodychain"><a href="https://duniafesyen.com/product-category/jewelry-watches/body-jewelry/bodychain/" title="Bodychain" class="nasa-filter-item nasa-filter-by-tax nasa-filter-by-cat">Bodychain</a></li>
<li class="nasa-tax-item cat-item cat-item-949 cat-item-dental-grill"><a href="https://duniafesyen.com/product-category/jewelry-watches/body-jewelry/dental-grill/" title="Dental Grill" class="nasa-filter-item nasa-filter-by-tax nasa-filter-by-cat">Dental Grill</a></li>
<li class="nasa-tax-item cat-item cat-item-948 cat-item-ear-piercing"><a href="https://duniafesyen.com/product-category/jewelry-watches/body-jewelry/ear-piercing/" title="Ear Piercing" class="nasa-filter-item nasa-filter-by-tax nasa-filter-by-cat">Ear Piercing</a></li>
<li class="nasa-tax-item cat-item cat-item-952 cat-item-nose-nail"><a href="https://duniafesyen.com/product-category/jewelry-watches/body-jewelry/nose-nail/" title="Nose Nail" class="nasa-filter-item nasa-filter-by-tax nasa-filter-by-cat">Nose Nail</a></li>
	</ul>
</li>
<li class="nasa-tax-item cat-item cat-item-933 cat-item-bracelet-bangles cat-parent nasa-tax-parent li_accordion"><a href="javascript:void(0);" class="accordion" rel="nofollow"></a><a href="https://duniafesyen.com/product-category/jewelry-watches/bracelet-bangles/" title="Bracelet &amp; Bangles" class="nasa-filter-item nasa-filter-by-tax nasa-filter-by-cat">Bracelet &amp; Bangles</a>	<ul class='children'>
<li class="nasa-tax-item cat-item cat-item-937 cat-item-chain-bracelet"><a href="https://duniafesyen.com/product-category/jewelry-watches/bracelet-bangles/chain-bracelet/" title="Chain Bracelet" class="nasa-filter-item nasa-filter-by-tax nasa-filter-by-cat">Chain Bracelet</a></li>
<li class="nasa-tax-item cat-item cat-item-939 cat-item-k-gold-bracelet"><a href="https://duniafesyen.com/product-category/jewelry-watches/bracelet-bangles/k-gold-bracelet/" title="K Gold Bracelet" class="nasa-filter-item nasa-filter-by-tax nasa-filter-by-cat">K Gold Bracelet</a></li>
<li class="nasa-tax-item cat-item cat-item-935 cat-item-moissanite-bracelet"><a href="https://duniafesyen.com/product-category/jewelry-watches/bracelet-bangles/moissanite-bracelet/" title="Moissanite Bracelet" class="nasa-filter-item nasa-filter-by-tax nasa-filter-by-cat">Moissanite Bracelet</a></li>
<li class="nasa-tax-item cat-item cat-item-936 cat-item-natural-stone-bracelet"><a href="https://duniafesyen.com/product-category/jewelry-watches/bracelet-bangles/natural-stone-bracelet/" title="Natural Stone Bracelet" class="nasa-filter-item nasa-filter-by-tax nasa-filter-by-cat">Natural Stone Bracelet</a></li>
<li class="nasa-tax-item cat-item cat-item-934 cat-item-silver-bracelet"><a href="https://duniafesyen.com/product-category/jewelry-watches/bracelet-bangles/silver-bracelet/" title="Silver Bracelet" class="nasa-filter-item nasa-filter-by-tax nasa-filter-by-cat">Silver Bracelet</a></li>
<li class="nasa-tax-item cat-item cat-item-938 cat-item-thread-bracelet"><a href="https://duniafesyen.com/product-category/jewelry-watches/bracelet-bangles/thread-bracelet/" title="Thread Bracelet" class="nasa-filter-item nasa-filter-by-tax nasa-filter-by-cat">Thread Bracelet</a></li>
	</ul>
</li>
<li class="nasa-tax-item cat-item cat-item-922 cat-item-earrings cat-parent nasa-tax-parent li_accordion"><a href="javascript:void(0);" class="accordion" rel="nofollow"></a><a href="https://duniafesyen.com/product-category/jewelry-watches/earrings/" title="Earrings" class="nasa-filter-item nasa-filter-by-tax nasa-filter-by-cat">Earrings</a>	<ul class='children'>
<li class="nasa-tax-item cat-item cat-item-928 cat-item-drop-dangle-earring"><a href="https://duniafesyen.com/product-category/jewelry-watches/earrings/drop-dangle-earring/" title="Drop &amp; Dangle Earring" class="nasa-filter-item nasa-filter-by-tax nasa-filter-by-cat">Drop &amp; Dangle Earring</a></li>
<li class="nasa-tax-item cat-item cat-item-924 cat-item-earring-set"><a href="https://duniafesyen.com/product-category/jewelry-watches/earrings/earring-set/" title="Earring Set" class="nasa-filter-item nasa-filter-by-tax nasa-filter-by-cat">Earring Set</a></li>
<li class="nasa-tax-item cat-item cat-item-926 cat-item-hoop-earring"><a href="https://duniafesyen.com/product-category/jewelry-watches/earrings/hoop-earring/" title="Hoop Earring" class="nasa-filter-item nasa-filter-by-tax nasa-filter-by-cat">Hoop Earring</a></li>
<li class="nasa-tax-item cat-item cat-item-923 cat-item-k-gold-earring"><a href="https://duniafesyen.com/product-category/jewelry-watches/earrings/k-gold-earring/" title="K Gold Earring" class="nasa-filter-item nasa-filter-by-tax nasa-filter-by-cat">K Gold Earring</a></li>
<li class="nasa-tax-item cat-item cat-item-927 cat-item-pearl-necklace"><a href="https://duniafesyen.com/product-category/jewelry-watches/earrings/pearl-necklace/" title="Pearl Necklace" class="nasa-filter-item nasa-filter-by-tax nasa-filter-by-cat">Pearl Necklace</a></li>
<li class="nasa-tax-item cat-item cat-item-925 cat-item-silver-earring"><a href="https://duniafesyen.com/product-category/jewelry-watches/earrings/silver-earring/" title="Silver Earring" class="nasa-filter-item nasa-filter-by-tax nasa-filter-by-cat">Silver Earring</a></li>
	</ul>
</li>
<li class="nasa-tax-item cat-item cat-item-903 cat-item-jewelry-making cat-parent nasa-tax-parent li_accordion"><a href="javascript:void(0);" class="accordion" rel="nofollow"></a><a href="https://duniafesyen.com/product-category/jewelry-watches/jewelry-making/" title="Jewelry Making" class="nasa-filter-item nasa-filter-by-tax nasa-filter-by-cat">Jewelry Making</a>	<ul class='children'>
<li class="nasa-tax-item cat-item cat-item-909 cat-item-chains"><a href="https://duniafesyen.com/product-category/jewelry-watches/jewelry-making/chains/" title="Chains" class="nasa-filter-item nasa-filter-by-tax nasa-filter-by-cat">Chains</a></li>
<li class="nasa-tax-item cat-item cat-item-908 cat-item-charms"><a href="https://duniafesyen.com/product-category/jewelry-watches/jewelry-making/charms/" title="Charms" class="nasa-filter-item nasa-filter-by-tax nasa-filter-by-cat">Charms</a></li>
<li class="nasa-tax-item cat-item cat-item-906 cat-item-jewelry-findings"><a href="https://duniafesyen.com/product-category/jewelry-watches/jewelry-making/jewelry-findings/" title="Jewelry Findings" class="nasa-filter-item nasa-filter-by-tax nasa-filter-by-cat">Jewelry Findings</a></li>
<li class="nasa-tax-item cat-item cat-item-905 cat-item-jewelry-packagings"><a href="https://duniafesyen.com/product-category/jewelry-watches/jewelry-making/jewelry-packagings/" title="Jewelry Packagings" class="nasa-filter-item nasa-filter-by-tax nasa-filter-by-cat">Jewelry Packagings</a></li>
<li class="nasa-tax-item cat-item cat-item-904 cat-item-resin-diy"><a href="https://duniafesyen.com/product-category/jewelry-watches/jewelry-making/resin-diy/" title="Resin DIY" class="nasa-filter-item nasa-filter-by-tax nasa-filter-by-cat">Resin DIY</a></li>
<li class="nasa-tax-item cat-item cat-item-907 cat-item-tools"><a href="https://duniafesyen.com/product-category/jewelry-watches/jewelry-making/tools/" title="Tools" class="nasa-filter-item nasa-filter-by-tax nasa-filter-by-cat">Tools</a></li>
	</ul>
</li>
<li class="nasa-tax-item cat-item cat-item-910 cat-item-material cat-parent nasa-tax-parent li_accordion"><a href="javascript:void(0);" class="accordion" rel="nofollow"></a><a href="https://duniafesyen.com/product-category/jewelry-watches/material/" title="Material" class="nasa-filter-item nasa-filter-by-tax nasa-filter-by-cat">Material</a>	<ul class='children'>
<li class="nasa-tax-item cat-item cat-item-914 cat-item-gems"><a href="https://duniafesyen.com/product-category/jewelry-watches/material/gems/" title="Gems" class="nasa-filter-item nasa-filter-by-tax nasa-filter-by-cat">Gems</a></li>
<li class="nasa-tax-item cat-item cat-item-913 cat-item-k-gold"><a href="https://duniafesyen.com/product-category/jewelry-watches/material/k-gold/" title="K Gold" class="nasa-filter-item nasa-filter-by-tax nasa-filter-by-cat">K Gold</a></li>
<li class="nasa-tax-item cat-item cat-item-915 cat-item-moissanite"><a href="https://duniafesyen.com/product-category/jewelry-watches/material/moissanite/" title="Moissanite" class="nasa-filter-item nasa-filter-by-tax nasa-filter-by-cat">Moissanite</a></li>
<li class="nasa-tax-item cat-item cat-item-912 cat-item-pearl"><a href="https://duniafesyen.com/product-category/jewelry-watches/material/pearl/" title="Pearl" class="nasa-filter-item nasa-filter-by-tax nasa-filter-by-cat">Pearl</a></li>
<li class="nasa-tax-item cat-item cat-item-911 cat-item-silver-925"><a href="https://duniafesyen.com/product-category/jewelry-watches/material/silver-925/" title="Silver 925" class="nasa-filter-item nasa-filter-by-tax nasa-filter-by-cat">Silver 925</a></li>
	</ul>
</li>
<li class="nasa-tax-item cat-item cat-item-953 cat-item-mens-watches cat-parent nasa-tax-parent li_accordion"><a href="javascript:void(0);" class="accordion" rel="nofollow"></a><a href="https://duniafesyen.com/product-category/jewelry-watches/mens-watches/" title="Men’s Watches" class="nasa-filter-item nasa-filter-by-tax nasa-filter-by-cat">Men’s Watches</a>	<ul class='children'>
<li class="nasa-tax-item cat-item cat-item-954 cat-item-digital-watches"><a href="https://duniafesyen.com/product-category/jewelry-watches/mens-watches/digital-watches/" title="Digital Watches" class="nasa-filter-item nasa-filter-by-tax nasa-filter-by-cat">Digital Watches</a></li>
<li class="nasa-tax-item cat-item cat-item-957 cat-item-mechanical-watches"><a href="https://duniafesyen.com/product-category/jewelry-watches/mens-watches/mechanical-watches/" title="Mechanical Watches" class="nasa-filter-item nasa-filter-by-tax nasa-filter-by-cat">Mechanical Watches</a></li>
<li class="nasa-tax-item cat-item cat-item-958 cat-item-quartz-watches"><a href="https://duniafesyen.com/product-category/jewelry-watches/mens-watches/quartz-watches/" title="Quartz Watches" class="nasa-filter-item nasa-filter-by-tax nasa-filter-by-cat">Quartz Watches</a></li>
<li class="nasa-tax-item cat-item cat-item-955 cat-item-watch-cases"><a href="https://duniafesyen.com/product-category/jewelry-watches/mens-watches/watch-cases/" title="Watch Cases" class="nasa-filter-item nasa-filter-by-tax nasa-filter-by-cat">Watch Cases</a></li>
<li class="nasa-tax-item cat-item cat-item-956 cat-item-watchbands"><a href="https://duniafesyen.com/product-category/jewelry-watches/mens-watches/watchbands/" title="Watchbands" class="nasa-filter-item nasa-filter-by-tax nasa-filter-by-cat">Watchbands</a></li>
	</ul>
</li>
<li class="nasa-tax-item cat-item cat-item-966 cat-item-more-ways-to-shop-jewelry-watches cat-parent nasa-tax-parent li_accordion"><a href="javascript:void(0);" class="accordion" rel="nofollow"></a><a href="https://duniafesyen.com/product-category/jewelry-watches/more-ways-to-shop-jewelry-watches/" title="More Ways to Shop" class="nasa-filter-item nasa-filter-by-tax nasa-filter-by-cat">More Ways to Shop</a>	<ul class='children'>
<li class="nasa-tax-item cat-item cat-item-967 cat-item-top-selling-more-ways-to-shop-jewelry-watches"><a href="https://duniafesyen.com/product-category/jewelry-watches/more-ways-to-shop-jewelry-watches/top-selling-more-ways-to-shop-jewelry-watches/" title="Top Selling" class="nasa-filter-item nasa-filter-by-tax nasa-filter-by-cat">Top Selling</a></li>
	</ul>
</li>
<li class="nasa-tax-item cat-item cat-item-940 cat-item-necklaces cat-parent nasa-tax-parent li_accordion"><a href="javascript:void(0);" class="accordion" rel="nofollow"></a><a href="https://duniafesyen.com/product-category/jewelry-watches/necklaces/" title="Necklaces" class="nasa-filter-item nasa-filter-by-tax nasa-filter-by-cat">Necklaces</a>	<ul class='children'>
<li class="nasa-tax-item cat-item cat-item-944 cat-item-beaded-necklace"><a href="https://duniafesyen.com/product-category/jewelry-watches/necklaces/beaded-necklace/" title="Beaded Necklace" class="nasa-filter-item nasa-filter-by-tax nasa-filter-by-cat">Beaded Necklace</a></li>
<li class="nasa-tax-item cat-item cat-item-943 cat-item-hip-hop-necklace"><a href="https://duniafesyen.com/product-category/jewelry-watches/necklaces/hip-hop-necklace/" title="Hip Hop Necklace" class="nasa-filter-item nasa-filter-by-tax nasa-filter-by-cat">Hip Hop Necklace</a></li>
<li class="nasa-tax-item cat-item cat-item-946 cat-item-layered-necklace"><a href="https://duniafesyen.com/product-category/jewelry-watches/necklaces/layered-necklace/" title="Layered Necklace" class="nasa-filter-item nasa-filter-by-tax nasa-filter-by-cat">Layered Necklace</a></li>
<li class="nasa-tax-item cat-item cat-item-945 cat-item-mens-necklace"><a href="https://duniafesyen.com/product-category/jewelry-watches/necklaces/mens-necklace/" title="Men’s Necklace" class="nasa-filter-item nasa-filter-by-tax nasa-filter-by-cat">Men’s Necklace</a></li>
<li class="nasa-tax-item cat-item cat-item-942 cat-item-silver-necklace"><a href="https://duniafesyen.com/product-category/jewelry-watches/necklaces/silver-necklace/" title="Silver Necklace" class="nasa-filter-item nasa-filter-by-tax nasa-filter-by-cat">Silver Necklace</a></li>
<li class="nasa-tax-item cat-item cat-item-941 cat-item-womens-necklace"><a href="https://duniafesyen.com/product-category/jewelry-watches/necklaces/womens-necklace/" title="Women’s Necklace" class="nasa-filter-item nasa-filter-by-tax nasa-filter-by-cat">Women’s Necklace</a></li>
	</ul>
</li>
<li class="nasa-tax-item cat-item cat-item-959 cat-item-new-in-jewelry-watches cat-parent nasa-tax-parent li_accordion"><a href="javascript:void(0);" class="accordion" rel="nofollow"></a><a href="https://duniafesyen.com/product-category/jewelry-watches/new-in-jewelry-watches/" title="New In" class="nasa-filter-item nasa-filter-by-tax nasa-filter-by-cat">New In</a>	<ul class='children'>
<li class="nasa-tax-item cat-item cat-item-963 cat-item-new-in-bracelets"><a href="https://duniafesyen.com/product-category/jewelry-watches/new-in-jewelry-watches/new-in-bracelets/" title="New in Bracelets" class="nasa-filter-item nasa-filter-by-tax nasa-filter-by-cat">New in Bracelets</a></li>
<li class="nasa-tax-item cat-item cat-item-965 cat-item-new-in-findings"><a href="https://duniafesyen.com/product-category/jewelry-watches/new-in-jewelry-watches/new-in-findings/" title="New in Findings" class="nasa-filter-item nasa-filter-by-tax nasa-filter-by-cat">New in Findings</a></li>
<li class="nasa-tax-item cat-item cat-item-960 cat-item-new-in-keychains"><a href="https://duniafesyen.com/product-category/jewelry-watches/new-in-jewelry-watches/new-in-keychains/" title="New in Keychains" class="nasa-filter-item nasa-filter-by-tax nasa-filter-by-cat">New in Keychains</a></li>
<li class="nasa-tax-item cat-item cat-item-961 cat-item-new-in-mens-watches"><a href="https://duniafesyen.com/product-category/jewelry-watches/new-in-jewelry-watches/new-in-mens-watches/" title="New in Men’s Watches" class="nasa-filter-item nasa-filter-by-tax nasa-filter-by-cat">New in Men’s Watches</a></li>
<li class="nasa-tax-item cat-item cat-item-962 cat-item-new-in-necklaces"><a href="https://duniafesyen.com/product-category/jewelry-watches/new-in-jewelry-watches/new-in-necklaces/" title="New in Necklaces" class="nasa-filter-item nasa-filter-by-tax nasa-filter-by-cat">New in Necklaces</a></li>
<li class="nasa-tax-item cat-item cat-item-964 cat-item-new-in-rings"><a href="https://duniafesyen.com/product-category/jewelry-watches/new-in-jewelry-watches/new-in-rings/" title="New in Rings" class="nasa-filter-item nasa-filter-by-tax nasa-filter-by-cat">New in Rings</a></li>
	</ul>
</li>
<li class="nasa-tax-item cat-item cat-item-916 cat-item-other-jewelry cat-parent nasa-tax-parent li_accordion"><a href="javascript:void(0);" class="accordion" rel="nofollow"></a><a href="https://duniafesyen.com/product-category/jewelry-watches/other-jewelry/" title="Other Jewelry" class="nasa-filter-item nasa-filter-by-tax nasa-filter-by-cat">Other Jewelry</a>	<ul class='children'>
<li class="nasa-tax-item cat-item cat-item-920 cat-item-brooches"><a href="https://duniafesyen.com/product-category/jewelry-watches/other-jewelry/brooches/" title="Brooches" class="nasa-filter-item nasa-filter-by-tax nasa-filter-by-cat">Brooches</a></li>
<li class="nasa-tax-item cat-item cat-item-921 cat-item-hair-jewelry"><a href="https://duniafesyen.com/product-category/jewelry-watches/other-jewelry/hair-jewelry/" title="Hair Jewelry" class="nasa-filter-item nasa-filter-by-tax nasa-filter-by-cat">Hair Jewelry</a></li>
<li class="nasa-tax-item cat-item cat-item-918 cat-item-jewelry-sets"><a href="https://duniafesyen.com/product-category/jewelry-watches/other-jewelry/jewelry-sets/" title="Jewelry Sets" class="nasa-filter-item nasa-filter-by-tax nasa-filter-by-cat">Jewelry Sets</a></li>
<li class="nasa-tax-item cat-item cat-item-919 cat-item-key-chains"><a href="https://duniafesyen.com/product-category/jewelry-watches/other-jewelry/key-chains/" title="Key Chains" class="nasa-filter-item nasa-filter-by-tax nasa-filter-by-cat">Key Chains</a></li>
<li class="nasa-tax-item cat-item cat-item-917 cat-item-tie-clips-cufflinks"><a href="https://duniafesyen.com/product-category/jewelry-watches/other-jewelry/tie-clips-cufflinks/" title="Tie Clips &amp; Cufflinks" class="nasa-filter-item nasa-filter-by-tax nasa-filter-by-cat">Tie Clips &amp; Cufflinks</a></li>
	</ul>
</li>
<li class="nasa-tax-item cat-item cat-item-929 cat-item-watches cat-parent nasa-tax-parent li_accordion"><a href="javascript:void(0);" class="accordion" rel="nofollow"></a><a href="https://duniafesyen.com/product-category/jewelry-watches/watches/" title="Watches" class="nasa-filter-item nasa-filter-by-tax nasa-filter-by-cat">Watches</a>	<ul class='children'>
<li class="nasa-tax-item cat-item cat-item-930 cat-item-electronic-watches"><a href="https://duniafesyen.com/product-category/jewelry-watches/watches/electronic-watches/" title="Electronic Watches" class="nasa-filter-item nasa-filter-by-tax nasa-filter-by-cat">Electronic Watches</a></li>
<li class="nasa-tax-item cat-item cat-item-931 cat-item-fashion-quartz-wristwatches"><a href="https://duniafesyen.com/product-category/jewelry-watches/watches/fashion-quartz-wristwatches/" title="Fashion Quartz Wristwatches" class="nasa-filter-item nasa-filter-by-tax nasa-filter-by-cat">Fashion Quartz Wristwatches</a></li>
<li class="nasa-tax-item cat-item cat-item-932 cat-item-watch-winders"><a href="https://duniafesyen.com/product-category/jewelry-watches/watches/watch-winders/" title="Watch Winders" class="nasa-filter-item nasa-filter-by-tax nasa-filter-by-cat">Watch Winders</a></li>
	</ul>
</li>
</ul>
</li>
<li class="nasa-tax-item cat-item cat-item-1109 cat-item-kid root-item cat-parent nasa-tax-parent li_accordion"><a href="javascript:void(0);" class="accordion" rel="nofollow"></a><a href="https://duniafesyen.com/product-category/kid/" title="Kid" class="nasa-filter-item nasa-filter-by-tax nasa-filter-by-cat">Kid</a><ul class='children'>
<li class="nasa-tax-item cat-item cat-item-1160 cat-item-bikes"><a href="https://duniafesyen.com/product-category/kid/bikes/" title="Bikes" class="nasa-filter-item nasa-filter-by-tax nasa-filter-by-cat">Bikes</a></li>
<li class="nasa-tax-item cat-item cat-item-1163 cat-item-car-seats"><a href="https://duniafesyen.com/product-category/kid/car-seats/" title="Car Seats" class="nasa-filter-item nasa-filter-by-tax nasa-filter-by-cat">Car Seats</a></li>
<li class="nasa-tax-item cat-item cat-item-1166 cat-item-clothing-kids"><a href="https://duniafesyen.com/product-category/kid/clothing-kids/" title="Clothing" class="nasa-filter-item nasa-filter-by-tax nasa-filter-by-cat">Clothing</a></li>
<li class="nasa-tax-item cat-item cat-item-1168 cat-item-diapers"><a href="https://duniafesyen.com/product-category/kid/diapers/" title="Diapers" class="nasa-filter-item nasa-filter-by-tax nasa-filter-by-cat">Diapers</a></li>
<li class="nasa-tax-item cat-item cat-item-1116 cat-item-mumz"><a href="https://duniafesyen.com/product-category/kid/mumz/" title="Mumz" class="nasa-filter-item nasa-filter-by-tax nasa-filter-by-cat">Mumz</a></li>
<li class="nasa-tax-item cat-item cat-item-1138 cat-item-toys"><a href="https://duniafesyen.com/product-category/kid/toys/" title="Toys" class="nasa-filter-item nasa-filter-by-tax nasa-filter-by-cat">Toys</a></li>
</ul>
</li>
<li class="nasa-tax-item cat-item cat-item-837 cat-item-luggages-bags root-item cat-parent nasa-tax-parent li_accordion"><a href="javascript:void(0);" class="accordion" rel="nofollow"></a><a href="https://duniafesyen.com/product-category/luggages-bags/" title="Luggages &amp; Bags" class="nasa-filter-item nasa-filter-by-tax nasa-filter-by-cat">Luggages &amp; Bags</a><ul class='children'>
<li class="nasa-tax-item cat-item cat-item-852 cat-item-backpacks cat-parent nasa-tax-parent li_accordion"><a href="javascript:void(0);" class="accordion" rel="nofollow"></a><a href="https://duniafesyen.com/product-category/luggages-bags/backpacks/" title="Backpacks" class="nasa-filter-item nasa-filter-by-tax nasa-filter-by-cat">Backpacks</a>	<ul class='children'>
<li class="nasa-tax-item cat-item cat-item-855 cat-item-anti-theft-backpack"><a href="https://duniafesyen.com/product-category/luggages-bags/backpacks/anti-theft-backpack/" title="Anti-Theft Backpack" class="nasa-filter-item nasa-filter-by-tax nasa-filter-by-cat">Anti-Theft Backpack</a></li>
<li class="nasa-tax-item cat-item cat-item-853 cat-item-business-backpack"><a href="https://duniafesyen.com/product-category/luggages-bags/backpacks/business-backpack/" title="Business Backpack" class="nasa-filter-item nasa-filter-by-tax nasa-filter-by-cat">Business Backpack</a></li>
<li class="nasa-tax-item cat-item cat-item-857 cat-item-business-garment-bag"><a href="https://duniafesyen.com/product-category/luggages-bags/backpacks/business-garment-bag/" title="Business Garment Bag" class="nasa-filter-item nasa-filter-by-tax nasa-filter-by-cat">Business Garment Bag</a></li>
<li class="nasa-tax-item cat-item cat-item-854 cat-item-high-capacity-backpack"><a href="https://duniafesyen.com/product-category/luggages-bags/backpacks/high-capacity-backpack/" title="High-Capacity Backpack" class="nasa-filter-item nasa-filter-by-tax nasa-filter-by-cat">High-Capacity Backpack</a></li>
<li class="nasa-tax-item cat-item cat-item-856 cat-item-outdoor-backpack"><a href="https://duniafesyen.com/product-category/luggages-bags/backpacks/outdoor-backpack/" title="Outdoor Backpack" class="nasa-filter-item nasa-filter-by-tax nasa-filter-by-cat">Outdoor Backpack</a></li>
<li class="nasa-tax-item cat-item cat-item-858 cat-item-waterproof-backpack"><a href="https://duniafesyen.com/product-category/luggages-bags/backpacks/waterproof-backpack/" title="Waterproof Backpack" class="nasa-filter-item nasa-filter-by-tax nasa-filter-by-cat">Waterproof Backpack</a></li>
	</ul>
</li>
<li class="nasa-tax-item cat-item cat-item-838 cat-item-handbags cat-parent nasa-tax-parent li_accordion"><a href="javascript:void(0);" class="accordion" rel="nofollow"></a><a href="https://duniafesyen.com/product-category/luggages-bags/handbags/" title="Handbags" class="nasa-filter-item nasa-filter-by-tax nasa-filter-by-cat">Handbags</a>	<ul class='children'>
<li class="nasa-tax-item cat-item cat-item-844 cat-item-baguette-bag"><a href="https://duniafesyen.com/product-category/luggages-bags/handbags/baguette-bag/" title="Baguette Bag" class="nasa-filter-item nasa-filter-by-tax nasa-filter-by-cat">Baguette Bag</a></li>
<li class="nasa-tax-item cat-item cat-item-842 cat-item-boston-bag"><a href="https://duniafesyen.com/product-category/luggages-bags/handbags/boston-bag/" title="Boston Bag" class="nasa-filter-item nasa-filter-by-tax nasa-filter-by-cat">Boston Bag</a></li>
<li class="nasa-tax-item cat-item cat-item-839 cat-item-bucket-bag"><a href="https://duniafesyen.com/product-category/luggages-bags/handbags/bucket-bag/" title="Bucket Bag" class="nasa-filter-item nasa-filter-by-tax nasa-filter-by-cat">Bucket Bag</a></li>
<li class="nasa-tax-item cat-item cat-item-840 cat-item-hobo-bags"><a href="https://duniafesyen.com/product-category/luggages-bags/handbags/hobo-bags/" title="Hobo Bags" class="nasa-filter-item nasa-filter-by-tax nasa-filter-by-cat">Hobo Bags</a></li>
<li class="nasa-tax-item cat-item cat-item-843 cat-item-messenger-bag"><a href="https://duniafesyen.com/product-category/luggages-bags/handbags/messenger-bag/" title="Messenger Bag" class="nasa-filter-item nasa-filter-by-tax nasa-filter-by-cat">Messenger Bag</a></li>
<li class="nasa-tax-item cat-item cat-item-841 cat-item-square-bag"><a href="https://duniafesyen.com/product-category/luggages-bags/handbags/square-bag/" title="Square Bag" class="nasa-filter-item nasa-filter-by-tax nasa-filter-by-cat">Square Bag</a></li>
	</ul>
</li>
<li class="nasa-tax-item cat-item cat-item-859 cat-item-mens-bags cat-parent nasa-tax-parent li_accordion"><a href="javascript:void(0);" class="accordion" rel="nofollow"></a><a href="https://duniafesyen.com/product-category/luggages-bags/mens-bags/" title="Men’s Bags" class="nasa-filter-item nasa-filter-by-tax nasa-filter-by-cat">Men’s Bags</a>	<ul class='children'>
<li class="nasa-tax-item cat-item cat-item-861 cat-item-briefcases"><a href="https://duniafesyen.com/product-category/luggages-bags/mens-bags/briefcases/" title="Briefcases" class="nasa-filter-item nasa-filter-by-tax nasa-filter-by-cat">Briefcases</a></li>
<li class="nasa-tax-item cat-item cat-item-862 cat-item-chest-bags"><a href="https://duniafesyen.com/product-category/luggages-bags/mens-bags/chest-bags/" title="Chest Bags" class="nasa-filter-item nasa-filter-by-tax nasa-filter-by-cat">Chest Bags</a></li>
<li class="nasa-tax-item cat-item cat-item-863 cat-item-crossbody-bags"><a href="https://duniafesyen.com/product-category/luggages-bags/mens-bags/crossbody-bags/" title="Crossbody Bags" class="nasa-filter-item nasa-filter-by-tax nasa-filter-by-cat">Crossbody Bags</a></li>
<li class="nasa-tax-item cat-item cat-item-860 cat-item-shoulder-bags"><a href="https://duniafesyen.com/product-category/luggages-bags/mens-bags/shoulder-bags/" title="Shoulder Bags" class="nasa-filter-item nasa-filter-by-tax nasa-filter-by-cat">Shoulder Bags</a></li>
<li class="nasa-tax-item cat-item cat-item-864 cat-item-waist-packs"><a href="https://duniafesyen.com/product-category/luggages-bags/mens-bags/waist-packs/" title="Waist Packs" class="nasa-filter-item nasa-filter-by-tax nasa-filter-by-cat">Waist Packs</a></li>
	</ul>
</li>
<li class="nasa-tax-item cat-item cat-item-899 cat-item-more-ways-to-shop-luggages-bags cat-parent nasa-tax-parent li_accordion"><a href="javascript:void(0);" class="accordion" rel="nofollow"></a><a href="https://duniafesyen.com/product-category/luggages-bags/more-ways-to-shop-luggages-bags/" title="More Ways to Shop" class="nasa-filter-item nasa-filter-by-tax nasa-filter-by-cat">More Ways to Shop</a>	<ul class='children'>
<li class="nasa-tax-item cat-item cat-item-900 cat-item-top-selling-more-ways-to-shop-luggages-bags"><a href="https://duniafesyen.com/product-category/luggages-bags/more-ways-to-shop-luggages-bags/top-selling-more-ways-to-shop-luggages-bags/" title="Top Selling" class="nasa-filter-item nasa-filter-by-tax nasa-filter-by-cat">Top Selling</a></li>
	</ul>
</li>
<li class="nasa-tax-item cat-item cat-item-877 cat-item-multi-purpose-bag cat-parent nasa-tax-parent li_accordion"><a href="javascript:void(0);" class="accordion" rel="nofollow"></a><a href="https://duniafesyen.com/product-category/luggages-bags/multi-purpose-bag/" title="Multi-Purpose Bag" class="nasa-filter-item nasa-filter-by-tax nasa-filter-by-cat">Multi-Purpose Bag</a>	<ul class='children'>
<li class="nasa-tax-item cat-item cat-item-881 cat-item-cooler-bag"><a href="https://duniafesyen.com/product-category/luggages-bags/multi-purpose-bag/cooler-bag/" title="Cooler Bag" class="nasa-filter-item nasa-filter-by-tax nasa-filter-by-cat">Cooler Bag</a></li>
<li class="nasa-tax-item cat-item cat-item-880 cat-item-cosmetic-bag-case"><a href="https://duniafesyen.com/product-category/luggages-bags/multi-purpose-bag/cosmetic-bag-case/" title="Cosmetic Bag &amp; Case" class="nasa-filter-item nasa-filter-by-tax nasa-filter-by-cat">Cosmetic Bag &amp; Case</a></li>
<li class="nasa-tax-item cat-item cat-item-878 cat-item-drawstring-bag"><a href="https://duniafesyen.com/product-category/luggages-bags/multi-purpose-bag/drawstring-bag/" title="Drawstring Bag" class="nasa-filter-item nasa-filter-by-tax nasa-filter-by-cat">Drawstring Bag</a></li>
<li class="nasa-tax-item cat-item cat-item-882 cat-item-lunch-bag"><a href="https://duniafesyen.com/product-category/luggages-bags/multi-purpose-bag/lunch-bag/" title="Lunch Bag" class="nasa-filter-item nasa-filter-by-tax nasa-filter-by-cat">Lunch Bag</a></li>
<li class="nasa-tax-item cat-item cat-item-879 cat-item-shopping-bag"><a href="https://duniafesyen.com/product-category/luggages-bags/multi-purpose-bag/shopping-bag/" title="Shopping Bag" class="nasa-filter-item nasa-filter-by-tax nasa-filter-by-cat">Shopping Bag</a></li>
	</ul>
</li>
<li class="nasa-tax-item cat-item cat-item-896 cat-item-new-in-luggages-bags cat-parent nasa-tax-parent li_accordion"><a href="javascript:void(0);" class="accordion" rel="nofollow"></a><a href="https://duniafesyen.com/product-category/luggages-bags/new-in-luggages-bags/" title="New In" class="nasa-filter-item nasa-filter-by-tax nasa-filter-by-cat">New In</a>	<ul class='children'>
<li class="nasa-tax-item cat-item cat-item-898 cat-item-new-in-backpack"><a href="https://duniafesyen.com/product-category/luggages-bags/new-in-luggages-bags/new-in-backpack/" title="New in Backpack" class="nasa-filter-item nasa-filter-by-tax nasa-filter-by-cat">New in Backpack</a></li>
<li class="nasa-tax-item cat-item cat-item-897 cat-item-new-in-handbag"><a href="https://duniafesyen.com/product-category/luggages-bags/new-in-luggages-bags/new-in-handbag/" title="New in Handbag" class="nasa-filter-item nasa-filter-by-tax nasa-filter-by-cat">New in Handbag</a></li>
	</ul>
</li>
<li class="nasa-tax-item cat-item cat-item-883 cat-item-other-bags-accessories cat-parent nasa-tax-parent li_accordion"><a href="javascript:void(0);" class="accordion" rel="nofollow"></a><a href="https://duniafesyen.com/product-category/luggages-bags/other-bags-accessories/" title="Other Bags &amp; Accessories" class="nasa-filter-item nasa-filter-by-tax nasa-filter-by-cat">Other Bags &amp; Accessories</a>	<ul class='children'>
<li class="nasa-tax-item cat-item cat-item-887 cat-item-bag-accessories"><a href="https://duniafesyen.com/product-category/luggages-bags/other-bags-accessories/bag-accessories/" title="Bag Accessories" class="nasa-filter-item nasa-filter-by-tax nasa-filter-by-cat">Bag Accessories</a></li>
<li class="nasa-tax-item cat-item cat-item-888 cat-item-diy-bags"><a href="https://duniafesyen.com/product-category/luggages-bags/other-bags-accessories/diy-bags/" title="DIY Bags" class="nasa-filter-item nasa-filter-by-tax nasa-filter-by-cat">DIY Bags</a></li>
<li class="nasa-tax-item cat-item cat-item-886 cat-item-luggage-covers"><a href="https://duniafesyen.com/product-category/luggages-bags/other-bags-accessories/luggage-covers/" title="Luggage Covers" class="nasa-filter-item nasa-filter-by-tax nasa-filter-by-cat">Luggage Covers</a></li>
<li class="nasa-tax-item cat-item cat-item-885 cat-item-luggage-tags"><a href="https://duniafesyen.com/product-category/luggages-bags/other-bags-accessories/luggage-tags/" title="Luggage Tags" class="nasa-filter-item nasa-filter-by-tax nasa-filter-by-cat">Luggage Tags</a></li>
<li class="nasa-tax-item cat-item cat-item-884 cat-item-other-kids-bags"><a href="https://duniafesyen.com/product-category/luggages-bags/other-bags-accessories/other-kids-bags/" title="Other Kid’s Bags" class="nasa-filter-item nasa-filter-by-tax nasa-filter-by-cat">Other Kid’s Bags</a></li>
	</ul>
</li>
<li class="nasa-tax-item cat-item cat-item-889 cat-item-shoulder-bags-luggages-bags cat-parent nasa-tax-parent li_accordion"><a href="javascript:void(0);" class="accordion" rel="nofollow"></a><a href="https://duniafesyen.com/product-category/luggages-bags/shoulder-bags-luggages-bags/" title="Shoulder Bags" class="nasa-filter-item nasa-filter-by-tax nasa-filter-by-cat">Shoulder Bags</a>	<ul class='children'>
<li class="nasa-tax-item cat-item cat-item-893 cat-item-animal-print-shoulder-bag"><a href="https://duniafesyen.com/product-category/luggages-bags/shoulder-bags-luggages-bags/animal-print-shoulder-bag/" title="Animal Print Shoulder Bag" class="nasa-filter-item nasa-filter-by-tax nasa-filter-by-cat">Animal Print Shoulder Bag</a></li>
<li class="nasa-tax-item cat-item cat-item-892 cat-item-canvas-shoulder-bag"><a href="https://duniafesyen.com/product-category/luggages-bags/shoulder-bags-luggages-bags/canvas-shoulder-bag/" title="Canvas Shoulder Bag" class="nasa-filter-item nasa-filter-by-tax nasa-filter-by-cat">Canvas Shoulder Bag</a></li>
<li class="nasa-tax-item cat-item cat-item-895 cat-item-chain-bag"><a href="https://duniafesyen.com/product-category/luggages-bags/shoulder-bags-luggages-bags/chain-bag/" title="Chain Bag" class="nasa-filter-item nasa-filter-by-tax nasa-filter-by-cat">Chain Bag</a></li>
<li class="nasa-tax-item cat-item cat-item-894 cat-item-denim-shoulder-bag"><a href="https://duniafesyen.com/product-category/luggages-bags/shoulder-bags-luggages-bags/denim-shoulder-bag/" title="Denim Shoulder Bag" class="nasa-filter-item nasa-filter-by-tax nasa-filter-by-cat">Denim Shoulder Bag</a></li>
<li class="nasa-tax-item cat-item cat-item-891 cat-item-fur-shoulder-bag"><a href="https://duniafesyen.com/product-category/luggages-bags/shoulder-bags-luggages-bags/fur-shoulder-bag/" title="Fur Shoulder Bag" class="nasa-filter-item nasa-filter-by-tax nasa-filter-by-cat">Fur Shoulder Bag</a></li>
<li class="nasa-tax-item cat-item cat-item-890 cat-item-pillow-shoulder-bag"><a href="https://duniafesyen.com/product-category/luggages-bags/shoulder-bags-luggages-bags/pillow-shoulder-bag/" title="Pillow Shoulder Bag" class="nasa-filter-item nasa-filter-by-tax nasa-filter-by-cat">Pillow Shoulder Bag</a></li>
	</ul>
</li>
<li class="nasa-tax-item cat-item cat-item-871 cat-item-travel-bags-luggage cat-parent nasa-tax-parent li_accordion"><a href="javascript:void(0);" class="accordion" rel="nofollow"></a><a href="https://duniafesyen.com/product-category/luggages-bags/travel-bags-luggage/" title="Travel Bags &amp; Luggage" class="nasa-filter-item nasa-filter-by-tax nasa-filter-by-cat">Travel Bags &amp; Luggage</a>	<ul class='children'>
<li class="nasa-tax-item cat-item cat-item-876 cat-item-carry-ons-luggage"><a href="https://duniafesyen.com/product-category/luggages-bags/travel-bags-luggage/carry-ons-luggage/" title="Carry-Ons Luggage" class="nasa-filter-item nasa-filter-by-tax nasa-filter-by-cat">Carry-Ons Luggage</a></li>
<li class="nasa-tax-item cat-item cat-item-875 cat-item-kids-luggage"><a href="https://duniafesyen.com/product-category/luggages-bags/travel-bags-luggage/kids-luggage/" title="Kid’s Luggage" class="nasa-filter-item nasa-filter-by-tax nasa-filter-by-cat">Kid’s Luggage</a></li>
<li class="nasa-tax-item cat-item cat-item-873 cat-item-large-size-luggage"><a href="https://duniafesyen.com/product-category/luggages-bags/travel-bags-luggage/large-size-luggage/" title="Large Size Luggage" class="nasa-filter-item nasa-filter-by-tax nasa-filter-by-cat">Large Size Luggage</a></li>
<li class="nasa-tax-item cat-item cat-item-874 cat-item-middle-size-luggage"><a href="https://duniafesyen.com/product-category/luggages-bags/travel-bags-luggage/middle-size-luggage/" title="Middle Size Luggage" class="nasa-filter-item nasa-filter-by-tax nasa-filter-by-cat">Middle Size Luggage</a></li>
<li class="nasa-tax-item cat-item cat-item-872 cat-item-travel-bag"><a href="https://duniafesyen.com/product-category/luggages-bags/travel-bags-luggage/travel-bag/" title="Travel Bag" class="nasa-filter-item nasa-filter-by-tax nasa-filter-by-cat">Travel Bag</a></li>
	</ul>
</li>
<li class="nasa-tax-item cat-item cat-item-865 cat-item-waist-packs-luggages-bags cat-parent nasa-tax-parent li_accordion"><a href="javascript:void(0);" class="accordion" rel="nofollow"></a><a href="https://duniafesyen.com/product-category/luggages-bags/waist-packs-luggages-bags/" title="Waist Packs" class="nasa-filter-item nasa-filter-by-tax nasa-filter-by-cat">Waist Packs</a>	<ul class='children'>
<li class="nasa-tax-item cat-item cat-item-869 cat-item-canvas-waist-pack"><a href="https://duniafesyen.com/product-category/luggages-bags/waist-packs-luggages-bags/canvas-waist-pack/" title="Canvas Waist Pack" class="nasa-filter-item nasa-filter-by-tax nasa-filter-by-cat">Canvas Waist Pack</a></li>
<li class="nasa-tax-item cat-item cat-item-867 cat-item-chain-waist-pack"><a href="https://duniafesyen.com/product-category/luggages-bags/waist-packs-luggages-bags/chain-waist-pack/" title="Chain Waist Pack" class="nasa-filter-item nasa-filter-by-tax nasa-filter-by-cat">Chain Waist Pack</a></li>
<li class="nasa-tax-item cat-item cat-item-866 cat-item-leather-waist-pack"><a href="https://duniafesyen.com/product-category/luggages-bags/waist-packs-luggages-bags/leather-waist-pack/" title="Leather Waist Pack" class="nasa-filter-item nasa-filter-by-tax nasa-filter-by-cat">Leather Waist Pack</a></li>
<li class="nasa-tax-item cat-item cat-item-870 cat-item-print-waist-pack"><a href="https://duniafesyen.com/product-category/luggages-bags/waist-packs-luggages-bags/print-waist-pack/" title="Print Waist Pack" class="nasa-filter-item nasa-filter-by-tax nasa-filter-by-cat">Print Waist Pack</a></li>
<li class="nasa-tax-item cat-item cat-item-868 cat-item-sport-waist-pack"><a href="https://duniafesyen.com/product-category/luggages-bags/waist-packs-luggages-bags/sport-waist-pack/" title="Sport Waist Pack" class="nasa-filter-item nasa-filter-by-tax nasa-filter-by-cat">Sport Waist Pack</a></li>
	</ul>
</li>
<li class="nasa-tax-item cat-item cat-item-845 cat-item-wallet-id-holder cat-parent nasa-tax-parent li_accordion"><a href="javascript:void(0);" class="accordion" rel="nofollow"></a><a href="https://duniafesyen.com/product-category/luggages-bags/wallet-id-holder/" title="Wallet &amp; ID Holder" class="nasa-filter-item nasa-filter-by-tax nasa-filter-by-cat">Wallet &amp; ID Holder</a>	<ul class='children'>
<li class="nasa-tax-item cat-item cat-item-849 cat-item-credit-card-holder"><a href="https://duniafesyen.com/product-category/luggages-bags/wallet-id-holder/credit-card-holder/" title="Credit Card Holder" class="nasa-filter-item nasa-filter-by-tax nasa-filter-by-cat">Credit Card Holder</a></li>
<li class="nasa-tax-item cat-item cat-item-851 cat-item-mens-fold-wallet"><a href="https://duniafesyen.com/product-category/luggages-bags/wallet-id-holder/mens-fold-wallet/" title="Men’s Fold Wallet" class="nasa-filter-item nasa-filter-by-tax nasa-filter-by-cat">Men’s Fold Wallet</a></li>
<li class="nasa-tax-item cat-item cat-item-850 cat-item-mens-leather-wallet"><a href="https://duniafesyen.com/product-category/luggages-bags/wallet-id-holder/mens-leather-wallet/" title="Men’s Leather Wallet" class="nasa-filter-item nasa-filter-by-tax nasa-filter-by-cat">Men’s Leather Wallet</a></li>
<li class="nasa-tax-item cat-item cat-item-846 cat-item-mens-wallet-with-zipper"><a href="https://duniafesyen.com/product-category/luggages-bags/wallet-id-holder/mens-wallet-with-zipper/" title="Men’s Wallet with Zipper" class="nasa-filter-item nasa-filter-by-tax nasa-filter-by-cat">Men’s Wallet with Zipper</a></li>
<li class="nasa-tax-item cat-item cat-item-847 cat-item-travel-wallets"><a href="https://duniafesyen.com/product-category/luggages-bags/wallet-id-holder/travel-wallets/" title="Travel Wallets" class="nasa-filter-item nasa-filter-by-tax nasa-filter-by-cat">Travel Wallets</a></li>
<li class="nasa-tax-item cat-item cat-item-848 cat-item-womens-fold-wallet"><a href="https://duniafesyen.com/product-category/luggages-bags/wallet-id-holder/womens-fold-wallet/" title="Women’s Fold Wallet" class="nasa-filter-item nasa-filter-by-tax nasa-filter-by-cat">Women’s Fold Wallet</a></li>
	</ul>
</li>
</ul>
</li>
<li class="nasa-tax-item cat-item cat-item-1114 cat-item-men root-item cat-parent nasa-tax-parent li_accordion"><a href="javascript:void(0);" class="accordion" rel="nofollow"></a><a href="https://duniafesyen.com/product-category/men/" title="Men" class="nasa-filter-item nasa-filter-by-tax nasa-filter-by-cat">Men</a><ul class='children'>
<li class="nasa-tax-item cat-item cat-item-1155 cat-item-accessories-men"><a href="https://duniafesyen.com/product-category/men/accessories-men/" title="Accessories" class="nasa-filter-item nasa-filter-by-tax nasa-filter-by-cat">Accessories</a></li>
<li class="nasa-tax-item cat-item cat-item-1157 cat-item-bags-men"><a href="https://duniafesyen.com/product-category/men/bags-men/" title="Bags" class="nasa-filter-item nasa-filter-by-tax nasa-filter-by-cat">Bags</a></li>
<li class="nasa-tax-item cat-item cat-item-1164 cat-item-clothing-men cat-parent nasa-tax-parent li_accordion"><a href="javascript:void(0);" class="accordion" rel="nofollow"></a><a href="https://duniafesyen.com/product-category/men/clothing-men/" title="Clothing" class="nasa-filter-item nasa-filter-by-tax nasa-filter-by-cat">Clothing</a>	<ul class='children'>
<li class="nasa-tax-item cat-item cat-item-1180 cat-item-outerwear-men"><a href="https://duniafesyen.com/product-category/men/clothing-men/outerwear-men/" title="Outerwear" class="nasa-filter-item nasa-filter-by-tax nasa-filter-by-cat">Outerwear</a></li>
<li class="nasa-tax-item cat-item cat-item-1182 cat-item-pants-men"><a href="https://duniafesyen.com/product-category/men/clothing-men/pants-men/" title="Pants" class="nasa-filter-item nasa-filter-by-tax nasa-filter-by-cat">Pants</a></li>
<li class="nasa-tax-item cat-item cat-item-1186 cat-item-shirts-men"><a href="https://duniafesyen.com/product-category/men/clothing-men/shirts-men/" title="Shirts" class="nasa-filter-item nasa-filter-by-tax nasa-filter-by-cat">Shirts</a></li>
<li class="nasa-tax-item cat-item cat-item-1188 cat-item-shorts-men"><a href="https://duniafesyen.com/product-category/men/clothing-men/shorts-men/" title="Shorts" class="nasa-filter-item nasa-filter-by-tax nasa-filter-by-cat">Shorts</a></li>
<li class="nasa-tax-item cat-item cat-item-1190 cat-item-sweaters-men"><a href="https://duniafesyen.com/product-category/men/clothing-men/sweaters-men/" title="Sweaters" class="nasa-filter-item nasa-filter-by-tax nasa-filter-by-cat">Sweaters</a></li>
<li class="nasa-tax-item cat-item cat-item-1193 cat-item-swim-men"><a href="https://duniafesyen.com/product-category/men/clothing-men/swim-men/" title="Swim" class="nasa-filter-item nasa-filter-by-tax nasa-filter-by-cat">Swim</a></li>
	</ul>
</li>
<li class="nasa-tax-item cat-item cat-item-1170 cat-item-grooming-men cat-parent nasa-tax-parent li_accordion"><a href="javascript:void(0);" class="accordion" rel="nofollow"></a><a href="https://duniafesyen.com/product-category/men/grooming-men/" title="Grooming" class="nasa-filter-item nasa-filter-by-tax nasa-filter-by-cat">Grooming</a>	<ul class='children'>
<li class="nasa-tax-item cat-item cat-item-1171 cat-item-hair-men"><a href="https://duniafesyen.com/product-category/men/grooming-men/hair-men/" title="Hair" class="nasa-filter-item nasa-filter-by-tax nasa-filter-by-cat">Hair</a></li>
<li class="nasa-tax-item cat-item cat-item-1189 cat-item-skin-men"><a href="https://duniafesyen.com/product-category/men/grooming-men/skin-men/" title="Skin" class="nasa-filter-item nasa-filter-by-tax nasa-filter-by-cat">Skin</a></li>
<li class="nasa-tax-item cat-item cat-item-1197 cat-item-toiletry-cases-men"><a href="https://duniafesyen.com/product-category/men/grooming-men/toiletry-cases-men/" title="Toiletry Cases" class="nasa-filter-item nasa-filter-by-tax nasa-filter-by-cat">Toiletry Cases</a></li>
	</ul>
</li>
<li class="nasa-tax-item cat-item cat-item-1129 cat-item-shoes-men cat-parent nasa-tax-parent li_accordion"><a href="javascript:void(0);" class="accordion" rel="nofollow"></a><a href="https://duniafesyen.com/product-category/men/shoes-men/" title="Shoes" class="nasa-filter-item nasa-filter-by-tax nasa-filter-by-cat">Shoes</a>	<ul class='children'>
<li class="nasa-tax-item cat-item cat-item-1161 cat-item-boots-men"><a href="https://duniafesyen.com/product-category/men/shoes-men/boots-men/" title="Boots" class="nasa-filter-item nasa-filter-by-tax nasa-filter-by-cat">Boots</a></li>
<li class="nasa-tax-item cat-item cat-item-1185 cat-item-sandals-men"><a href="https://duniafesyen.com/product-category/men/shoes-men/sandals-men/" title="Sandals" class="nasa-filter-item nasa-filter-by-tax nasa-filter-by-cat">Sandals</a></li>
<li class="nasa-tax-item cat-item cat-item-1131 cat-item-sneakers-men"><a href="https://duniafesyen.com/product-category/men/shoes-men/sneakers-men/" title="Sneakers" class="nasa-filter-item nasa-filter-by-tax nasa-filter-by-cat">Sneakers</a></li>
	</ul>
</li>
</ul>
</li>
<li class="nasa-tax-item cat-item cat-item-801 cat-item-mens-clothing root-item cat-parent nasa-tax-parent li_accordion"><a href="javascript:void(0);" class="accordion" rel="nofollow"></a><a href="https://duniafesyen.com/product-category/mens-clothing/" title="Men&#039;s Clothing" class="nasa-filter-item nasa-filter-by-tax nasa-filter-by-cat">Men's Clothing</a><ul class='children'>
<li class="nasa-tax-item cat-item cat-item-826 cat-item-accessories cat-parent nasa-tax-parent li_accordion"><a href="javascript:void(0);" class="accordion" rel="nofollow"></a><a href="https://duniafesyen.com/product-category/mens-clothing/accessories/" title="Accessories" class="nasa-filter-item nasa-filter-by-tax nasa-filter-by-cat">Accessories</a>	<ul class='children'>
<li class="nasa-tax-item cat-item cat-item-827 cat-item-belts"><a href="https://duniafesyen.com/product-category/mens-clothing/accessories/belts/" title="Belts" class="nasa-filter-item nasa-filter-by-tax nasa-filter-by-cat">Belts</a></li>
<li class="nasa-tax-item cat-item cat-item-829 cat-item-gloves"><a href="https://duniafesyen.com/product-category/mens-clothing/accessories/gloves/" title="Gloves" class="nasa-filter-item nasa-filter-by-tax nasa-filter-by-cat">Gloves</a></li>
<li class="nasa-tax-item cat-item cat-item-828 cat-item-hats"><a href="https://duniafesyen.com/product-category/mens-clothing/accessories/hats/" title="Hats" class="nasa-filter-item nasa-filter-by-tax nasa-filter-by-cat">Hats</a></li>
<li class="nasa-tax-item cat-item cat-item-830 cat-item-scarves"><a href="https://duniafesyen.com/product-category/mens-clothing/accessories/scarves/" title="Scarves" class="nasa-filter-item nasa-filter-by-tax nasa-filter-by-cat">Scarves</a></li>
<li class="nasa-tax-item cat-item cat-item-831 cat-item-sunglasses"><a href="https://duniafesyen.com/product-category/mens-clothing/accessories/sunglasses/" title="Sunglasses" class="nasa-filter-item nasa-filter-by-tax nasa-filter-by-cat">Sunglasses</a></li>
	</ul>
</li>
<li class="nasa-tax-item cat-item cat-item-818 cat-item-activewear cat-parent nasa-tax-parent li_accordion"><a href="javascript:void(0);" class="accordion" rel="nofollow"></a><a href="https://duniafesyen.com/product-category/mens-clothing/activewear/" title="Activewear" class="nasa-filter-item nasa-filter-by-tax nasa-filter-by-cat">Activewear</a>	<ul class='children'>
<li class="nasa-tax-item cat-item cat-item-820 cat-item-gym-shorts"><a href="https://duniafesyen.com/product-category/mens-clothing/activewear/gym-shorts/" title="Gym Shorts" class="nasa-filter-item nasa-filter-by-tax nasa-filter-by-cat">Gym Shorts</a></li>
<li class="nasa-tax-item cat-item cat-item-821 cat-item-sports-jackets"><a href="https://duniafesyen.com/product-category/mens-clothing/activewear/sports-jackets/" title="Sports Jackets" class="nasa-filter-item nasa-filter-by-tax nasa-filter-by-cat">Sports Jackets</a></li>
<li class="nasa-tax-item cat-item cat-item-819 cat-item-tracksuits"><a href="https://duniafesyen.com/product-category/mens-clothing/activewear/tracksuits/" title="Tracksuits" class="nasa-filter-item nasa-filter-by-tax nasa-filter-by-cat">Tracksuits</a></li>
	</ul>
</li>
<li class="nasa-tax-item cat-item cat-item-808 cat-item-bottoms-mens-clothing cat-parent nasa-tax-parent li_accordion"><a href="javascript:void(0);" class="accordion" rel="nofollow"></a><a href="https://duniafesyen.com/product-category/mens-clothing/bottoms-mens-clothing/" title="Bottoms" class="nasa-filter-item nasa-filter-by-tax nasa-filter-by-cat">Bottoms</a>	<ul class='children'>
<li class="nasa-tax-item cat-item cat-item-810 cat-item-cargo-pants"><a href="https://duniafesyen.com/product-category/mens-clothing/bottoms-mens-clothing/cargo-pants/" title="Cargo Pants" class="nasa-filter-item nasa-filter-by-tax nasa-filter-by-cat">Cargo Pants</a></li>
<li class="nasa-tax-item cat-item cat-item-813 cat-item-dress-pants"><a href="https://duniafesyen.com/product-category/mens-clothing/bottoms-mens-clothing/dress-pants/" title="Dress Pants" class="nasa-filter-item nasa-filter-by-tax nasa-filter-by-cat">Dress Pants</a></li>
<li class="nasa-tax-item cat-item cat-item-809 cat-item-jeans-bottoms-mens-clothing"><a href="https://duniafesyen.com/product-category/mens-clothing/bottoms-mens-clothing/jeans-bottoms-mens-clothing/" title="Jeans" class="nasa-filter-item nasa-filter-by-tax nasa-filter-by-cat">Jeans</a></li>
<li class="nasa-tax-item cat-item cat-item-811 cat-item-shorts-bottoms-mens-clothing"><a href="https://duniafesyen.com/product-category/mens-clothing/bottoms-mens-clothing/shorts-bottoms-mens-clothing/" title="Shorts" class="nasa-filter-item nasa-filter-by-tax nasa-filter-by-cat">Shorts</a></li>
<li class="nasa-tax-item cat-item cat-item-812 cat-item-sweatpants"><a href="https://duniafesyen.com/product-category/mens-clothing/bottoms-mens-clothing/sweatpants/" title="Sweatpants" class="nasa-filter-item nasa-filter-by-tax nasa-filter-by-cat">Sweatpants</a></li>
	</ul>
</li>
<li class="nasa-tax-item cat-item cat-item-814 cat-item-outerwear cat-parent nasa-tax-parent li_accordion"><a href="javascript:void(0);" class="accordion" rel="nofollow"></a><a href="https://duniafesyen.com/product-category/mens-clothing/outerwear/" title="Outerwear" class="nasa-filter-item nasa-filter-by-tax nasa-filter-by-cat">Outerwear</a>	<ul class='children'>
<li class="nasa-tax-item cat-item cat-item-816 cat-item-blazers"><a href="https://duniafesyen.com/product-category/mens-clothing/outerwear/blazers/" title="Blazers" class="nasa-filter-item nasa-filter-by-tax nasa-filter-by-cat">Blazers</a></li>
<li class="nasa-tax-item cat-item cat-item-815 cat-item-jackets-coats"><a href="https://duniafesyen.com/product-category/mens-clothing/outerwear/jackets-coats/" title="Jackets &amp; Coats" class="nasa-filter-item nasa-filter-by-tax nasa-filter-by-cat">Jackets &amp; Coats</a></li>
<li class="nasa-tax-item cat-item cat-item-817 cat-item-vests"><a href="https://duniafesyen.com/product-category/mens-clothing/outerwear/vests/" title="Vests" class="nasa-filter-item nasa-filter-by-tax nasa-filter-by-cat">Vests</a></li>
	</ul>
</li>
<li class="nasa-tax-item cat-item cat-item-832 cat-item-shoes cat-parent nasa-tax-parent li_accordion"><a href="javascript:void(0);" class="accordion" rel="nofollow"></a><a href="https://duniafesyen.com/product-category/mens-clothing/shoes/" title="Shoes" class="nasa-filter-item nasa-filter-by-tax nasa-filter-by-cat">Shoes</a>	<ul class='children'>
<li class="nasa-tax-item cat-item cat-item-835 cat-item-boots"><a href="https://duniafesyen.com/product-category/mens-clothing/shoes/boots/" title="Boots" class="nasa-filter-item nasa-filter-by-tax nasa-filter-by-cat">Boots</a></li>
<li class="nasa-tax-item cat-item cat-item-834 cat-item-loafers"><a href="https://duniafesyen.com/product-category/mens-clothing/shoes/loafers/" title="Loafers" class="nasa-filter-item nasa-filter-by-tax nasa-filter-by-cat">Loafers</a></li>
<li class="nasa-tax-item cat-item cat-item-836 cat-item-sandals"><a href="https://duniafesyen.com/product-category/mens-clothing/shoes/sandals/" title="Sandals" class="nasa-filter-item nasa-filter-by-tax nasa-filter-by-cat">Sandals</a></li>
<li class="nasa-tax-item cat-item cat-item-833 cat-item-sneakers"><a href="https://duniafesyen.com/product-category/mens-clothing/shoes/sneakers/" title="Sneakers" class="nasa-filter-item nasa-filter-by-tax nasa-filter-by-cat">Sneakers</a></li>
	</ul>
</li>
<li class="nasa-tax-item cat-item cat-item-802 cat-item-tops-mens-clothing cat-parent nasa-tax-parent li_accordion"><a href="javascript:void(0);" class="accordion" rel="nofollow"></a><a href="https://duniafesyen.com/product-category/mens-clothing/tops-mens-clothing/" title="Tops" class="nasa-filter-item nasa-filter-by-tax nasa-filter-by-cat">Tops</a>	<ul class='children'>
<li class="nasa-tax-item cat-item cat-item-806 cat-item-hoodies-sweatshirts"><a href="https://duniafesyen.com/product-category/mens-clothing/tops-mens-clothing/hoodies-sweatshirts/" title="Hoodies &amp; Sweatshirts" class="nasa-filter-item nasa-filter-by-tax nasa-filter-by-cat">Hoodies &amp; Sweatshirts</a></li>
<li class="nasa-tax-item cat-item cat-item-804 cat-item-polo-shirts"><a href="https://duniafesyen.com/product-category/mens-clothing/tops-mens-clothing/polo-shirts/" title="Polo Shirts" class="nasa-filter-item nasa-filter-by-tax nasa-filter-by-cat">Polo Shirts</a></li>
<li class="nasa-tax-item cat-item cat-item-807 cat-item-sweaters-cardigans"><a href="https://duniafesyen.com/product-category/mens-clothing/tops-mens-clothing/sweaters-cardigans/" title="Sweaters &amp; Cardigans" class="nasa-filter-item nasa-filter-by-tax nasa-filter-by-cat">Sweaters &amp; Cardigans</a></li>
<li class="nasa-tax-item cat-item cat-item-803 cat-item-t-shirts"><a href="https://duniafesyen.com/product-category/mens-clothing/tops-mens-clothing/t-shirts/" title="T-Shirts" class="nasa-filter-item nasa-filter-by-tax nasa-filter-by-cat">T-Shirts</a></li>
<li class="nasa-tax-item cat-item cat-item-805 cat-item-tank-tops"><a href="https://duniafesyen.com/product-category/mens-clothing/tops-mens-clothing/tank-tops/" title="Tank Tops" class="nasa-filter-item nasa-filter-by-tax nasa-filter-by-cat">Tank Tops</a></li>
	</ul>
</li>
<li class="nasa-tax-item cat-item cat-item-822 cat-item-underwear-sleepwear cat-parent nasa-tax-parent li_accordion"><a href="javascript:void(0);" class="accordion" rel="nofollow"></a><a href="https://duniafesyen.com/product-category/mens-clothing/underwear-sleepwear/" title="Underwear &amp; Sleepwear" class="nasa-filter-item nasa-filter-by-tax nasa-filter-by-cat">Underwear &amp; Sleepwear</a>	<ul class='children'>
<li class="nasa-tax-item cat-item cat-item-823 cat-item-boxers-briefs"><a href="https://duniafesyen.com/product-category/mens-clothing/underwear-sleepwear/boxers-briefs/" title="Boxers &amp; Briefs" class="nasa-filter-item nasa-filter-by-tax nasa-filter-by-cat">Boxers &amp; Briefs</a></li>
<li class="nasa-tax-item cat-item cat-item-824 cat-item-pajamas"><a href="https://duniafesyen.com/product-category/mens-clothing/underwear-sleepwear/pajamas/" title="Pajamas" class="nasa-filter-item nasa-filter-by-tax nasa-filter-by-cat">Pajamas</a></li>
<li class="nasa-tax-item cat-item cat-item-825 cat-item-robes"><a href="https://duniafesyen.com/product-category/mens-clothing/underwear-sleepwear/robes/" title="Robes" class="nasa-filter-item nasa-filter-by-tax nasa-filter-by-cat">Robes</a></li>
	</ul>
</li>
</ul>
</li>
<li class="nasa-tax-item cat-item cat-item-1144 cat-item-uncategorized root-item"><a href="https://duniafesyen.com/product-category/uncategorized/" title="Uncategorized" class="nasa-filter-item nasa-filter-by-tax nasa-filter-by-cat">Uncategorized</a></li>
<li class="nasa-tax-item cat-item cat-item-1152 cat-item-woman root-item cat-parent nasa-tax-parent li_accordion"><a href="javascript:void(0);" class="accordion" rel="nofollow"></a><a href="https://duniafesyen.com/product-category/woman/" title="Woman" class="nasa-filter-item nasa-filter-by-tax nasa-filter-by-cat">Woman</a><ul class='children'>
<li class="nasa-tax-item cat-item cat-item-1156 cat-item-accessories-woman cat-parent nasa-tax-parent li_accordion"><a href="javascript:void(0);" class="accordion" rel="nofollow"></a><a href="https://duniafesyen.com/product-category/woman/accessories-woman/" title="Accessories" class="nasa-filter-item nasa-filter-by-tax nasa-filter-by-cat">Accessories</a>	<ul class='children'>
<li class="nasa-tax-item cat-item cat-item-1172 cat-item-hair-accessories-woman"><a href="https://duniafesyen.com/product-category/woman/accessories-woman/hair-accessories-woman/" title="Hair accessories" class="nasa-filter-item nasa-filter-by-tax nasa-filter-by-cat">Hair accessories</a></li>
<li class="nasa-tax-item cat-item cat-item-1198 cat-item-wallets-ace-woman"><a href="https://duniafesyen.com/product-category/woman/accessories-woman/wallets-ace-woman/" title="Wallets" class="nasa-filter-item nasa-filter-by-tax nasa-filter-by-cat">Wallets</a></li>
	</ul>
</li>
<li class="nasa-tax-item cat-item cat-item-1158 cat-item-bags-woman"><a href="https://duniafesyen.com/product-category/woman/bags-woman/" title="Bags" class="nasa-filter-item nasa-filter-by-tax nasa-filter-by-cat">Bags</a></li>
<li class="nasa-tax-item cat-item cat-item-1159 cat-item-beauty cat-parent nasa-tax-parent li_accordion"><a href="javascript:void(0);" class="accordion" rel="nofollow"></a><a href="https://duniafesyen.com/product-category/woman/beauty/" title="Beauty" class="nasa-filter-item nasa-filter-by-tax nasa-filter-by-cat">Beauty</a>	<ul class='children'>
<li class="nasa-tax-item cat-item cat-item-1173 cat-item-haircare-woman"><a href="https://duniafesyen.com/product-category/woman/beauty/haircare-woman/" title="Haircare" class="nasa-filter-item nasa-filter-by-tax nasa-filter-by-cat">Haircare</a></li>
<li class="nasa-tax-item cat-item cat-item-1177 cat-item-makeup-woman"><a href="https://duniafesyen.com/product-category/woman/beauty/makeup-woman/" title="Makeup" class="nasa-filter-item nasa-filter-by-tax nasa-filter-by-cat">Makeup</a></li>
<li class="nasa-tax-item cat-item cat-item-1178 cat-item-nails-woman"><a href="https://duniafesyen.com/product-category/woman/beauty/nails-woman/" title="Nails" class="nasa-filter-item nasa-filter-by-tax nasa-filter-by-cat">Nails</a></li>
	</ul>
</li>
<li class="nasa-tax-item cat-item cat-item-1165 cat-item-clothing-woman cat-parent nasa-tax-parent li_accordion"><a href="javascript:void(0);" class="accordion" rel="nofollow"></a><a href="https://duniafesyen.com/product-category/woman/clothing-woman/" title="Clothing" class="nasa-filter-item nasa-filter-by-tax nasa-filter-by-cat">Clothing</a>	<ul class='children'>
<li class="nasa-tax-item cat-item cat-item-1167 cat-item-coats-and-jackets-woman"><a href="https://duniafesyen.com/product-category/woman/clothing-woman/coats-and-jackets-woman/" title="Coats and jackets" class="nasa-filter-item nasa-filter-by-tax nasa-filter-by-cat">Coats and jackets</a></li>
<li class="nasa-tax-item cat-item cat-item-1169 cat-item-dresses-woman"><a href="https://duniafesyen.com/product-category/woman/clothing-woman/dresses-woman/" title="Dresses" class="nasa-filter-item nasa-filter-by-tax nasa-filter-by-cat">Dresses</a></li>
<li class="nasa-tax-item cat-item cat-item-1174 cat-item-jeans-woman"><a href="https://duniafesyen.com/product-category/woman/clothing-woman/jeans-woman/" title="Jeans" class="nasa-filter-item nasa-filter-by-tax nasa-filter-by-cat">Jeans</a></li>
<li class="nasa-tax-item cat-item cat-item-1176 cat-item-knit-woman"><a href="https://duniafesyen.com/product-category/woman/clothing-woman/knit-woman/" title="Knit" class="nasa-filter-item nasa-filter-by-tax nasa-filter-by-cat">Knit</a></li>
<li class="nasa-tax-item cat-item cat-item-1181 cat-item-outerwear-woman"><a href="https://duniafesyen.com/product-category/woman/clothing-woman/outerwear-woman/" title="Outerwear" class="nasa-filter-item nasa-filter-by-tax nasa-filter-by-cat">Outerwear</a></li>
<li class="nasa-tax-item cat-item cat-item-1183 cat-item-puffer-jackets-woman"><a href="https://duniafesyen.com/product-category/woman/clothing-woman/puffer-jackets-woman/" title="Puffer jackets" class="nasa-filter-item nasa-filter-by-tax nasa-filter-by-cat">Puffer jackets</a></li>
<li class="nasa-tax-item cat-item cat-item-1191 cat-item-sweaters-woman"><a href="https://duniafesyen.com/product-category/woman/clothing-woman/sweaters-woman/" title="Sweaters" class="nasa-filter-item nasa-filter-by-tax nasa-filter-by-cat">Sweaters</a></li>
<li class="nasa-tax-item cat-item cat-item-1192 cat-item-sweatshirts-hoodies-woman"><a href="https://duniafesyen.com/product-category/woman/clothing-woman/sweatshirts-hoodies-woman/" title="Sweatshirts &amp; Hoodies" class="nasa-filter-item nasa-filter-by-tax nasa-filter-by-cat">Sweatshirts &amp; Hoodies</a></li>
<li class="nasa-tax-item cat-item cat-item-1194 cat-item-swim-woman"><a href="https://duniafesyen.com/product-category/woman/clothing-woman/swim-woman/" title="Swim" class="nasa-filter-item nasa-filter-by-tax nasa-filter-by-cat">Swim</a></li>
<li class="nasa-tax-item cat-item cat-item-1195 cat-item-t-shirts-woman"><a href="https://duniafesyen.com/product-category/woman/clothing-woman/t-shirts-woman/" title="T-shirts" class="nasa-filter-item nasa-filter-by-tax nasa-filter-by-cat">T-shirts</a></li>
<li class="nasa-tax-item cat-item cat-item-1196 cat-item-tees-woman"><a href="https://duniafesyen.com/product-category/woman/clothing-woman/tees-woman/" title="Tees" class="nasa-filter-item nasa-filter-by-tax nasa-filter-by-cat">Tees</a></li>
	</ul>
</li>
<li class="nasa-tax-item cat-item cat-item-1175 cat-item-jewelry-woman cat-parent nasa-tax-parent li_accordion"><a href="javascript:void(0);" class="accordion" rel="nofollow"></a><a href="https://duniafesyen.com/product-category/woman/jewelry-woman/" title="Jewelry" class="nasa-filter-item nasa-filter-by-tax nasa-filter-by-cat">Jewelry</a>	<ul class='children'>
<li class="nasa-tax-item cat-item cat-item-1200 cat-item-bracelets-woman"><a href="https://duniafesyen.com/product-category/woman/jewelry-woman/bracelets-woman/" title="Bracelets" class="nasa-filter-item nasa-filter-by-tax nasa-filter-by-cat">Bracelets</a></li>
<li class="nasa-tax-item cat-item cat-item-1201 cat-item-earrings-woman"><a href="https://duniafesyen.com/product-category/woman/jewelry-woman/earrings-woman/" title="Earrings" class="nasa-filter-item nasa-filter-by-tax nasa-filter-by-cat">Earrings</a></li>
<li class="nasa-tax-item cat-item cat-item-1179 cat-item-necklaces-woman"><a href="https://duniafesyen.com/product-category/woman/jewelry-woman/necklaces-woman/" title="Necklaces" class="nasa-filter-item nasa-filter-by-tax nasa-filter-by-cat">Necklaces</a></li>
<li class="nasa-tax-item cat-item cat-item-1184 cat-item-rings-woman"><a href="https://duniafesyen.com/product-category/woman/jewelry-woman/rings-woman/" title="Rings" class="nasa-filter-item nasa-filter-by-tax nasa-filter-by-cat">Rings</a></li>
	</ul>
</li>
<li class="nasa-tax-item cat-item cat-item-1187 cat-item-shoes-woman cat-parent nasa-tax-parent li_accordion"><a href="javascript:void(0);" class="accordion" rel="nofollow"></a><a href="https://duniafesyen.com/product-category/woman/shoes-woman/" title="Shoes" class="nasa-filter-item nasa-filter-by-tax nasa-filter-by-cat">Shoes</a>	<ul class='children'>
<li class="nasa-tax-item cat-item cat-item-1199 cat-item-boots-and-ankle-boots-woman"><a href="https://duniafesyen.com/product-category/woman/shoes-woman/boots-and-ankle-boots-woman/" title="Boots and ankle boots" class="nasa-filter-item nasa-filter-by-tax nasa-filter-by-cat">Boots and ankle boots</a></li>
<li class="nasa-tax-item cat-item cat-item-1202 cat-item-flat-shoes-woman"><a href="https://duniafesyen.com/product-category/woman/shoes-woman/flat-shoes-woman/" title="Flat shoes" class="nasa-filter-item nasa-filter-by-tax nasa-filter-by-cat">Flat shoes</a></li>
<li class="nasa-tax-item cat-item cat-item-1203 cat-item-giftcards-woman"><a href="https://duniafesyen.com/product-category/woman/shoes-woman/giftcards-woman/" title="Giftcards" class="nasa-filter-item nasa-filter-by-tax nasa-filter-by-cat">Giftcards</a></li>
<li class="nasa-tax-item cat-item cat-item-1204 cat-item-heeled-shoes-woman"><a href="https://duniafesyen.com/product-category/woman/shoes-woman/heeled-shoes-woman/" title="Heeled shoes" class="nasa-filter-item nasa-filter-by-tax nasa-filter-by-cat">Heeled shoes</a></li>
<li class="nasa-tax-item cat-item cat-item-1205 cat-item-sandals-woman"><a href="https://duniafesyen.com/product-category/woman/shoes-woman/sandals-woman/" title="Sandals" class="nasa-filter-item nasa-filter-by-tax nasa-filter-by-cat">Sandals</a></li>
	</ul>
</li>
</ul>
</li>
<li class="nasa-tax-item cat-item cat-item-734 cat-item-womens-clothing root-item cat-parent nasa-tax-parent li_accordion"><a href="javascript:void(0);" class="accordion" rel="nofollow"></a><a href="https://duniafesyen.com/product-category/womens-clothing/" title="Women&#039;s Clothing" class="nasa-filter-item nasa-filter-by-tax nasa-filter-by-cat">Women's Clothing</a><ul class='children'>
<li class="nasa-tax-item cat-item cat-item-735 cat-item-bottoms cat-parent nasa-tax-parent li_accordion"><a href="javascript:void(0);" class="accordion" rel="nofollow"></a><a href="https://duniafesyen.com/product-category/womens-clothing/bottoms/" title="Bottoms" class="nasa-filter-item nasa-filter-by-tax nasa-filter-by-cat">Bottoms</a>	<ul class='children'>
<li class="nasa-tax-item cat-item cat-item-739 cat-item-jeans"><a href="https://duniafesyen.com/product-category/womens-clothing/bottoms/jeans/" title="Jeans" class="nasa-filter-item nasa-filter-by-tax nasa-filter-by-cat">Jeans</a></li>
<li class="nasa-tax-item cat-item cat-item-740 cat-item-leggings"><a href="https://duniafesyen.com/product-category/womens-clothing/bottoms/leggings/" title="Leggings" class="nasa-filter-item nasa-filter-by-tax nasa-filter-by-cat">Leggings</a></li>
<li class="nasa-tax-item cat-item cat-item-736 cat-item-pants"><a href="https://duniafesyen.com/product-category/womens-clothing/bottoms/pants/" title="Pants" class="nasa-filter-item nasa-filter-by-tax nasa-filter-by-cat">Pants</a></li>
<li class="nasa-tax-item cat-item cat-item-737 cat-item-shorts"><a href="https://duniafesyen.com/product-category/womens-clothing/bottoms/shorts/" title="Shorts" class="nasa-filter-item nasa-filter-by-tax nasa-filter-by-cat">Shorts</a></li>
<li class="nasa-tax-item cat-item cat-item-738 cat-item-skirts"><a href="https://duniafesyen.com/product-category/womens-clothing/bottoms/skirts/" title="Skirts" class="nasa-filter-item nasa-filter-by-tax nasa-filter-by-cat">Skirts</a></li>
<li class="nasa-tax-item cat-item cat-item-741 cat-item-womens-pants"><a href="https://duniafesyen.com/product-category/womens-clothing/bottoms/womens-pants/" title="Women’s Pants" class="nasa-filter-item nasa-filter-by-tax nasa-filter-by-cat">Women’s Pants</a></li>
	</ul>
</li>
<li class="nasa-tax-item cat-item cat-item-774 cat-item-curve-plus-size cat-parent nasa-tax-parent li_accordion"><a href="javascript:void(0);" class="accordion" rel="nofollow"></a><a href="https://duniafesyen.com/product-category/womens-clothing/curve-plus-size/" title="Curve &amp; Plus Size" class="nasa-filter-item nasa-filter-by-tax nasa-filter-by-cat">Curve &amp; Plus Size</a>	<ul class='children'>
<li class="nasa-tax-item cat-item cat-item-777 cat-item-plus-size-down-coats"><a href="https://duniafesyen.com/product-category/womens-clothing/curve-plus-size/plus-size-down-coats/" title="Plus Size Down Coats" class="nasa-filter-item nasa-filter-by-tax nasa-filter-by-cat">Plus Size Down Coats</a></li>
<li class="nasa-tax-item cat-item cat-item-780 cat-item-plus-size-dresses"><a href="https://duniafesyen.com/product-category/womens-clothing/curve-plus-size/plus-size-dresses/" title="Plus Size Dresses" class="nasa-filter-item nasa-filter-by-tax nasa-filter-by-cat">Plus Size Dresses</a></li>
<li class="nasa-tax-item cat-item cat-item-778 cat-item-plus-size-matching-sets"><a href="https://duniafesyen.com/product-category/womens-clothing/curve-plus-size/plus-size-matching-sets/" title="Plus Size Matching Sets" class="nasa-filter-item nasa-filter-by-tax nasa-filter-by-cat">Plus Size Matching Sets</a></li>
<li class="nasa-tax-item cat-item cat-item-776 cat-item-plus-size-outwears"><a href="https://duniafesyen.com/product-category/womens-clothing/curve-plus-size/plus-size-outwears/" title="Plus Size Outwears" class="nasa-filter-item nasa-filter-by-tax nasa-filter-by-cat">Plus Size Outwears</a></li>
<li class="nasa-tax-item cat-item cat-item-775 cat-item-plus-size-swimwears"><a href="https://duniafesyen.com/product-category/womens-clothing/curve-plus-size/plus-size-swimwears/" title="Plus Size Swimwears" class="nasa-filter-item nasa-filter-by-tax nasa-filter-by-cat">Plus Size Swimwears</a></li>
<li class="nasa-tax-item cat-item cat-item-779 cat-item-plus-size-tops"><a href="https://duniafesyen.com/product-category/womens-clothing/curve-plus-size/plus-size-tops/" title="Plus Size Tops" class="nasa-filter-item nasa-filter-by-tax nasa-filter-by-cat">Plus Size Tops</a></li>
	</ul>
</li>
<li class="nasa-tax-item cat-item cat-item-742 cat-item-dresses cat-parent nasa-tax-parent li_accordion"><a href="javascript:void(0);" class="accordion" rel="nofollow"></a><a href="https://duniafesyen.com/product-category/womens-clothing/dresses/" title="Dresses" class="nasa-filter-item nasa-filter-by-tax nasa-filter-by-cat">Dresses</a>	<ul class='children'>
<li class="nasa-tax-item cat-item cat-item-743 cat-item-knitted-dresses"><a href="https://duniafesyen.com/product-category/womens-clothing/dresses/knitted-dresses/" title="Knitted Dresses" class="nasa-filter-item nasa-filter-by-tax nasa-filter-by-cat">Knitted Dresses</a></li>
<li class="nasa-tax-item cat-item cat-item-744 cat-item-long-dresses"><a href="https://duniafesyen.com/product-category/womens-clothing/dresses/long-dresses/" title="Long Dresses" class="nasa-filter-item nasa-filter-by-tax nasa-filter-by-cat">Long Dresses</a></li>
<li class="nasa-tax-item cat-item cat-item-745 cat-item-long-sleeve-dresses"><a href="https://duniafesyen.com/product-category/womens-clothing/dresses/long-sleeve-dresses/" title="Long Sleeve Dresses" class="nasa-filter-item nasa-filter-by-tax nasa-filter-by-cat">Long Sleeve Dresses</a></li>
<li class="nasa-tax-item cat-item cat-item-747 cat-item-midi-dresses"><a href="https://duniafesyen.com/product-category/womens-clothing/dresses/midi-dresses/" title="Midi Dresses" class="nasa-filter-item nasa-filter-by-tax nasa-filter-by-cat">Midi Dresses</a></li>
<li class="nasa-tax-item cat-item cat-item-746 cat-item-party-dresses"><a href="https://duniafesyen.com/product-category/womens-clothing/dresses/party-dresses/" title="Party Dresses" class="nasa-filter-item nasa-filter-by-tax nasa-filter-by-cat">Party Dresses</a></li>
<li class="nasa-tax-item cat-item cat-item-748 cat-item-short-dresses"><a href="https://duniafesyen.com/product-category/womens-clothing/dresses/short-dresses/" title="Short Dresses" class="nasa-filter-item nasa-filter-by-tax nasa-filter-by-cat">Short Dresses</a></li>
	</ul>
</li>
<li class="nasa-tax-item cat-item cat-item-769 cat-item-matching-sets cat-parent nasa-tax-parent li_accordion"><a href="javascript:void(0);" class="accordion" rel="nofollow"></a><a href="https://duniafesyen.com/product-category/womens-clothing/matching-sets/" title="Matching Sets" class="nasa-filter-item nasa-filter-by-tax nasa-filter-by-cat">Matching Sets</a>	<ul class='children'>
<li class="nasa-tax-item cat-item cat-item-772 cat-item-dress-sets"><a href="https://duniafesyen.com/product-category/womens-clothing/matching-sets/dress-sets/" title="Dress Sets" class="nasa-filter-item nasa-filter-by-tax nasa-filter-by-cat">Dress Sets</a></li>
<li class="nasa-tax-item cat-item cat-item-770 cat-item-pant-sets"><a href="https://duniafesyen.com/product-category/womens-clothing/matching-sets/pant-sets/" title="Pant Sets" class="nasa-filter-item nasa-filter-by-tax nasa-filter-by-cat">Pant Sets</a></li>
<li class="nasa-tax-item cat-item cat-item-771 cat-item-short-sets"><a href="https://duniafesyen.com/product-category/womens-clothing/matching-sets/short-sets/" title="Short Sets" class="nasa-filter-item nasa-filter-by-tax nasa-filter-by-cat">Short Sets</a></li>
<li class="nasa-tax-item cat-item cat-item-773 cat-item-sweater-matching-sets"><a href="https://duniafesyen.com/product-category/womens-clothing/matching-sets/sweater-matching-sets/" title="Sweater Matching Sets" class="nasa-filter-item nasa-filter-by-tax nasa-filter-by-cat">Sweater Matching Sets</a></li>
	</ul>
</li>
<li class="nasa-tax-item cat-item cat-item-799 cat-item-more-ways-to-shop cat-parent nasa-tax-parent li_accordion"><a href="javascript:void(0);" class="accordion" rel="nofollow"></a><a href="https://duniafesyen.com/product-category/womens-clothing/more-ways-to-shop/" title="More Ways to Shop" class="nasa-filter-item nasa-filter-by-tax nasa-filter-by-cat">More Ways to Shop</a>	<ul class='children'>
<li class="nasa-tax-item cat-item cat-item-800 cat-item-top-selling"><a href="https://duniafesyen.com/product-category/womens-clothing/more-ways-to-shop/top-selling/" title="Top Selling" class="nasa-filter-item nasa-filter-by-tax nasa-filter-by-cat">Top Selling</a></li>
	</ul>
</li>
<li class="nasa-tax-item cat-item cat-item-792 cat-item-new-in cat-parent nasa-tax-parent li_accordion"><a href="javascript:void(0);" class="accordion" rel="nofollow"></a><a href="https://duniafesyen.com/product-category/womens-clothing/new-in/" title="New In" class="nasa-filter-item nasa-filter-by-tax nasa-filter-by-cat">New In</a>	<ul class='children'>
<li class="nasa-tax-item cat-item cat-item-793 cat-item-new-in-coats-jackets"><a href="https://duniafesyen.com/product-category/womens-clothing/new-in/new-in-coats-jackets/" title="New in Coats &amp; Jackets" class="nasa-filter-item nasa-filter-by-tax nasa-filter-by-cat">New in Coats &amp; Jackets</a></li>
<li class="nasa-tax-item cat-item cat-item-796 cat-item-new-in-dresses"><a href="https://duniafesyen.com/product-category/womens-clothing/new-in/new-in-dresses/" title="New in Dresses" class="nasa-filter-item nasa-filter-by-tax nasa-filter-by-cat">New in Dresses</a></li>
<li class="nasa-tax-item cat-item cat-item-798 cat-item-new-in-knitwears"><a href="https://duniafesyen.com/product-category/womens-clothing/new-in/new-in-knitwears/" title="New in Knitwears" class="nasa-filter-item nasa-filter-by-tax nasa-filter-by-cat">New in Knitwears</a></li>
<li class="nasa-tax-item cat-item cat-item-797 cat-item-new-in-matching-sets"><a href="https://duniafesyen.com/product-category/womens-clothing/new-in/new-in-matching-sets/" title="New in Matching Sets" class="nasa-filter-item nasa-filter-by-tax nasa-filter-by-cat">New in Matching Sets</a></li>
<li class="nasa-tax-item cat-item cat-item-795 cat-item-new-in-outerwears"><a href="https://duniafesyen.com/product-category/womens-clothing/new-in/new-in-outerwears/" title="New in Outerwears" class="nasa-filter-item nasa-filter-by-tax nasa-filter-by-cat">New in Outerwears</a></li>
<li class="nasa-tax-item cat-item cat-item-794 cat-item-new-in-pants-capris"><a href="https://duniafesyen.com/product-category/womens-clothing/new-in/new-in-pants-capris/" title="New in Pants &amp; Capris" class="nasa-filter-item nasa-filter-by-tax nasa-filter-by-cat">New in Pants &amp; Capris</a></li>
	</ul>
</li>
<li class="nasa-tax-item cat-item cat-item-756 cat-item-outerwears cat-parent nasa-tax-parent li_accordion"><a href="javascript:void(0);" class="accordion" rel="nofollow"></a><a href="https://duniafesyen.com/product-category/womens-clothing/outerwears/" title="Outerwears" class="nasa-filter-item nasa-filter-by-tax nasa-filter-by-cat">Outerwears</a>	<ul class='children'>
<li class="nasa-tax-item cat-item cat-item-762 cat-item-cardigans"><a href="https://duniafesyen.com/product-category/womens-clothing/outerwears/cardigans/" title="Cardigans" class="nasa-filter-item nasa-filter-by-tax nasa-filter-by-cat">Cardigans</a></li>
<li class="nasa-tax-item cat-item cat-item-757 cat-item-down-coats"><a href="https://duniafesyen.com/product-category/womens-clothing/outerwears/down-coats/" title="Down Coats" class="nasa-filter-item nasa-filter-by-tax nasa-filter-by-cat">Down Coats</a></li>
<li class="nasa-tax-item cat-item cat-item-760 cat-item-long-down-coats"><a href="https://duniafesyen.com/product-category/womens-clothing/outerwears/long-down-coats/" title="Long Down Coats" class="nasa-filter-item nasa-filter-by-tax nasa-filter-by-cat">Long Down Coats</a></li>
<li class="nasa-tax-item cat-item cat-item-759 cat-item-parkas"><a href="https://duniafesyen.com/product-category/womens-clothing/outerwears/parkas/" title="Parkas" class="nasa-filter-item nasa-filter-by-tax nasa-filter-by-cat">Parkas</a></li>
<li class="nasa-tax-item cat-item cat-item-761 cat-item-short-down-coats"><a href="https://duniafesyen.com/product-category/womens-clothing/outerwears/short-down-coats/" title="Short Down Coats" class="nasa-filter-item nasa-filter-by-tax nasa-filter-by-cat">Short Down Coats</a></li>
<li class="nasa-tax-item cat-item cat-item-758 cat-item-wool-blends-coats"><a href="https://duniafesyen.com/product-category/womens-clothing/outerwears/wool-blends-coats/" title="Wool &amp; Blends Coats" class="nasa-filter-item nasa-filter-by-tax nasa-filter-by-cat">Wool &amp; Blends Coats</a></li>
	</ul>
</li>
<li class="nasa-tax-item cat-item cat-item-749 cat-item-special-occasion-dresses cat-parent nasa-tax-parent li_accordion"><a href="javascript:void(0);" class="accordion" rel="nofollow"></a><a href="https://duniafesyen.com/product-category/womens-clothing/special-occasion-dresses/" title="Special Occasion Dresses" class="nasa-filter-item nasa-filter-by-tax nasa-filter-by-cat">Special Occasion Dresses</a>	<ul class='children'>
<li class="nasa-tax-item cat-item cat-item-752 cat-item-bespoke-occasion-dresses"><a href="https://duniafesyen.com/product-category/womens-clothing/special-occasion-dresses/bespoke-occasion-dresses/" title="Bespoke Occasion Dresses" class="nasa-filter-item nasa-filter-by-tax nasa-filter-by-cat">Bespoke Occasion Dresses</a></li>
<li class="nasa-tax-item cat-item cat-item-751 cat-item-formal-occasion-dresses"><a href="https://duniafesyen.com/product-category/womens-clothing/special-occasion-dresses/formal-occasion-dresses/" title="Formal Occasion Dresses" class="nasa-filter-item nasa-filter-by-tax nasa-filter-by-cat">Formal Occasion Dresses</a></li>
<li class="nasa-tax-item cat-item cat-item-754 cat-item-homecoming-dresses"><a href="https://duniafesyen.com/product-category/womens-clothing/special-occasion-dresses/homecoming-dresses/" title="Homecoming Dresses" class="nasa-filter-item nasa-filter-by-tax nasa-filter-by-cat">Homecoming Dresses</a></li>
<li class="nasa-tax-item cat-item cat-item-755 cat-item-kebaya"><a href="https://duniafesyen.com/product-category/womens-clothing/special-occasion-dresses/kebaya/" title="Kebaya" class="nasa-filter-item nasa-filter-by-tax nasa-filter-by-cat">Kebaya</a></li>
<li class="nasa-tax-item cat-item cat-item-750 cat-item-prom-dresses"><a href="https://duniafesyen.com/product-category/womens-clothing/special-occasion-dresses/prom-dresses/" title="Prom Dresses" class="nasa-filter-item nasa-filter-by-tax nasa-filter-by-cat">Prom Dresses</a></li>
<li class="nasa-tax-item cat-item cat-item-753 cat-item-quinceanera-dresses"><a href="https://duniafesyen.com/product-category/womens-clothing/special-occasion-dresses/quinceanera-dresses/" title="Quinceanera Dresses" class="nasa-filter-item nasa-filter-by-tax nasa-filter-by-cat">Quinceanera Dresses</a></li>
	</ul>
</li>
<li class="nasa-tax-item cat-item cat-item-788 cat-item-swimwears cat-parent nasa-tax-parent li_accordion"><a href="javascript:void(0);" class="accordion" rel="nofollow"></a><a href="https://duniafesyen.com/product-category/womens-clothing/swimwears/" title="Swimwears" class="nasa-filter-item nasa-filter-by-tax nasa-filter-by-cat">Swimwears</a>	<ul class='children'>
<li class="nasa-tax-item cat-item cat-item-790 cat-item-bikinis-sets"><a href="https://duniafesyen.com/product-category/womens-clothing/swimwears/bikinis-sets/" title="Bikinis Sets" class="nasa-filter-item nasa-filter-by-tax nasa-filter-by-cat">Bikinis Sets</a></li>
<li class="nasa-tax-item cat-item cat-item-791 cat-item-cover-ups"><a href="https://duniafesyen.com/product-category/womens-clothing/swimwears/cover-ups/" title="Cover-Ups" class="nasa-filter-item nasa-filter-by-tax nasa-filter-by-cat">Cover-Ups</a></li>
<li class="nasa-tax-item cat-item cat-item-789 cat-item-one-pieces"><a href="https://duniafesyen.com/product-category/womens-clothing/swimwears/one-pieces/" title="One Pieces" class="nasa-filter-item nasa-filter-by-tax nasa-filter-by-cat">One Pieces</a></li>
	</ul>
</li>
<li class="nasa-tax-item cat-item cat-item-781 cat-item-tops cat-parent nasa-tax-parent li_accordion"><a href="javascript:void(0);" class="accordion" rel="nofollow"></a><a href="https://duniafesyen.com/product-category/womens-clothing/tops/" title="Tops" class="nasa-filter-item nasa-filter-by-tax nasa-filter-by-cat">Tops</a>	<ul class='children'>
<li class="nasa-tax-item cat-item cat-item-783 cat-item-knitwears"><a href="https://duniafesyen.com/product-category/womens-clothing/tops/knitwears/" title="Knitwears" class="nasa-filter-item nasa-filter-by-tax nasa-filter-by-cat">Knitwears</a></li>
<li class="nasa-tax-item cat-item cat-item-786 cat-item-long-sleeve-tees"><a href="https://duniafesyen.com/product-category/womens-clothing/tops/long-sleeve-tees/" title="Long Sleeve Tees" class="nasa-filter-item nasa-filter-by-tax nasa-filter-by-cat">Long Sleeve Tees</a></li>
<li class="nasa-tax-item cat-item cat-item-785 cat-item-o-neck-pullovers"><a href="https://duniafesyen.com/product-category/womens-clothing/tops/o-neck-pullovers/" title="O-Neck Pullovers" class="nasa-filter-item nasa-filter-by-tax nasa-filter-by-cat">O-Neck Pullovers</a></li>
<li class="nasa-tax-item cat-item cat-item-784 cat-item-pullovers"><a href="https://duniafesyen.com/product-category/womens-clothing/tops/pullovers/" title="Pullovers" class="nasa-filter-item nasa-filter-by-tax nasa-filter-by-cat">Pullovers</a></li>
<li class="nasa-tax-item cat-item cat-item-782 cat-item-shirts-blouses"><a href="https://duniafesyen.com/product-category/womens-clothing/tops/shirts-blouses/" title="Shirts &amp; Blouses" class="nasa-filter-item nasa-filter-by-tax nasa-filter-by-cat">Shirts &amp; Blouses</a></li>
<li class="nasa-tax-item cat-item cat-item-787 cat-item-turtlenecks"><a href="https://duniafesyen.com/product-category/womens-clothing/tops/turtlenecks/" title="Turtlenecks" class="nasa-filter-item nasa-filter-by-tax nasa-filter-by-cat">Turtlenecks</a></li>
	</ul>
</li>
<li class="nasa-tax-item cat-item cat-item-763 cat-item-wedding-dresses cat-parent nasa-tax-parent li_accordion"><a href="javascript:void(0);" class="accordion" rel="nofollow"></a><a href="https://duniafesyen.com/product-category/womens-clothing/wedding-dresses/" title="Wedding Dresses" class="nasa-filter-item nasa-filter-by-tax nasa-filter-by-cat">Wedding Dresses</a>	<ul class='children'>
<li class="nasa-tax-item cat-item cat-item-768 cat-item-bespoke-wedding-dress"><a href="https://duniafesyen.com/product-category/womens-clothing/wedding-dresses/bespoke-wedding-dress/" title="Bespoke Wedding Dress" class="nasa-filter-item nasa-filter-by-tax nasa-filter-by-cat">Bespoke Wedding Dress</a></li>
<li class="nasa-tax-item cat-item cat-item-767 cat-item-plus-size-wedding-dress"><a href="https://duniafesyen.com/product-category/womens-clothing/wedding-dresses/plus-size-wedding-dress/" title="Plus Size Wedding Dress" class="nasa-filter-item nasa-filter-by-tax nasa-filter-by-cat">Plus Size Wedding Dress</a></li>
<li class="nasa-tax-item cat-item cat-item-766 cat-item-wedding-accessories"><a href="https://duniafesyen.com/product-category/womens-clothing/wedding-dresses/wedding-accessories/" title="Wedding Accessories" class="nasa-filter-item nasa-filter-by-tax nasa-filter-by-cat">Wedding Accessories</a></li>
<li class="nasa-tax-item cat-item cat-item-765 cat-item-wedding-dress"><a href="https://duniafesyen.com/product-category/womens-clothing/wedding-dresses/wedding-dress/" title="Wedding Dress" class="nasa-filter-item nasa-filter-by-tax nasa-filter-by-cat">Wedding Dress</a></li>
<li class="nasa-tax-item cat-item cat-item-764 cat-item-wedding-party-dress"><a href="https://duniafesyen.com/product-category/womens-clothing/wedding-dresses/wedding-party-dress/" title="Wedding Party Dress" class="nasa-filter-item nasa-filter-by-tax nasa-filter-by-cat">Wedding Party Dress</a></li>
	</ul>
</li>
</ul>
</li>
<li class="nasa-current-note"></li></ul></div>
            <a href="javascript:void(0);" title="Close" class="nasa-close-filter-cat ns-touch-close" rel="nofollow">
                <svg class="nasa-rotate-180" width="15" height="15" viewBox="0 0 512 512" fill="currentColor">
                    <path d="M135 512c3 0 4 0 6 0 15-4 26-21 40-33 62-61 122-122 187-183 9-9 27-24 29-33 3-14-8-23-17-32-67-66-135-131-202-198-11-9-24-27-33-29-18-4-28 8-31 21 0 0 0 2 0 2 1 1 1 6 3 10 3 8 18 20 27 28 47 47 95 93 141 139 19 18 39 36 55 55-62 64-134 129-199 193-8 9-24 21-26 32-3 18 8 24 20 28z" />
                </svg>
            </a>
        </div>
    <div class="hidden-tag ns-wrap-cfg"><input type="hidden" name="ns-cookie-path" value="/" /><input type="hidden" name="ns-cookie-domain" value="" /></div><!-- Enable Fixed add to cart single product --><input type="hidden" name="nasa_fixed_single_add_to_cart" value="1" /><!-- Fixed add to cart single product in Mobile layout --><input type="hidden" name="nasa_fixed_mobile_single_add_to_cart_layout" value="no" /><!-- Event After Add To Cart --><input type="hidden" name="nasa-event-after-add-to-cart" value="sidebar" /><script type="text/template" id="tmpl-nasa-pswpHTML"><div class="pswp" tabindex="-1" role="dialog" aria-hidden="true"><div class="pswp__bg"></div><div class="pswp__scroll-wrap"><div class="pswp__container"><div class="pswp__item"></div><div class="pswp__item"></div><div class="pswp__item"></div></div><div class="pswp__ui pswp__ui--hidden"><div class="pswp__top-bar"><div class="pswp__counter"></div><button class="pswp__button pswp__button--close" title="Close (Esc)"></button><button class="pswp__button pswp__button--share" title="Share"></button><button class="pswp__button pswp__button--fs" title="Toggle fullscreen"></button><button class="pswp__button pswp__button--zoom" title="Zoom in/out"></button><div class="pswp__preloader"><div class="pswp__preloader__icn"><div class="pswp__preloader__cut"><div class="pswp__preloader__donut"></div></div></div></div></div><div class="pswp__share-modal pswp__share-modal--hidden pswp__single-tap"><div class="pswp__share-tooltip"></div></div><button class="pswp__button pswp__button--arrow--left" title="Previous (arrow left)"></button><button class="pswp__button pswp__button--arrow--right" title="Next (arrow right)"></button><div class="pswp__caption"><div class="pswp__caption__center"></div></div></div></div></div></script>
        <!-- URL Logout -->
        <input type="hidden" name="nasa_logout_menu" value="https://duniafesyen.com/wp-login.php?action=logout&amp;redirect_to=https%3A%2F%2Fduniafesyen.com%2F&amp;_wpnonce=38fb3bc41a" />

        <!-- width toggle Add To Cart | Countdown -->
        <input type="hidden" name="nasa-toggle-width-product-content" value="180" />

        <!-- Close Pop-up string -->
        <input type="hidden" name="nasa-close-string" value="Close (Esc)" />

        <!-- Toggle Select Options Sticky add to cart single product page -->
        <input type="hidden" name="nasa_select_options_text" value="Select Options" />

        <!-- Less Total Count items Wishlist - Compare - (9+) -->
        <input type="hidden" name="nasa_less_total_items" value="1" />

        <!-- Confirm text - Value to 0 in Quantity - Cart Sidebar -->
        <input type="hidden" name="nasa_change_value_0" value="Are you sure you want to remove it?" />

        <!-- Cookie Life Time - Default 7 days -->
        <input type="hidden" name="nasa-cookie-life" value="7" />

        <script type="text/template" id="tmpl-nasa-bottom-bar"><div class="nasa-bottom-bar nasa-transition">
    <ul class="nasa-bottom-bar-icons nasa-transition">
        <li class="nasa-bot-item ns-bot-store">
            <a class="nasa-bot-icons nasa-bot-icon-shop" href="https://duniafesyen.com/shop/" title="Shop">
                <svg class="nasa-svg-shop" height="23" width="22" viewBox="0 0 32 32" fill="currentColor">
            <g transform="matrix(0.048565, 0, 0, 0.048565, 24.580261, 2.974931)">
                <g transform="matrix(1, 0, 0, 1, -518.638794, 10.322351)">
                    <path d="M 325.775 138.986 L 325.775 3.106 L 226.224 3.106 L 206.439 139.36 C 206.645 170.27 234.133 190.889 268.991 190.889 C 303.978 190.889 325.803 170.085 325.803 139.017 C 325.803 139.007 325.803 138.997 325.803 138.986 L 325.775 138.986 Z M 184.112 137.888 L 203.681 3.106 L 97.891 3.106 L 58.284 139.43 C 58.584 170.266 86.435 190.733 121.233 190.733 C 156.222 190.733 184.07 170.085 184.07 139.017 C 184.07 138.63 184.088 138.254 184.128 137.89 L 184.112 137.888 Z M 594.367 -19.814 C 599.223 -19.831 603.454 -16.894 604.618 -12.712 L 646.637 136.813 C 646.84 137.534 646.943 138.276 646.947 139.019 C 646.947 180.185 613.869 209.926 567.511 209.926 C 531.02 209.926 499.688 193.287 489.208 175.252 C 478.646 193.118 453.202 209.443 416.701 209.443 C 380.201 209.443 352.393 193.307 341.803 175.252 C 331.352 193.145 304.741 212.29 268.25 212.29 C 231.749 212.29 205.105 193.207 194.551 175.252 C 184.058 193.315 157.589 211.144 121.098 211.144 C 74.74 211.144 36.736 180.185 36.736 139.019 C 36.741 138.277 36.843 137.534 37.048 136.813 L 79.14 -12.712 C 80.303 -16.894 84.542 -19.831 89.392 -19.814 L 594.367 -19.814 Z M 348.045 139.207 C 348.045 170.275 381.317 188.935 416.303 188.935 C 450.995 188.935 476.125 170.509 476.599 139.807 L 456.751 3.106 L 348.015 3.295 L 348.015 138.403 C 348.035 138.666 348.045 138.933 348.045 139.207 Z M 499.694 139.017 C 499.694 170.085 533.968 189.636 568.956 189.636 C 603.758 189.636 624.426 170.27 624.721 139.43 L 585.114 3.106 C 587.139 0.878 481.773 1.17 480.014 3.106 L 499.402 136.59 C 499.593 137.337 499.694 138.147 499.694 139.017 Z" style="stroke-width: 0px;" />
                    <path d="M 84.471 189.481 L 84.471 477.433 C 84.471 477.433 84.553 498.229 93.5 514.914 C 102.449 531.6 120.513 544.603 156.583 544.603 L 527.101 544.603 C 527.101 544.603 555.31 542.288 573.205 533.941 C 591.1 525.599 599.213 510.85 599.213 477.431 L 599.213 189.48 L 577.499 189.098 L 577.499 477.049 C 577.499 501.307 570.068 508.99 557.08 515.043 C 544.094 521.099 527.101 521.66 527.101 521.66 L 156.583 521.66 C 130.839 521.66 118.528 516.699 112.038 504.589 C 105.541 492.481 105.426 477.431 105.426 477.431 L 105.426 189.48 L 84.471 189.481 Z" style="stroke-width: 0px;" />
                    <path d="M 305.173 310.741 C 271.149 310.741 253.821 328.39 245.355 345.327 C 236.885 362.259 237.011 378.904 237.011 378.904 L 237.011 525.004 L 260 525.004 L 260 378.904 C 260 378.904 260.061 367.149 266.204 354.864 C 272.349 342.576 280.805 333.685 305.338 333.685 L 383.276 333.685 C 383.276 333.685 392.741 333.794 405.026 339.942 C 417.314 346.087 428.659 354.397 428.659 378.907 L 428.663 525.007 L 451.275 525.007 L 451.275 378.907 C 451.275 345.025 433.626 327.554 416.689 319.089 C 399.757 310.619 383.112 310.745 383.112 310.745 L 305.173 310.741 Z" style="stroke-width: 0px;" />
                </g>
            </g>
        </svg>                Shop            </a>
        </li>

        <li class="nasa-bot-item nasa-bot-item-sidebar hidden-tag">
            <a class="nasa-bot-icons nasa-bot-icon-sidebar" href="javascript:void(0);" title="Filters" rel="nofollow">
                <svg width="23" height="23" viewBox="0 0 32 32" fill="currentColor"><path d="M19.199 28.262h-6.403v-10.398l-10.661-14.126h27.731l-10.667 14.126v10.398zM13.862 27.196h4.271v-9.688l9.592-12.703h-23.449l9.586 12.703v9.688z"/></svg>                Filters            </a>
        </li>
        
                    <li class="nasa-bot-item ns-bot-cats">
                <a class="nasa-bot-icons nasa-bot-icon-categories filter-cat-icon-mobile" href="javascript:void(0);" title="Categories" rel="nofollow">
                    <svg width="23" height="23" viewBox="0 0 32 32" fill="currentColor">
<path d="M6.937 21.865c-1.766 0-3.199 1.432-3.199 3.198s1.432 3.199 3.199 3.199c1.766 0 3.199-1.432 3.199-3.199s-1.433-3.198-3.199-3.198zM6.937 27.195c-1.176 0-2.132-0.956-2.132-2.133s0.956-2.132 2.133-2.132c1.176 0 2.133 0.956 2.133 2.132s-0.956 2.133-2.133 2.133z" /><path d="M6.937 3.738c-1.766 0-3.199 1.432-3.199 3.198s1.432 3.199 3.199 3.199c1.766 0 3.199-1.432 3.199-3.199s-1.433-3.198-3.199-3.198zM6.937 9.069c-1.176 0-2.132-0.956-2.132-2.133s0.956-2.132 2.133-2.132c1.176 0 2.133 0.956 2.133 2.132s-0.956 2.133-2.133 2.133z" /><path d="M6.937 12.779c-1.766 0-3.199 1.432-3.199 3.198s1.432 3.199 3.199 3.199c1.766 0 3.199-1.432 3.199-3.199s-1.433-3.198-3.199-3.198zM6.937 18.11c-1.176 0-2.132-0.957-2.132-2.133s0.956-2.132 2.133-2.132c1.176 0 2.133 0.956 2.133 2.132s-0.956 2.133-2.133 2.133z" /><path d="M16 21.865c-1.767 0-3.199 1.432-3.199 3.198s1.432 3.199 3.199 3.199c1.766 0 3.199-1.432 3.199-3.199s-1.433-3.198-3.199-3.198zM16 27.195c-1.176 0-2.133-0.956-2.133-2.133s0.956-2.132 2.133-2.132c1.176 0 2.133 0.956 2.133 2.132s-0.956 2.133-2.133 2.133z" /><path d="M16 3.738c-1.767 0-3.199 1.432-3.199 3.198s1.432 3.199 3.199 3.199c1.766 0 3.199-1.432 3.199-3.199s-1.433-3.198-3.199-3.198zM16 9.069c-1.176 0-2.133-0.956-2.133-2.133s0.956-2.132 2.133-2.132c1.176 0 2.133 0.956 2.133 2.132s-0.956 2.133-2.133 2.133z" /><path d="M16 12.779c-1.767 0-3.199 1.432-3.199 3.198s1.432 3.199 3.199 3.199c1.766 0 3.199-1.432 3.199-3.199s-1.433-3.198-3.199-3.198zM16 18.11c-1.176 0-2.133-0.957-2.133-2.133s0.956-2.132 2.133-2.132c1.176 0 2.133 0.956 2.133 2.132s-0.956 2.133-2.133 2.133z" />
<path d="M25.063 21.865c-1.767 0-3.199 1.432-3.199 3.198s1.432 3.199 3.199 3.199c1.766 0 3.199-1.432 3.199-3.199s-1.433-3.198-3.199-3.198zM25.063 27.195c-1.176 0-2.133-0.956-2.133-2.133s0.956-2.132 2.133-2.132c1.176 0 2.133 0.956 2.133 2.132s-0.956 2.133-2.133 2.133z" /><path d="M25.063 10.135c1.766 0 3.199-1.432 3.199-3.199s-1.433-3.198-3.199-3.198c-1.767 0-3.199 1.432-3.199 3.198s1.432 3.199 3.199 3.199zM25.063 4.805c1.176 0 2.133 0.956 2.133 2.132s-0.956 2.133-2.133 2.133c-1.176 0-2.133-0.956-2.133-2.133s0.956-2.132 2.133-2.132z" /><path d="M25.063 12.779c-1.767 0-3.199 1.432-3.199 3.198s1.432 3.199 3.199 3.199c1.766 0 3.199-1.432 3.199-3.199s-1.433-3.198-3.199-3.198zM25.063 18.11c-1.176 0-2.133-0.957-2.133-2.133s0.956-2.132 2.133-2.132c1.176 0 2.133 0.956 2.133 2.132s-0.956 2.133-2.133 2.133z" /></svg>                    Categories                </a>
            </li>
        
        <li class="nasa-bot-item nasa-bot-item-search hidden-tag">
            <a class="nasa-bot-icons nasa-bot-icon-search botbar-mobile-search" href="javascript:void(0);" title="Search" rel="nofollow">
                <svg fill="currentColor" viewBox="0 0 80 80" width="23" height="23"><path d="M74.3,72.2L58.7,56.5C69.9,44,69,24.8,56.5,13.5s-31.7-10.3-43,2.2s-10.3,31.7,2.2,43c11.6,10.5,29.3,10.5,40.9,0 l15.7,15.7L74.3,72.2z M36.1,63.5c-15.1,0-27.4-12.3-27.4-27.4C8.7,20.9,21,8.7,36.1,8.7c15.1,0,27.4,12.3,27.4,27.4 C63.5,51.2,51.2,63.5,36.1,63.5z" /><path d="M36.1,12.8v3c11.2,0,20.3,9.1,20.3,20.3h3C59.4,23.2,49,12.8,36.1,12.8z" /></svg>                Search            </a>
        </li>

                    
            <li class="nasa-bot-item ns-bot-wl">
                <a class="nasa-bot-icons nasa-bot-icon-wishlist botbar-wishlist-link" href="javascript:void(0);" title="Wishlist" rel="nofollow">
                    <svg width="23" height="23" viewBox="0 0 32 32" fill="currentColor"><path d="M21.886 5.115c3.521 0 6.376 2.855 6.376 6.376 0 1.809-0.754 3.439-1.964 4.6l-10.297 10.349-10.484-10.536c-1.1-1.146-1.778-2.699-1.778-4.413 0-3.522 2.855-6.376 6.376-6.376 2.652 0 4.925 1.62 5.886 3.924 0.961-2.304 3.234-3.924 5.886-3.924zM21.886 4.049c-2.345 0-4.499 1.089-5.886 2.884-1.386-1.795-3.54-2.884-5.886-2.884-4.104 0-7.442 3.339-7.442 7.442 0 1.928 0.737 3.758 2.075 5.152l11.253 11.309 11.053-11.108c1.46-1.402 2.275-3.308 2.275-5.352 0-4.104-3.339-7.442-7.442-7.442v0z"/></svg>                    Wishlist                </a>
                <a class="wishlist-link nasa-wishlist-link nasa-flex" href="javascript:void(0);" title="Wishlist" rel="nofollow"><span class="icon-wrap"><svg class="nasa-icon wishlist-icon" width="28" height="28" viewBox="0 0 32 32"><path d="M21.886 5.115c3.521 0 6.376 2.855 6.376 6.376 0 1.809-0.754 3.439-1.964 4.6l-10.297 10.349-10.484-10.536c-1.1-1.146-1.778-2.699-1.778-4.413 0-3.522 2.855-6.376 6.376-6.376 2.652 0 4.925 1.62 5.886 3.924 0.961-2.304 3.234-3.924 5.886-3.924zM21.886 4.049c-2.345 0-4.499 1.089-5.886 2.884-1.386-1.795-3.54-2.884-5.886-2.884-4.104 0-7.442 3.339-7.442 7.442 0 1.928 0.737 3.758 2.075 5.152l11.253 11.309 11.053-11.108c1.46-1.402 2.275-3.308 2.275-5.352 0-4.104-3.339-7.442-7.442-7.442v0z" fill="currentColor" /></svg><span class="nasa-wishlist-count nasa-mini-number wishlist-number nasa-product-empty">0</span></span><span class="icon-text hidden-tag">Wishlist</span></a>            </li>

            </ul>

</div></script><input type="hidden" name="add_to_cart_text" value="Add to cart" /><input type="hidden" name="nasa_no_matching_variations" value="Sorry, no products matched your selection. Please choose a different combination." />            <script type="text/template" id="tmpl-nasa-responsive-header">
                
<div class="mobile-menu header-responsive">
    <div class="mini-icon-mobile nasa-flex">
        <a href="javascript:void(0);" class="nasa-icon nasa-mobile-menu_toggle mobile_toggle nasa-mobile-menu-icon nasa-flex" rel="nofollow"><svg width="26" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1" stroke-linecap="round" stroke-linejoin="round"><line x1="3" y1="12" x2="21" y2="12" /><line x1="3" y1="6" x2="21" y2="6" /><line x1="3" y1="18" x2="21" y2="18" /></svg></a><a href="javascript:void(0);" class="nasa-icon mobile-search fs-23" rel="nofollow"><svg fill="currentColor" viewBox="0 0 80 80" width="22" height="22"><path d="M74.3,72.2L58.7,56.5C69.9,44,69,24.8,56.5,13.5s-31.7-10.3-43,2.2s-10.3,31.7,2.2,43c11.6,10.5,29.3,10.5,40.9,0 l15.7,15.7L74.3,72.2z M36.1,63.5c-15.1,0-27.4-12.3-27.4-27.4C8.7,20.9,21,8.7,36.1,8.7c15.1,0,27.4,12.3,27.4,27.4 C63.5,51.2,51.2,63.5,36.1,63.5z"/><path d="M36.1,12.8v3c11.2,0,20.3,9.1,20.3,20.3h3C59.4,23.2,49,12.8,36.1,12.8z" /></svg></a>    </div>

    <div class="logo-wrapper">
        <a class="logo nasa-logo-retina nasa-has-sticky-logo nasa-has-mobile-logo" href="https://duniafesyen.com/" title="Dunia Fesyen - Info Terkini Fesyen" rel="Home"><img src="//duniafesyen-media.s3.ap-southeast-1.amazonaws.com/wp-content/uploads/2025/03/03181633/Dunia-Fesyen-Logo.png" alt="Dunia Fesyen" class="header_logo" srcset="//duniafesyen-media.s3.ap-southeast-1.amazonaws.com/wp-content/uploads/2025/03/03181633/Dunia-Fesyen-Logo.png 1x, //duniafesyen-media.s3.ap-southeast-1.amazonaws.com/wp-content/uploads/2025/03/03181554/DF-Logo-Retina.png 2x" /><img src="//duniafesyen-media.s3.ap-southeast-1.amazonaws.com/wp-content/uploads/2025/03/03181633/Dunia-Fesyen-Logo.png" alt="Dunia Fesyen" class="header_logo logo_sticky" /><img src="//duniafesyen-media.s3.ap-southeast-1.amazonaws.com/wp-content/uploads/2025/03/03181633/Dunia-Fesyen-Logo.png" alt="Dunia Fesyen" class="header_logo logo_mobile" /></a>    </div>

    <div class="nasa-mobile-icons-wrap mini-icon-mobile">
        <ul class="header-icons"><li class="first nasa-icon-account-mobile"><a class="nasa-login-register-ajax nasa-flex" data-enable="1" href="https://duniafesyen.com/my-account/" title="Login / Register"><svg width="24" height="24" viewBox="0 0 32 32" fill="currentColor"><path d="M16 3.205c-7.067 0-12.795 5.728-12.795 12.795s5.728 12.795 12.795 12.795 12.795-5.728 12.795-12.795c0-7.067-5.728-12.795-12.795-12.795zM16 4.271c6.467 0 11.729 5.261 11.729 11.729 0 2.845-1.019 5.457-2.711 7.49-1.169-0.488-3.93-1.446-5.638-1.951-0.146-0.046-0.169-0.053-0.169-0.66 0-0.501 0.206-1.005 0.407-1.432 0.218-0.464 0.476-1.244 0.569-1.944 0.259-0.301 0.612-0.895 0.839-2.026 0.199-0.997 0.106-1.36-0.026-1.7-0.014-0.036-0.028-0.071-0.039-0.107-0.050-0.234 0.019-1.448 0.189-2.391 0.118-0.647-0.030-2.022-0.921-3.159-0.562-0.719-1.638-1.601-3.603-1.724l-1.078 0.001c-1.932 0.122-3.008 1.004-3.57 1.723-0.89 1.137-1.038 2.513-0.92 3.159 0.172 0.943 0.239 2.157 0.191 2.387-0.010 0.040-0.025 0.075-0.040 0.111-0.131 0.341-0.225 0.703-0.025 1.7 0.226 1.131 0.579 1.725 0.839 2.026 0.092 0.7 0.35 1.48 0.569 1.944 0.159 0.339 0.234 0.801 0.234 1.454 0 0.607-0.023 0.614-0.159 0.657-1.767 0.522-4.579 1.538-5.628 1.997-1.725-2.042-2.768-4.679-2.768-7.555 0-6.467 5.261-11.729 11.729-11.729zM7.811 24.386c1.201-0.49 3.594-1.344 5.167-1.808 0.914-0.288 0.914-1.058 0.914-1.677 0-0.513-0.035-1.269-0.335-1.908-0.206-0.438-0.442-1.189-0.494-1.776-0.011-0.137-0.076-0.265-0.18-0.355-0.151-0.132-0.458-0.616-0.654-1.593-0.155-0.773-0.089-0.942-0.026-1.106 0.027-0.070 0.053-0.139 0.074-0.216 0.128-0.468-0.015-2.005-0.17-2.858-0.068-0.371 0.018-1.424 0.711-2.311 0.622-0.795 1.563-1.238 2.764-1.315l1.011-0.001c1.233 0.078 2.174 0.521 2.797 1.316 0.694 0.887 0.778 1.94 0.71 2.312-0.154 0.852-0.298 2.39-0.17 2.857 0.022 0.078 0.047 0.147 0.074 0.217 0.064 0.163 0.129 0.333-0.025 1.106-0.196 0.977-0.504 1.461-0.655 1.593-0.103 0.091-0.168 0.218-0.18 0.355-0.051 0.588-0.286 1.338-0.492 1.776-0.236 0.502-0.508 1.171-0.508 1.886 0 0.619 0 1.389 0.924 1.68 1.505 0.445 3.91 1.271 5.18 1.77-2.121 2.1-5.035 3.4-8.248 3.4-3.183 0-6.073-1.277-8.188-3.342z"/></svg></a></li><li class="nasa-icon-mini-cart"><a href="https://duniafesyen.com/shopping-cart/" class="cart-link mini-cart cart-inner nasa-flex jc" title="Cart" rel="nofollow"><span class="icon-wrap"><svg class="nasa-icon cart-icon nasa-icon-1" width="28" height="28" viewBox="0 0 32 32" fill="currentColor"><path d="M3.205 3.205v25.59h25.59v-25.59h-25.59zM27.729 27.729h-23.457v-23.457h23.457v23.457z" /><path d="M9.068 13.334c0 3.828 3.104 6.931 6.931 6.931s6.93-3.102 6.93-6.931v-3.732h1.067v-1.066h-3.199v1.066h1.065v3.732c0 3.234-2.631 5.864-5.864 5.864-3.234 0-5.865-2.631-5.865-5.864v-3.732h1.067v-1.066h-3.199v1.066h1.065v3.732z"/></svg><span class="nasa-cart-count nasa-mini-number cart-number hidden-tag nasa-product-empty">0</span></span><span class="icon-text hidden-tag">Cart</span></a></li></ul>    </div>
</div>
            </script>
        <script type="text/template" id="nasa-style-off-canvas" data-link="https://duniafesyen.com/wp-content/themes/elessi-theme/assets/css/style-off-canvas.css"></script><script type="text/template" id="nasa-style-mobile-menu" data-link="https://duniafesyen.com/wp-content/themes/elessi-theme/assets/css/style-mobile-menu.css"></script><script type="text/template" id="cross-sell-popup-cart-style" data-link="https://duniafesyen.com/wp-content/themes/elessi-theme/assets/css/style-loop-product-modern-5.css"></script><script type="speculationrules">
{"prefetch":[{"source":"document","where":{"and":[{"href_matches":"\/*"},{"not":{"href_matches":["\/wp-*.php","\/wp-admin\/*","\/wp-content\/uploads\/*","\/wp-content\/*","\/wp-content\/plugins\/*","\/wp-content\/themes\/elessi-theme-child\/*","\/wp-content\/themes\/elessi-theme\/*","\/*\\?(.+)"]}},{"not":{"selector_matches":"a[rel~=\"nofollow\"]"}},{"not":{"selector_matches":".no-prefetch, .no-prefetch a"}}]},"eagerness":"conservative"}]}
</script>
<p class="woocommerce-store-notice demo_store" data-notice-id="ecba3578d8cd65126d4a47c76b3c9c2d" style="display:none;">Free Shipping! <a href="#" class="woocommerce-store-notice__dismiss-link">Dismiss</a></p><!-- Instagram Feed JS -->
<script type="text/javascript">
var sbiajaxurl = "https://duniafesyen.com/wp-admin/admin-ajax.php";
</script>

<script type="text/template" id="nasa-single-product-custom-fields">
    <div class="nasa-ct-fields-add-to-cart nasa-not-in-sticky">
        <a href="javascript:void(0);" class="nasa-ct-fields-toggle" rel="nofollow">
            <input class="hidden-tag" type="checkbox" name="nasa-ct-fields-check" value="1" />
            Customize this item?        </a>
        
        <div class="hidden-tag nasa-ct-fields-wrap">
                            <div class="nasa-ct-field">
                    <label for="nasa-ct-font-type">
                        Font Type                    </label>
                    <select id="nasa-ct-font-type" name="nasa-ct-font-type">
                        <option value="Font One">Font One</option><option value="Font Two">Font Two</option><option value="Font Three">Font Three</option><option value="Font Four">Font Four</option>                    </select>
                </div>
                            
                            <div class="nasa-ct-field">
                    <label for="nasa-ct-font-colour">
                        Font Colour                    </label>
                    <select id="nasa-ct-font-colour" name="nasa-ct-font-colour">
                        <option value="Black">Black</option><option value="White">White</option><option value="Silver">Silver</option><option value="Gold">Gold</option>                    </select>
                </div>
                        
                            <div class="nasa-ct-field">
                    <label for="nasa-ct-font-orientation">
                        Font Orientation                    </label>
                    <select id="nasa-ct-font-orientation" name="nasa-ct-font-orientation">
                        <option value="Portrait">Portrait</option><option value="Landscape">Landscape</option>                    </select>
                </div>
                    
                        <div class="nasa-ct-field">
                <label for="nasa-ct-personalized">
                    Enter personalized text                </label>
                <textarea class="nasa-require" id="nasa-ct-personalized" name="nasa-ct-personalized"></textarea>
            </div>
        </div>
    </div>
</script>
			<script>
				const lazyloadRunObserver = () => {
					const lazyloadBackgrounds = document.querySelectorAll( `.e-con.e-parent:not(.e-lazyloaded)` );
					const lazyloadBackgroundObserver = new IntersectionObserver( ( entries ) => {
						entries.forEach( ( entry ) => {
							if ( entry.isIntersecting ) {
								let lazyloadBackground = entry.target;
								if( lazyloadBackground ) {
									lazyloadBackground.classList.add( 'e-lazyloaded' );
								}
								lazyloadBackgroundObserver.unobserve( entry.target );
							}
						});
					}, { rootMargin: '200px 0px 200px 0px' } );
					lazyloadBackgrounds.forEach( ( lazyloadBackground ) => {
						lazyloadBackgroundObserver.observe( lazyloadBackground );
					} );
				};
				const events = [
					'DOMContentLoaded',
					'elementor/lazyload/observe',
				];
				events.forEach( ( event ) => {
					document.addEventListener( event, lazyloadRunObserver );
				} );
			</script>
				<script type='text/javascript'>
		(function () {
			var c = document.body.className;
			c = c.replace(/woocommerce-no-js/, 'woocommerce-js');
			document.body.className = c;
		})();
	</script>
	<link rel='stylesheet' id='wc-blocks-style-css' href='https://duniafesyen.com/wp-content/plugins/woocommerce/assets/client/blocks/wc-blocks.css?ver=wc-9.8.5' type='text/css' media='all' />
<script defer type="text/javascript" src="https://duniafesyen.com/wp-content/plugins/akismet/_inc/akismet-frontend.js?ver=1747140973" id="akismet-frontend-js"></script>
<script type="text/javascript" src="https://duniafesyen.com/wp-content/plugins/elementor/assets/lib/swiper/v8/swiper.min.js?ver=8.4.5" id="swiper-js"></script>
<script type="text/javascript" src="https://duniafesyen.com/wp-content/plugins/contact-form-7/includes/swv/js/index.js?ver=6.6.4" id="swv-js"></script>
<script type="text/javascript" id="contact-form-7-js-extra">
/* <![CDATA[ */
var wpcf7 = {"api":{"root":"https:\/\/duniafesyen.com\/wp-json\/","namespace":"contact-form-7\/v1"},"cached":"1"};
/* ]]> */
</script>
<script type="text/javascript" src="https://duniafesyen.com/wp-content/plugins/contact-form-7/includes/js/index.js?ver=6.6.4" id="contact-form-7-js"></script>
<script type="text/javascript" src="https://duniafesyen.com/wp-content/plugins/woocommerce/assets/js/sourcebuster/sourcebuster.min.js?ver=9.8.5" id="sourcebuster-js-js"></script>
<script type="text/javascript" id="wc-order-attribution-js-extra">
/* <![CDATA[ */
var wc_order_attribution = {"params":{"lifetime":1.0e-5,"session":30,"base64":false,"ajaxurl":"https:\/\/duniafesyen.com\/wp-admin\/admin-ajax.php","prefix":"wc_order_attribution_","allowTracking":true},"fields":{"source_type":"current.typ","referrer":"current_add.rf","utm_campaign":"current.cmp","utm_source":"current.src","utm_medium":"current.mdm","utm_content":"current.cnt","utm_id":"current.id","utm_term":"current.trm","utm_source_platform":"current.plt","utm_creative_format":"current.fmt","utm_marketing_tactic":"current.tct","session_entry":"current_add.ep","session_start_time":"current_add.fd","session_pages":"session.pgs","session_count":"udata.vst","user_agent":"udata.uag"}};
/* ]]> */
</script>
<script type="text/javascript" src="https://duniafesyen.com/wp-content/plugins/woocommerce/assets/js/frontend/order-attribution.min.js?ver=9.8.5" id="wc-order-attribution-js"></script>
<script type="text/javascript" src="https://duniafesyen.com/wp-content/plugins/woocommerce/assets/js/jquery-cookie/jquery.cookie.min.js?ver=1.4.1-wc.9.8.5" id="jquery-cookie-js" defer="defer" data-wp-strategy="defer"></script>
<script type="text/javascript" id="jquery-countdown-js-extra">
/* <![CDATA[ */
var nasa_countdown_l10n = {"days":"Days","months":"Months","weeks":"Weeks","years":"Years","hours":"Hours","minutes":"Mins","seconds":"Secs","day":"Day","month":"Month","week":"Week","year":"Year","hour":"Hour","minute":"Min","second":"Sec"};
/* ]]> */
</script>
<script type="text/javascript" src="https://duniafesyen.com/wp-content/plugins/nasa-core/assets/js/min/countdown.min.js" id="jquery-countdown-js"></script>
<script type="text/javascript" src="https://duniafesyen.com/wp-content/plugins/nasa-core/assets/js/min/jquery.slick.min.js" id="jquery-slick-js"></script>
<script type="text/javascript" id="nasa-typeahead-js-before">
/* <![CDATA[ */
var search_options={"template":"<div class=\"item-search\"><a href=\"{{url}}\" class=\"nasa-link-item-search\" title=\"{{title}}\">{{{image}}}<div class=\"nasa-item-title-search rtl-right rtl-text-right\"><p class=\"nasa-title-item\">{{title}}<\/p><small class=\"nasa-sku-item\">SKU: {{sku}}<\/small><div class=\"price text-left rtl-text-right\">{{{price}}}<\/div><\/div><\/a><\/div>","view_all":"<div class=\"hidden-tag nasa-search-all-wrap\"><a href=\"javascript:void(0);\" class=\"nasa-search-all\" rel=\"nofollow\">More Results<\/a><\/div>","empty_result":"Sorry. No results match your search.","limit":5,"url":"\/?wc-ajax=nasa_search_products"};
/* ]]> */
</script>
<script type="text/javascript" src="https://duniafesyen.com/wp-content/themes/elessi-theme/assets/js/min/typeahead.bundle.min.js" id="nasa-typeahead-js"></script>
<script type="text/javascript" src="https://duniafesyen.com/wp-content/themes/elessi-theme/assets/js/min/handlebars.min.js" id="nasa-handlebars-js"></script>
<script type="text/javascript" id="elessi-functions-js-js-before">
/* <![CDATA[ */
var nasa_ajax_params={"ajax_url":"https:\/\/duniafesyen.com\/wp-admin\/admin-ajax.php","wc_ajax_url":"\/?wc-ajax=%%endpoint%%"};
/* ]]> */
</script>
<script type="text/javascript" src="https://duniafesyen.com/wp-content/themes/elessi-theme/assets/js/min/functions.min.js" id="elessi-functions-js-js"></script>
<script type="text/javascript" src="https://duniafesyen.com/wp-content/themes/elessi-theme/assets/js/min/main.min.js" id="elessi-js-js"></script>
<script type="text/javascript" src="https://duniafesyen.com/wp-content/themes/elessi-theme/assets/js/min/js-large.min.js" id="elessi-js-large-js"></script>
<script type="text/javascript" src="https://duniafesyen.com/wp-content/themes/elessi-theme/assets/js/min/main-async.min.js" id="nasa-main-async-js-js"></script>
<script type="text/javascript" id="nasa-quickview-js-before">
/* <![CDATA[ */
var nasa_params_quickview={"wc_ajax_url":"\/?wc-ajax=%%endpoint%%","i18n_no_matching_variations_text":"Sorry, no products matched your selection. Please choose a different combination.","i18n_make_a_selection_text":"Please select some product options before adding this product to your cart.","i18n_unavailable_text":"Sorry, this product is unavailable. Please choose a different combination."};
/* ]]> */
</script>
<script type="text/javascript" src="https://duniafesyen.com/wp-content/themes/elessi-theme/assets/js/min/nasa-quickview.min.js" id="nasa-quickview-js"></script>
<script type="text/javascript" src="https://duniafesyen.com/wp-content/plugins/nasa-core/assets/js/min/nasa.functions.min.js" id="nasa-core-functions-js-js"></script>
<script type="text/javascript" src="https://duniafesyen.com/wp-content/plugins/nasa-core/assets/js/min/nasa.script.min.js" id="nasa-core-js-js"></script>
<script type="text/javascript" src="https://duniafesyen.com/wp-content/plugins/elementor/assets/js/webpack.runtime.min.js?ver=3.28.4" id="elementor-webpack-runtime-js"></script>
<script type="text/javascript" src="https://duniafesyen.com/wp-content/plugins/elementor/assets/js/frontend-modules.min.js?ver=3.28.4" id="elementor-frontend-modules-js"></script>
<script type="text/javascript" src="https://duniafesyen.com/wp-includes/js/jquery/ui/core.min.js?ver=1.13.3" id="jquery-ui-core-js"></script>
<script type="text/javascript" id="elementor-frontend-js-before">
/* <![CDATA[ */
var elementorFrontendConfig = {"environmentMode":{"edit":false,"wpPreview":false,"isScriptDebug":false},"i18n":{"shareOnFacebook":"Share on Facebook","shareOnTwitter":"Share on Twitter","pinIt":"Pin it","download":"Download","downloadImage":"Download image","fullscreen":"Fullscreen","zoom":"Zoom","share":"Share","playVideo":"Play Video","previous":"Previous","next":"Next","close":"Close","a11yCarouselPrevSlideMessage":"Previous slide","a11yCarouselNextSlideMessage":"Next slide","a11yCarouselFirstSlideMessage":"This is the first slide","a11yCarouselLastSlideMessage":"This is the last slide","a11yCarouselPaginationBulletMessage":"Go to slide"},"is_rtl":false,"breakpoints":{"xs":0,"sm":480,"md":768,"lg":1025,"xl":1440,"xxl":1600},"responsive":{"breakpoints":{"mobile":{"label":"Mobile Portrait","value":767,"default_value":767,"direction":"max","is_enabled":true},"mobile_extra":{"label":"Mobile Landscape","value":880,"default_value":880,"direction":"max","is_enabled":false},"tablet":{"label":"Tablet Portrait","value":1024,"default_value":1024,"direction":"max","is_enabled":true},"tablet_extra":{"label":"Tablet Landscape","value":1200,"default_value":1200,"direction":"max","is_enabled":false},"laptop":{"label":"Laptop","value":1366,"default_value":1366,"direction":"max","is_enabled":false},"widescreen":{"label":"Widescreen","value":2400,"default_value":2400,"direction":"min","is_enabled":false}},"hasCustomBreakpoints":false},"version":"3.28.4","is_static":false,"experimentalFeatures":{"additional_custom_breakpoints":true,"e_local_google_fonts":true,"editor_v2":true,"home_screen":true},"urls":{"assets":"https:\/\/duniafesyen.com\/wp-content\/plugins\/elementor\/assets\/","ajaxurl":"https:\/\/duniafesyen.com\/wp-admin\/admin-ajax.php","uploadUrl":"https:\/\/duniafesyen.com\/wp-content\/uploads"},"nonces":{"floatingButtonsClickTracking":"c8c6179afb"},"swiperClass":"swiper","settings":{"editorPreferences":[]},"kit":{"active_breakpoints":["viewport_mobile","viewport_tablet"],"lightbox_enable_counter":"yes","lightbox_enable_fullscreen":"yes","lightbox_enable_zoom":"yes","lightbox_enable_share":"yes","lightbox_title_src":"title","lightbox_description_src":"description"},"post":{"id":0,"title":"Page Not Found - Dunia Fesyen","excerpt":""}};
/* ]]> */
</script>
<script type="text/javascript" src="https://duniafesyen.com/wp-content/plugins/elementor/assets/js/frontend.min.js?ver=3.28.4" id="elementor-frontend-js"></script>
<script>if(typeof wpcf7 !== "undefined"){wpcf7.cached = 0;}</script></body></html>

<!-- Page cached by LiteSpeed Cache 7.1 on 2025-05-20 14:01:34 -->